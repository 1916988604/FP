#ifndef Flash_Update_H
#define Flash_Update_H

#include "device.h"
#include "board.h"
#include "Types.h"

/**********************************************
* ����1��2��ΪBOOT����
* ����1����������
* ����2����������
**********************************************/
#define BOOT_FUN_SEL   0  //0:can  1:485

#define BAUDRATE_SEL   0  //0:500K  1:250K

#define XTAL_PLL_FREQ  1  //0:120MHz��SCI60MHz��  1:100MHz��SCI50MHz��   2:120Mhz��SCI30MHz��  3:100Mhz��SCI25MHz��

#define  controller    0  //0:ˮ��1�� 1:ˮ��2�� 2:���1��  3:���2;  4:��ѹ��1�� 5:ST030

#if controller == 0                 //ˮ��1
#define  MODBUS_ID      0x07E0
#define  DSP_ID         0x07E8
#define  TM_ID          0x11
#elif controller == 1               //ˮ��2
#define  MODBUS_ID      0x07E1
#define  DSP_ID         0x07E9
#define  TM_ID          0x12
#elif controller == 2               //���1
#define  MODBUS_ID      0x07E2
#define  DSP_ID         0x07EA
#define  TM_ID          0x13
#elif controller == 3               //���2
#define  MODBUS_ID      0x07E3
#define  DSP_ID         0x07EB
#define  TM_ID          0x14
#elif controller == 4               //��ѹ��1
#define  MODBUS_ID      0x07E4
#define  DSP_ID         0x07EC
#define  TM_ID          0x14
#else                               //����
#define  MODBUS_ID      0x07E1
#define  DSP_ID         0x07E9
#define  TM_ID          0x12
#endif

#define  BOOT_VERION  0x01

#define  RECEIVE_MODE  0x01
#define  SEND_MODE     0x03  

#define   SET   0x0AA
#define   CLEAR  0x055
#define   STATUS_SUCCESS        0

typedef  struct 
{
    uint32  CANId;
	uint16  CANDlc;
	uint16  CANData[8];

}CAN_FRAME;

typedef  struct 
{
    uint16  u16_receive_ptr;
    uint16  u16_receive_length;
    uint16  u16_receive_data_flag;
    uint16  u16_can_mode;
    uint16  u16_crc_value;
    uint16  u16_receive_buf[256];
    uint16  u16_crc_flag;                //0x10 crcУ���־
    uint16  u16_send_ptr;
    uint16  u16_send_length;
    uint16  u16_send_buf[256];
    uint16  u16_last_pack_flag;
    uint16  u16_send_sum;
    uint16  u16_ctr_ID;
    uint16  u16_softverion;
}CAN_MODBUS;


typedef  union
{
        struct
        {
             unsigned bit_CRC         :   1;
             unsigned bit_shake       :   1;
             unsigned bit_receive_data:   1;
             unsigned bit_erase       :   1;
             unsigned bit_verorid     :   1;
             unsigned bit_program     :   1;
             unsigned bit_reserved    :   2;
        }field;
        uint16 u16_value;
}BOOT_ERR;

extern void Cana_Modbus_Initial(void);
extern  uint16  Crc_Caculate(uint16 crc_temp,uint16 input_data);
extern uint16 GetU16(uint16* value);
extern void Cana_Crc_Cal0x10(void);
extern void Cana_Process(void);
extern void Cana_Data_Process(void);
extern void Cana_Modbus_Split(void);
extern void Cana_Modbus_Reorganize(CAN_FRAME *pRevFrame);
extern void SysCanaSendData(CAN_FRAME *pSendFrame);

extern void  Flash_FlagProgram_Para(uint16* p_Flash, uint16* p_Array);

extern CAN_MODBUS  Can_Modbus;
extern CAN_FRAME   ReceiveFrame;
extern CAN_FRAME   SendFrame;
extern BOOT_ERR    Boot_err;


#endif
















