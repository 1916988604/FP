/*
 * mcuSel.h
 *
 *  Created on: 2024��5��22��
 *      Author: shujixiang
 */

#ifndef MCUSEL_H_
#define MCUSEL_H_


#define     MCU_SEL     1       //0:2800152/3;  1:2800154/5;    2:2800156/7

#if MCU_SEL==0
    #define  FLASH_START_ADDRESS  0x00083000
    #define  FLASH_STOP_ADDRESS   0x00087F00
    #define  FLASH_FLG1_ADDRESS   0x00087F00
    #define  FLASH_FLG2_ADDRESS   0x00087F09
    #define  FLASH_FLG3_ADDRESS   0x00087F0F
#elif MCU_SEL==1
    #define  FLASH_START_ADDRESS  0x00083000
    #define  FLASH_STOP_ADDRESS   0x0008FF00
    #define  FLASH_FLG1_ADDRESS   0x0008FF00
    #define  FLASH_FLG2_ADDRESS   0x0008FF09
    #define  FLASH_FLG3_ADDRESS   0x0008FF0F
#else
    #define  FLASH_START_ADDRESS  0x00083000
    #define  FLASH_STOP_ADDRESS   0x0009FF00
    #define  FLASH_FLG1_ADDRESS   0x0009FF00
    #define  FLASH_FLG2_ADDRESS   0x0009FF09
    #define  FLASH_FLG3_ADDRESS   0x0009FF0F
#endif




#endif /* MCUSEL_H_ */
