
#include "driverlib.h"
#include "device.h"
#include "board.h"

#include "FlashTech_F280015x_C28x.h"
#include "flash_programming_f280015x.h"
#include "Flash_Update.h"
#include "mcuSel.h"
#include "com_modbus.h"

#pragma  DATA_SECTION(Buffer,"DataBufferSection");
uint16   Buffer[250];
uint32   *Buffer32 = (uint32 *)Buffer;
uint16   ProgramDataLength=0;
extern   uint32      p_Flash ;

void Example_Error(Fapi_StatusType status);
void Example_Done(void);
void Example_CallFlashAPI(void);
void FMSTAT_Fail(void);
void ECC_Fail(void);
void Example_EraseSector(void);

void Example_EraseBanks(void);
void Example_ProgramUsingAutoECC(void);
void Example_ProgramBankUsingAutoECC(void);
void Example_ProgramUsingDataOnlyECCOnly(void);
void Example_ProgramUsingDataAndECC(void);
void ClearFSMStatus(void);

__interrupt void INT_myCPUTIMER0_ISR(void);
extern void Board_init();

unsigned int    time10msFlg=0;
unsigned int    time10msCnt=0;
uint16_t txMsgData[8], rxMsgData[8];
unsigned int    u16_10ms_count=0;
unsigned int    time_10ms_flg=0;
uint16  erase_force_flg=0;
extern uint32      u16_Status;
#define MSG_DATA_LENGTH    8


#pragma DATA_SECTION(var_sel, "prg_data_flg")
#pragma RETAIN (var_sel)
    //0x0080010: BIT0-7(BOOT�汾); BIT8(0:500K,1:250K); bit10(0:��CAN������1:485��CAN����)
    //0x0080011: ����ID
    //0x0080012: ����ID
    //0x0080013: BIT16-31(��)
    //0x0080014: BIT8-15(��)��BIT0-7(��)
    //const unsigned int  var_sel[]={(0x000B+(BAUDRATE_SEL<<8)+(1<<10)),DSP_ID,MODBUS_ID,24,((11<<8)+11)};
    //const unsigned int  var_sel[]={(0x000B+(BAUDRATE_SEL<<8)+(1<<10)),DSP_ID,MODBUS_ID,25,((04<<8)+30)};
    const unsigned int  var_sel[]={(0x000C+(BAUDRATE_SEL<<8)+(1<<10)),DSP_ID,MODBUS_ID,25,((05<<8)+14)};    //��е��Ӳ��V1.1
/*#pragma DATA_SECTION(boot_RamData, ".bootramData")
    uint16 boot_RamData[4];*/

/*
#pragma DATA_SECTION(var2, "testdata_flg")
#pragma RETAIN (var2)
    const unsigned int  var2[]={1,3,4,5,6,7,9};

#pragma DATA_SECTION(var3, "testdata_flg1")
#pragma RETAIN (var3)
    const unsigned int  var3[]={1,3,4,5,6,7,9};

#pragma DATA_SECTION(var4, "testdata_flg2")
#pragma RETAIN (var4)
    const unsigned int  var4[]={1,3,4,5,6,7,9};
*/

void main(void)
{
    //
    // Initialize device clock and peripherals
    // Copy the Flash initialization code from Flash to RAM
    // Copy the Flash API from Flash to RAM
    // Configure Flash wait-states, fall back power mode, performance features
    // and ECC
    //
    Device_init();

    //
    // Initialize GPIO
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    SysCtl_setWatchdogMode(SYSCTL_WD_MODE_RESET);
    SysCtl_setWatchdogPredivider(SYSCTL_WD_PREDIV_128);
    SysCtl_setWatchdogPrescaler(SYSCTL_WD_PRESCALE_1);
    SysCtl_serviceWatchdog();
    SysCtl_disableWatchdog();

    Board_init();
    f_rs485_ComInit();
    Cana_Modbus_Initial();
    txMsgData[0] = 0x01;
    txMsgData[1] = 0x02;
    *(uint16_t *)rxMsgData = 0;

    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    EINT;
    ERTM;

    time_10ms_flg = 0;

    // At 120MHz, execution wait-states for external oscillator is 2. Modify the
    // wait-states when the system clock frequency is changed.
    Flash_initModule(FLASH0CTRL_BASE, FLASH0ECC_BASE, 2);

    // Flash API functions should not be executed from the same bank on which
    // erase/program operations are in progress.
    // Also, note that there should not be any access to the Flash bank on
    // which erase/program operations are in progress.  Hence below function
    // is mapped to RAM for execution.
    //
    while(1){
        Cana_Data_Process( );

        //RAM������������CMD�ļ��������䶨�壬����λʱֱ����0�ˣ���0������оƬ��ʼ��������
        //if((1==time_10ms_flg)&&(erase_force_flg==0) &&(boot_RamData[0]!=0x38)&&(boot_RamData[1]!=0x0EC)){
        if((1==time_10ms_flg)&&(erase_force_flg==0) &&(*(uint8 *)0x8000 !=0x38)&&(*(uint8 *)0x8001 !=0x0EC)){
            if(*((uint16 *)FLASH_FLG1_ADDRESS)==0x55BB) //������ɱ�־ B�����һ���ӿռ�
            {
                if((*((uint16 *)FLASH_FLG2_ADDRESS)==0xffff)&&(*((uint16 *)FLASH_FLG3_ADDRESS)==0xffff))//����Ƿ����flash�����FALSHĬ��״̬Ϊȫ1���������ȫ1��˵�����������flash�ռ䲻��
                {
                    DINT;
                    DRTM;
                    CPUTimer_stopTimer(myCPUTIMER0_BASE);


                    //GPIO_togglePin(myGPIO0);
                    asm(" LB #0x0083000") ; //app����ռ�õ�flash��ȡ�ռ�Ϊ����0x0083000- 0x0083001�����ڴ����ת��app��ڵ�ַ֮ǰ����ڵ�ַ��
                }
            }
        }
        if(time10msFlg==1){
            time10msFlg = 0;
            //CAN_sendMessage(myCAN0_BASE, 2, MSG_DATA_LENGTH, txMsgData);
        }

/*
        if(time10msFlg==1){
            time10msFlg=0;
            Fapi_StatusType  oReturnCheck;
            uint32_t p_flashNum=9;
            uint32_t p_flashNum1=16;
            uint32_t i;
            DINT;
            //����FLASH�󣬴˳�ʼ�����벻��Ҫ
            //Fapi_initializeAPI(FlashTech_CPU0_BASE_ADDRESS, 120);
            //oReturnCheck = Fapi_setActiveFlashBank(Fapi_FlashBank0);
            //��д�ɹ�����
            for(i=0; i < WORDS_IN_FLASH_BUFFER; i++)
            {
                Buffer[i] = i+1;
            }
            p_Flash = 0x83008;       //��ʼ��ַ��Ҫ��8�ı���
            ProgramDataLength = 0x400;
            Example_ProgramUsingAutoECC();
            EINT;
            //ʾ�����ķ��ͳɹ�
            //CAN_sendMessage(myCAN0_BASE, 2, MSG_DATA_LENGTH, txMsgData);
        }else if(time10msFlg==3){
            time10msFlg=0;
            uint32_t i;
            DINT;
            //��д�ɹ�����
            for(i=0; i < WORDS_IN_FLASH_BUFFER; i++)
            {
                Buffer[i] = i+40;
            }
            p_Flash = 0x8FEF0;       //��ʼ��ַ��Ҫ��8�ı���
            ProgramDataLength = 0x8;
            Example_ProgramUsingAutoECC();
            EINT;
        }else if(time10msFlg==2){
            //����ʾ��
            Fapi_StatusType  oReturnCheck;
            time10msFlg=0;
            uint32 eraseStartAdd = 0x83000;
            unsigned int i=0;
            DINT;
            Fapi_initializeAPI(FlashTech_CPU0_BASE_ADDRESS, 120);
            oReturnCheck = Fapi_setActiveFlashBank(Fapi_FlashBank0);
            //����OK
            Example_EraseSector();
            //����OK
            //for(i=0;i<116;i++)
            //{
            //    eraseStartAdd = 1024;
            //    eraseStartAdd = eraseStartAdd*i+0x83000;
            //    Fapi_setupBankSectorEnable(FLASH_WRAPPER_PROGRAM_BASE+FLASH_O_CMDWEPROTA, 0x00000FFF);
            //    Fapi_setupBankSectorEnable(FLASH_WRAPPER_PROGRAM_BASE+FLASH_O_CMDWEPROTB, 0x00000000);
            //    Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector,(uint32*)eraseStartAdd);   //0x400�������
            //    while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}
            //}
            EINT;
        }*/
    }

    //Example_CallFlashAPI();
    //Example_Done();
}


__interrupt  void INT_myCPUTIMER0_ISR(void)     //0.1ms
{
    static unsigned int ms0_5Cnt=0;

    ms0_5Cnt++;
    if(ms0_5Cnt>5){ //0.5ms
        commTicker++;
        ms0_5Cnt = 0;
        if(commTicker>40000){
            commTicker=40000;
        }
    }

    time10msCnt++;
    if(time10msCnt>100)
    {
        time10msFlg=1;
        time10msCnt=0;
        //GPIO_togglePin(myGPIO24);
    }

    u16_10ms_count++;
    if(u16_10ms_count >= 300)  //200ms/100us=2000
    {
        u16_10ms_count = 300;
        time_10ms_flg  = 1;
    }
    Cana_Process();//���ж���ִ��MODBUSЭ�����ݵ����飨�������ݣ����֣��������ݣ�
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

//**************************************************************************************
//  ClearFSMStatus
//
//  This function clears the status (STATCMD, similar to FMSTAT of the previous 
//  devices) of the previous flash operation.
//  This function and the flash API functions used in this function are 
//  executed from RAM in this example.
//  Note: this function is applicable for only F280013X, F280015X and F28P65X devices
//**************************************************************************************
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(ClearFSMStatus, ".TI.ramfunc");
#endif
void ClearFSMStatus(void){
    Fapi_FlashStatusType  oFlashStatus;
    Fapi_StatusType  oReturnCheck;

    //
    // Wait until FSM is done with the previous flash operation
    //
    while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}
        oFlashStatus = Fapi_getFsmStatus();
        if(oFlashStatus != 0)
        {

            /* Clear the Status register */
            oReturnCheck = Fapi_issueAsyncCommand(Fapi_ClearStatus);
            //
            // Wait until status is cleared
            //
            while (Fapi_getFsmStatus() != 0) {}

            if(oReturnCheck != Fapi_Status_Success)
            {
                //
                // Check Flash API documentation for possible errors
                //
                Example_Error(oReturnCheck);
            }
        }
}


//*****************************************************************************
//  Example_ProgramUsingAutoECC
//
//  Example function to Program data in Flash using "AutoEccGeneration" option.
//  Flash API functions used in this function are executed from RAM in this
//  example.
//*****************************************************************************
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Example_ProgramUsingAutoECC, ".TI.ramfunc");
#endif
void Example_ProgramUsingAutoECC(void)
{
    uint32 u32Index = 0;
    uint16 i = 0;
    Fapi_StatusType  oReturnCheck;
    Fapi_FlashStatusType  oFlashStatus;
    Fapi_FlashStatusWordType  oFlashStatusWord;

    //
    // A data buffer of max 8 16-bit words can be supplied to the program
    // function.
    // Each word is programmed until the whole buffer is programmed or a
    // problem is found. However to program a buffer that has more than 8
    // words, program function can be called in a loop to program 8 words for
    // each loop iteration until the whole buffer is programmed.
    //
    // Remember that the main array flash programming must be aligned to
    // 64-bit address boundaries and each 64 bit word may only be programmed
    // once per write/erase cycle.  Meaning the length of the data buffer
    // (3rd parameter for Fapi_issueProgrammingCommand() function) passed
    // to the program function can only be either 4 or 8.
    //
    // Program data in Flash using "AutoEccGeneration" option.
    // When AutoEccGeneration option is used, Flash API calculates ECC for the
    // given 64-bit data and programs it along with the 64-bit main array data.
    // Note that any unprovided data with in a 64-bit data slice
    // will be assumed as 1s for calculating ECC and will be programmed.
    //
    // Note that data buffer (Buffer) is aligned on 64-bit boundary for verify
    // reasons.
    //
    // Monitor ECC address for the sector below while programming with 
    // AutoEcc mode.
    //
    // In this example, the number of bytes specified in the flash buffer
    // are programmed in the flash sector below along with auto-generated
    // ECC.
    //

    for(i=0, u32Index = p_Flash;
       (u32Index < (p_Flash + ProgramDataLength));
       i+= 8, u32Index+= 8)
    {
        ClearFSMStatus();

        // Enable program/erase protection for select sectors where this example is 
        // located
        // CMDWEPROTA is applicable for sectors 0-31
        // Bits 0-11 of CMDWEPROTB is applicable for sectors 32-127, each bit represents
        // a group of 8 sectors, e.g bit 0 represents sectors 32-39, bit 1 represents
        // sectors 40-47, etc
        Fapi_setupBankSectorEnable(FLASH_WRAPPER_PROGRAM_BASE+FLASH_O_CMDWEPROTA, 0x00000FFF);
        Fapi_setupBankSectorEnable(FLASH_WRAPPER_PROGRAM_BASE+FLASH_O_CMDWEPROTB, 0x00000000);


        oReturnCheck = Fapi_issueProgrammingCommand((uint32 *)u32Index,Buffer+i,
                                               8, 0, 0, Fapi_AutoEccGeneration);

        //
        // Wait until the Flash program operation is over
        //
        while(Fapi_checkFsmForReady() == Fapi_Status_FsmBusy);

        if(oReturnCheck != Fapi_Status_Success)
        {
            //
            // Check Flash API documentation for possible errors
            //
            Example_Error(oReturnCheck);
        }

        //
        // Read FMSTAT register contents to know the status of FSM after
        // program command to see if there are any program operation related
        // errors
        //
        oFlashStatus = Fapi_getFsmStatus();
        if(oFlashStatus != 3)
        {
            //
            //Check FMSTAT and debug accordingly
            //
            FMSTAT_Fail();
        }

        //
        // Verify the programmed values.  Check for any ECC errors.
        //
        oReturnCheck = Fapi_doVerify((uint32 *)u32Index,
                                     4, (uint32 *)(uint32)(Buffer + i),
                                     &oFlashStatusWord);

        if(oReturnCheck != Fapi_Status_Success)
        {
            //
            // Check Flash API documentation for possible errors
            //
            Example_Error(oReturnCheck);
            u16_Status=1;
        }else{
            u16_Status=0;
        }
    }
}


//*****************************************************************************
//  Example_EraseSector
//
//  Example function to Erase data of a sector in Flash.
//  Flash API functions used in this function are executed from RAM in this
//  example.
//*****************************************************************************
#ifdef __cplusplus
#pragma CODE_SECTION(".TI.ramfunc");
#else
#pragma CODE_SECTION(Example_EraseSector, ".TI.ramfunc");
#endif
void Example_EraseSector(void)
{
    Fapi_StatusType  oReturnCheck;
    Fapi_FlashStatusType  oFlashStatus;
    Fapi_FlashStatusWordType  oFlashStatusWord;

    uint32 eraseStartAdd;
    unsigned int i;
    unsigned int flashEraseLen=52;
    unsigned int mcuType;

    mcuType=MCU_SEL;
    if(mcuType==0){         //0:2800152/3;  1:2800154/5;    2:2800156/7
        flashEraseLen = 20;
    }else if(mcuType==1){
        flashEraseLen = 52;
    }else{
        flashEraseLen = 116;
    }

    for(i=0;i<flashEraseLen;i++){     //115*1024+0x83000=0x9FC00.     116:2800156/2800157;   52::2800154/2800155;   20::2800152/2800153;
        ClearFSMStatus();

        // Enable program/erase protection for select sectors where this example is 
        // located
        // CMDWEPROTA is applicable for sectors 0-31
        // Bits 0-11 of CMDWEPROTB is applicable for sectors 32-127, each bit represents
        // a group of 8 sectors, e.g bit 0 represents sectors 32-39, bit 1 represents
        // sectors 40-47, etc
        Fapi_setupBankSectorEnable(FLASH_WRAPPER_PROGRAM_BASE+FLASH_O_CMDWEPROTA, 0x00000FFF);
        Fapi_setupBankSectorEnable(FLASH_WRAPPER_PROGRAM_BASE+FLASH_O_CMDWEPROTB, 0x00000000);
        eraseStartAdd = 1024;
        eraseStartAdd = eraseStartAdd*i+0x83000;
        oReturnCheck = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector,
                           (uint32 *)eraseStartAdd);
    }

    //
    // Erase the sector that is programmed in the above example
    // Erase Sector 0
    //


    //oReturnCheck = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector,
    //               (uint32 *)Bzero_Sector12_start);
    //
    // Wait until FSM is done with erase sector operation
    //
    while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}

    if(oReturnCheck != Fapi_Status_Success)
    {
        //
        // Check Flash API documentation for possible errors
        //
        Example_Error(oReturnCheck);
    }

    //
    // Read FMSTAT register contents to know the status of FSM after
    // erase command to see if there are any erase operation related errors
    //
    oFlashStatus = Fapi_getFsmStatus();
        if(oFlashStatus != 3)
    {
        //
        // Check Flash API documentation for FMSTAT and debug accordingly
        // Fapi_getFsmStatus() function gives the FMSTAT register contents.
        // Check to see if any of the EV bit, ESUSP bit, CSTAT bit or
        // VOLTSTAT bit is set (Refer to API documentation for more details).
        //
        FMSTAT_Fail();
        u16_Status=1;
    }else{
        u16_Status=0;
    }

    //
    // Verify that Sector0 is erased
    //
    oReturnCheck = Fapi_doBlankCheck((uint32 *)Bzero_Sector12_start,
                   Sector2KB_u32length,
                   &oFlashStatusWord);
    if(oReturnCheck != Fapi_Status_Success)
    {
        //
        // Check Flash API documentation for error info
        //
        Example_Error(oReturnCheck);
    }
}


//******************************************************************************
// For this example, just stop here if an API error is found
//******************************************************************************
void Example_Error(Fapi_StatusType status)
{
    //
    //  Error code will be in the status parameter
    //
    __asm("    ESTOP0");
}

//******************************************************************************
//  For this example, once we are done just stop here
//******************************************************************************
void Example_Done(void)
{
    __asm("    ESTOP0");
}

//******************************************************************************
// For this example, just stop here if FMSTAT fail occurs
//******************************************************************************
void FMSTAT_Fail(void)
{
    __asm("    ESTOP0");
}

//******************************************************************************
// For this example, just stop here if ECC fail occurs
//******************************************************************************
void ECC_Fail(void)
{
    __asm("    ESTOP0");
}

//
// End of File
//
