/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"
#include "Flash_Update.h"
//*****************************************************************************
//
// Board Configurations
// Initializes the rest of the modules.
// Call this function in your application if you wish to do all module
// initialization.
// If you wish to not use some of the initializations, instead of the
// Board_init use the individual Module_inits
//
//*****************************************************************************
void Board_init()
{
    EALLOW;

    PinMux_init();
    CAN_init();
    CPUTIMER_init();
	SCI_init();
    INTERRUPT_init();

    EDIS;
}

//*****************************************************************************
//
// PINMUX Configurations
//
//*****************************************************************************
void PinMux_init()
{
    //
    // PinMux for modules assigned to CPU1
    //

    //
    // CANA -> myCAN0 Pinmux
    GPIO_setPinConfig(myCAN0_CANRX_PIN_CONFIG);
    GPIO_setPinConfig(myCAN0_CANTX_PIN_CONFIG);

#if    CAN_PIN_SEL_B==0       //2800157 ���԰�

#elif CAN_PIN_SEL_B==1        //2800155 ���ư�
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(230, GPIO_ANALOG_DISABLED);
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(20, GPIO_ANALOG_DISABLED);
#elif CAN_PIN_SEL_B==3        //��е��������
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(12, GPIO_ANALOG_DISABLED);
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(13, GPIO_ANALOG_DISABLED);
#else                       //2800155 ������
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(12, GPIO_ANALOG_DISABLED);
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(13, GPIO_ANALOG_DISABLED);
#endif

    GPIO_setPadConfig(myCAN0_CANRX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(myCAN0_CANRX_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPadConfig(myCAN0_CANTX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(myCAN0_CANTX_GPIO, GPIO_QUAL_ASYNC);

#if CAN_PIN_SEL_B==3        //��е��������
    //
    // SCIC -> mySCIC Pinmux
    //
    GPIO_setPinConfig(mySCIC_SCIRX_PIN_CONFIG);
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(226, GPIO_ANALOG_DISABLED);
    GPIO_setPadConfig(mySCIC_SCIRX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(mySCIC_SCIRX_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(mySCIC_SCITX_PIN_CONFIG);
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(20, GPIO_ANALOG_DISABLED);
    GPIO_setPadConfig(mySCIC_SCITX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(mySCIC_SCITX_GPIO, GPIO_QUAL_ASYNC);
#else
    //
    // SCIB -> mySCIB Pinmux
    //
    GPIO_setPinConfig(mySCIB_SCIRX_PIN_CONFIG);
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(13, GPIO_ANALOG_DISABLED);
    GPIO_setPadConfig(mySCIB_SCIRX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(mySCIB_SCIRX_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(mySCIB_SCITX_PIN_CONFIG);
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(12, GPIO_ANALOG_DISABLED);
    GPIO_setPadConfig(mySCIB_SCITX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(mySCIB_SCITX_GPIO, GPIO_QUAL_ASYNC);

    // GPIO28 -> Re_Tr_485Dir Pinmux
    GPIO_setPinConfig(GPIO_28_GPIO28);
    // AGPIO -> GPIO mode selected
    GPIO_setAnalogMode(28, GPIO_ANALOG_DISABLED);
    GPIO_writePin(28, 0);
    GPIO_setPadConfig(28, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(28, GPIO_QUAL_SYNC);
    GPIO_setDirectionMode(28, GPIO_DIR_MODE_OUT);
#endif
}

//*****************************************************************************
//
// CAN Configurations
//
//*****************************************************************************
void CAN_init(){
    myCAN0_init();
}

void myCAN0_init(){
    CAN_initModule(myCAN0_BASE);
    //
    // Refer to the Driver Library User Guide for information on how to set
    // tighter timing control. Additionally, consult the device data sheet
    // for more information about the CAN module clocking.
    //
#if XTAL_PLL_FREQ==0  || XTAL_PLL_FREQ==2
    #if BAUDRATE_SEL==0
        CAN_setBitTiming(myCAN0_BASE, 9, 0, 14, 7, 3); //500k,������79.1%
    #else
        CAN_setBitTiming(myCAN0_BASE, 19, 0, 14, 7, 3); //250k,������79.1%
    #endif
#else
    #if BAUDRATE_SEL==0
        CAN_setBitTiming(myCAN0_BASE, 7, 0, 15, 7, 3); //500k,������79.1%
    #else
        CAN_setBitTiming(myCAN0_BASE, 15, 0, 15, 7, 3); //250k,������79.1%
    #endif
#endif
    //
    // Initialize the transmit message object used for sending CAN messages.
    // Message Object Parameters:
    //      Message Object ID Number: 1
    //      Message Identifier: 100
    //      Message Frame: CAN_MSG_FRAME_STD
    //      Message Type: CAN_MSG_OBJ_TYPE_RX
    //      Message ID Mask: 0
    //      Message Object Flags:
    //      Message Data Length: 0 Bytes
    //

    //CAN_setupMessageObject(myCAN0_BASE, 1, myCAN0_MessageObj1_ID, CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_RX, 0, 0,0);
    CAN_setupMessageObject(myCAN0_BASE, 1, myCAN0_MessageObj1_ID, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_RX, 0, 0,0);
    //
    // Initialize the transmit message object used for sending CAN messages.
    // Message Object Parameters:
    //      Message Object ID Number: 2
    //      Message Identifier: 200
    //      Message Frame: CAN_MSG_FRAME_STD
    //      Message Type: CAN_MSG_OBJ_TYPE_TX
    //      Message ID Mask: 0
    //      Message Object Flags:
    //      Message Data Length: 8 Bytes
    //
    //CAN_setupMessageObject(myCAN0_BASE, 2, myCAN0_MessageObj2_ID, CAN_MSG_FRAME_STD,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    CAN_setupMessageObject(myCAN0_BASE, 2, myCAN0_MessageObj2_ID, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
    //
    // Start CAN module operations
    //
    CAN_startModule(myCAN0_BASE);
}

//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
void CPUTIMER_init(){
    myCPUTIMER0_init();
}

void myCPUTIMER0_init(){
    CPUTimer_setEmulationMode(myCPUTIMER0_BASE, CPUTIMER_EMULATIONMODE_RUNFREE);
    CPUTimer_setPreScaler(myCPUTIMER0_BASE, 0U);
#if XTAL_PLL_FREQ==0  || XTAL_PLL_FREQ==2
    CPUTimer_setPeriod(myCPUTIMER0_BASE, 12000U);
#else
    CPUTimer_setPeriod(myCPUTIMER0_BASE, 10000U);
#endif
    CPUTimer_enableInterrupt(myCPUTIMER0_BASE);
    CPUTimer_stopTimer(myCPUTIMER0_BASE);

    CPUTimer_reloadTimerCounter(myCPUTIMER0_BASE);
    CPUTimer_startTimer(myCPUTIMER0_BASE);
}

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************
void INTERRUPT_init(){

    // Interrupt Setings for INT_myCPUTIMER0
    Interrupt_register(INT_myCPUTIMER0, &INT_myCPUTIMER0_ISR);
    Interrupt_enable(INT_myCPUTIMER0);
}
void SCI_init(){
#if CAN_PIN_SEL_B==3        //��е��������
	mySCIC_init();
#else
    mySCIB_init();
#endif
}

#if CAN_PIN_SEL_B==3        //��е��������
    void mySCIC_init(){
        SCI_clearInterruptStatus(mySCIC_BASE, SCI_INT_RXFF | SCI_INT_TXFF | SCI_INT_FE | SCI_INT_OE | SCI_INT_PE | SCI_INT_RXERR | SCI_INT_RXRDY_BRKDT | SCI_INT_TXRDY);
        SCI_clearOverflowStatus(mySCIC_BASE);
        SCI_disableFIFO(mySCIC_BASE);
        SCI_resetChannels(mySCIC_BASE);
        SCI_setConfig(mySCIC_BASE, DEVICE_LSPCLK_FREQ, mySCIC_BAUDRATE, (SCI_CONFIG_WLEN_8|SCI_CONFIG_STOP_ONE|SCI_CONFIG_PAR_NONE));
        SCI_disableLoopback(mySCIC_BASE);
        SCI_performSoftwareReset(mySCIC_BASE);
        SCI_enableModule(mySCIC_BASE);
    }
#else
    void mySCIB_init(){
        SCI_clearInterruptStatus(mySCIB_BASE, SCI_INT_RXFF | SCI_INT_TXFF | SCI_INT_FE | SCI_INT_OE | SCI_INT_PE | SCI_INT_RXERR | SCI_INT_RXRDY_BRKDT | SCI_INT_TXRDY);
        SCI_clearOverflowStatus(mySCIB_BASE);
        SCI_disableFIFO(mySCIB_BASE);
        SCI_resetChannels(mySCIB_BASE);
        SCI_setConfig(mySCIB_BASE, DEVICE_LSPCLK_FREQ, mySCIB_BAUDRATE, (SCI_CONFIG_WLEN_8|SCI_CONFIG_STOP_ONE|SCI_CONFIG_PAR_NONE));
        SCI_disableLoopback(mySCIB_BASE);
        SCI_performSoftwareReset(mySCIB_BASE);
        SCI_enableModule(mySCIB_BASE);
    }
#endif


