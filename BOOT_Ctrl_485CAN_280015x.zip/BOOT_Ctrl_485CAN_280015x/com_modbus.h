/*
 * com_modbus.c
 *
 *  Created on: 2024��11��8��
 *      Author: shujixiang
 */

#ifndef SRC_APP_C_COM_MODBUS_H_
#define SRC_APP_C_COM_MODBUS_H_

#define     sci_numeber_Mod      2       //0:scia�� 1:scib; 2:scic

//*******sci ʹ���ź�*******************************************/
#if sci_numeber_Mod!=2
#define SET_RTS_R   (GpioDataRegs.GPACLEAR.bit.GPIO28 = 1)
#define SET_RTS_T   (GpioDataRegs.GPASET.bit.GPIO28 = 1)
#else
#define SET_RTS_R
#define SET_RTS_T
#endif

#ifdef  SRC_APP_COM_MODBUS_C_
    #define SRC_APP_COM_MODBUS
#else
    #define SRC_APP_COM_MODBUS  extern
#endif

SRC_APP_COM_MODBUS void f_rs485_ComInit();
SRC_APP_COM_MODBUS interrupt void SCI_RXD_isr(void);
SRC_APP_COM_MODBUS interrupt void SCI_TXD_isr(void);
SRC_APP_COM_MODBUS unsigned int baudrate;
SRC_APP_COM_MODBUS unsigned int commTicker;
SRC_APP_COM_MODBUS unsigned int frameSpaceTime;
SRC_APP_COM_MODBUS unsigned int frameStoRSpaceTime;

#endif



