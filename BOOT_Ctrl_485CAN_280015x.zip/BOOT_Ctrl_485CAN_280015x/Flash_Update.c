
#include "f280015x_device.h"
#include "device.h"
#include "board.h"
#include "Types.h"
#include "Flash_Update.h"
#include "FlashTech.h"
#include "flash_programming_f280015x.h"
#include "mcuSel.h"
#include "com_modbus.h"

extern volatile struct SCI_REGS *SciRegs;

CAN_MODBUS 	Can_Modbus;
CAN_FRAME   ReceiveFrame; 
CAN_FRAME   SendFrame;
BOOT_ERR    Boot_err;

uint32      p_Flash ;
uint32 		u16_Status = 0 ;
uint16 		u16_Flash_Result_Flag = SET ;
uint16  	u32_total_iap_file_length_byte = 0  ;
uint16  	u32_upgraded_iap_file_length_byte = 0 ;
uint16  	u16_package_iap_file_length_byte = 0 ;    // ����Ҫ�����ļ��ֽ���  ��������+�������� = �ܵ��ֽ��� �����
uint16  	u16_last_package_flag = CLEAR ;
uint16      crc_value16bit;
uint32      total_iap_length=0;
uint32      iap_start_adddress;

extern uint16  erase_force_flg;
extern uint16_t txMsgData[8], rxMsgData[8];
extern uint16   ProgramDataLength;
extern uint16   Buffer[1024];
extern void Example_EraseSector(void);
extern void Example_ProgramUsingAutoECC(void);

extern uint16 can_485_flg;
extern uint16 dataSend485_over;

/****************************************************************************************
** ��������:  Modbus����֡�ĳ�ʼ��
****************************************************************************************/
void Cana_Modbus_Initial(void)
{
    uint16 i;

    Can_Modbus.u16_receive_ptr=0;
    Can_Modbus.u16_receive_length=8;
    Can_Modbus.u16_receive_data_flag=CLEAR;
	Can_Modbus.u16_can_mode=RECEIVE_MODE;
    Can_Modbus.u16_crc_value=0xffff;
    Can_Modbus.u16_send_ptr=0;
    Can_Modbus.u16_send_length=8;
	Can_Modbus.u16_crc_flag=CLEAR;            /*crc�����־λ*/

    Can_Modbus.u16_last_pack_flag = CLEAR;
    Boot_err.u16_value = 0;
    Can_Modbus.u16_ctr_ID = TM_ID;
    Can_Modbus.u16_softverion = BOOT_VERION;
    Can_Modbus.u16_send_sum = 8;

	for(i=0;i<256;i++)                       /*��ʼ���շ��;�Ϊ0*/
	{
	   Can_Modbus.u16_receive_buf[i]=0;
	   Can_Modbus.u16_send_buf[i]=0;
	}
}


/****************************************************************************************
** ��������:  ����һ֡����
** ��    ��:  pSendFrame������֡��			  
****************************************************************************************/
void SysCanaSendData(CAN_FRAME *pSendFrame)
{
    uint16 i;

    for(i=0;i<8;i++)
    {
        txMsgData[i]=pSendFrame->CANData[i];
    }
    if(can_485_flg==0){
        CAN_sendMessage(myCAN0_BASE, 2, 8, txMsgData);
    }else{
        if(dataSend485_over==0){
            SET_RTS_T;  // RTS��Ϊ����
            //ScibRegs.SCICTL1.all = 0x0022;  // ����
            //ScibRegs.SCICTL2.all = 0x00C1;  // ���������ж�
            //ScibRegs.SCITXBUF.all = txMsgData[0];
            SciRegs->SCICTL1.all = 0x0022;  // ����
            SciRegs->SCICTL2.all = 0x00C1;  // ���������ж�
            SciRegs->SCITXBUF.all = txMsgData[0];


        }
    }
}


/****************************************************************************************
** �ļ�����:  Cana_Process.c
** ��������:  CAN����
****************************************************************************************/
void Cana_Process(void)
{
    uint16 i;

    if(can_485_flg==1){
        if(commTicker>10000){
              Can_Modbus.u16_receive_ptr=0;
              Can_Modbus.u16_crc_value = 0;
              Can_Modbus.u16_can_mode=RECEIVE_MODE;
              Can_Modbus.u16_receive_data_flag = CLEAR;
              SET_RTS_R;
              SciRegs->SCICTL1.all = 0x0021;  // ����
              SciRegs->SCICTL2.all = 0x00C2;  // ���������ж�
              dataSend485_over = 0;
              Can_Modbus.u16_send_sum = 8;
              commTicker = 0;
              f_rs485_ComInit();
         }
    }

     if(Can_Modbus.u16_can_mode == RECEIVE_MODE)    //����ģʽ
	 {	    
	     if(Can_Modbus.u16_receive_data_flag == CLEAR)
		 {
	          if(CAN_readMessage(myCAN0_BASE, 1, rxMsgData))	            /*���յ�����*/
	          {
	              can_485_flg = 0;
	              ReceiveFrame.CANDlc = 8;
	              for(i=0;i<8;i++){
	                  ReceiveFrame.CANData[i] = rxMsgData[i];
	              }
                  Cana_Modbus_Reorganize(&ReceiveFrame);
			  }
		 }
	 }
	 else if(Can_Modbus.u16_can_mode == SEND_MODE)
	 {
	      //if(ECanaRegs.CANTRS.bit.TRS0==0)                       /*���ͳɹ�ʱ����ʼҲΪ0*/
		  {
			  Cana_Modbus_Split();                              /*modbus����ֱ�־λ        */
		  }
	 }    
}


/****************************************************************************************
** ��������:  Modbus����
** ��    ��:  pSourceFrame CAN����֡
****************************************************************************************/
void Cana_Modbus_Reorganize(CAN_FRAME *pRevFrame)
{
	   /*����һ֡������������*/
    memcpy(Can_Modbus.u16_receive_buf+Can_Modbus.u16_receive_ptr,pRevFrame->CANData,pRevFrame->CANDlc);
    Can_Modbus.u16_receive_ptr+=pRevFrame->CANDlc;
    if(Can_Modbus.u16_receive_ptr<=8)
    {
         if((Can_Modbus.u16_receive_buf[1] != Can_Modbus.u16_softverion))//�����汾����
         {
               Can_Modbus.u16_receive_ptr=0;
               Can_Modbus.u16_crc_value = 0;
         }else if((Can_Modbus.u16_receive_buf[0] != Can_Modbus.u16_ctr_ID))//�������ͺŲ���
         {
               Can_Modbus.u16_receive_ptr=0;
               Can_Modbus.u16_crc_value = 0;
         }
         else
         {
                Can_Modbus.u16_send_sum = Can_Modbus.u16_receive_buf[2]; //�ܵ����ݳ���
         }
    }

    if(Can_Modbus.u16_receive_ptr>=Can_Modbus.u16_send_sum)
    {
         Can_Modbus.u16_receive_ptr=0;
         Can_Modbus.u16_crc_value = 0;

         if(Can_Modbus.u16_receive_buf[Can_Modbus.u16_send_sum-1] == 0xFF)
         {
             Can_Modbus.u16_crc_flag = SET;
         }
         else
         {
             Can_Modbus.u16_crc_value = 0;
         }
    }
}

/****************************************************************************************
** ��������:  ����������ݣ��������Ļظ��ź�
****************************************************************************************/
void Cana_Modbus_Split(void)
{   
   SysCanaSendData(&SendFrame);        /* ����һ֡���� */
   if((Can_Modbus.u16_last_pack_flag== SET)) //appӦ�ó������ת
   {
       Buffer[0]=0x55BB;
       Buffer[1]=0x5500;
       Buffer[2]=0x5511;
       Buffer[3]=0x5522;
       Buffer[4]=0x5533;
       Buffer[5]=0x5544;
       Buffer[6]=0x5555;
       Buffer[7]=0x5566;

       p_Flash = FLASH_FLG1_ADDRESS;     //ĩ��ַ,������8�ı���
       ProgramDataLength=8;

       DINT;
       Example_ProgramUsingAutoECC();
       EINT;
       if(can_485_flg==1){
           DEVICE_DELAY_US(100000);//(frameSpaceTime);
       }
       SysCtl_enableWatchdog();
       while (1)
       {
          asm(" nop");
       }
   }
   if(can_485_flg==1){
       if(dataSend485_over==2){
           //DEVICE_DELAY_US(2000);   //9600bit:2000;   38400:1000
           //DEVICE_DELAY_US(frameStoRSpaceTime);
           //SysCtl_delay(4000);

           Can_Modbus.u16_can_mode=RECEIVE_MODE;
           SET_RTS_R;
           SciRegs->SCICTL1.all = 0x0021;  // ����
           SciRegs->SCICTL2.all = 0x00C2;  // ���������ж�
           dataSend485_over = 0;
       }
   }else{
       Can_Modbus.u16_can_mode=RECEIVE_MODE;
   }
}


/****************************************************************************************
** ��������:  ����������ݹ�����crcУ��
****************************************************************************************/
void Cana_Crc_Cal0x10(void)
{
    uint16 i=0;
    uint16 temp=0;

    if(Can_Modbus.u16_crc_flag == SET)                                 //crcУ�飬��λ���ձ�־λ
    {
        Can_Modbus.u16_crc_value = 0;

        for(i=0;i<Can_Modbus.u16_send_sum-3;i++)
        {
            Can_Modbus.u16_crc_value += Can_Modbus.u16_receive_buf[i];
        }

        temp = Can_Modbus.u16_send_sum - 3;
        if(Can_Modbus.u16_crc_value == GetU16(Can_Modbus.u16_receive_buf + temp))//crcУ��OK
        {
            Can_Modbus.u16_receive_data_flag = SET;
        }
        else
        {
            Boot_err.field.bit_CRC = 1;
        }
        Can_Modbus.u16_crc_flag=CLEAR;                            //���crcУ���־λ
    }
}

/****************************************************************************************
 *Function:           Canb_Data_Process����
 *Description:        CAN���ݽ��պͷ����߼��ж�
 *main��ѭ�����������̲���
****************************************************************************************/ 
void Cana_Data_Process(void)
{
    uint16 i;
    uint32 temp;
    uint32 temp1;

    Fapi_StatusType  oReturnCheck;

     if((Can_Modbus.u16_can_mode==RECEIVE_MODE)&&(Can_Modbus.u16_receive_data_flag==CLEAR))      
     {
          Cana_Crc_Cal0x10();//crcУ��
     }
     /*modbus���ݴ���*/
     if(Can_Modbus.u16_receive_data_flag ==SET)//crcУ����ȷ
     {
          switch(Can_Modbus.u16_receive_buf[3])
          {
            case 0x11:
                if(Can_Modbus.u16_receive_buf[0]==TM_ID){
                    Boot_err.u16_value = 0;
                }else{
                    Boot_err.u16_value = 1;
                }
                if(Boot_err.u16_value == 0)
                {
                    SendFrame.CANData[2] = 0x01;   //���ֳɹ��ɹ�
                }
                else
                {
                    SendFrame.CANData[2]  = 0x00;
                }
                SendFrame.CANData[3]             = 0x55;
                SendFrame.CANData[4]             = 0xAA;
                SendFrame.CANData[5]             = 0x55;
                total_iap_length = 0;
                if(Can_Modbus.u16_receive_buf[7] & 0x01)
                {
                    erase_force_flg = 1;
                }

                break;
            case 0x22:
                if(Can_Modbus.u16_receive_buf[4] == 0xFE)
                {
                    DINT;

                    Fapi_initializeAPI(FlashTech_CPU0_BASE_ADDRESS, 120);
                    oReturnCheck = Fapi_setActiveFlashBank(Fapi_FlashBank0);
                    Example_EraseSector();

                    //u16_Status = Fapi_getFsmStatus();
                    if(u16_Status != STATUS_SUCCESS)
                    {
                        SendFrame.CANData[2]  = 0x01;
                        Boot_err.field.bit_erase  = 1;
                    }
                    else
                    {
                        (*(uint8 *)0x8000) = 0;
                        (*(uint8 *)0x8001) = 0;
                        SendFrame.CANData[2] = 0x02; //�����ɹ��ɹ�
                    }
                    SendFrame.CANData[3] = 0x55;
                    SendFrame.CANData[4] = 0xAA;
                    SendFrame.CANData[5] = 0x55;

                    EINT;
                }
                break;
            case 0x33:
                for(i = 0;i<Can_Modbus.u16_receive_buf[13];i++)
                {
                     //FlashBuffer[i] = Can_Modbus.u16_receive_buf[i+14];
                    Buffer[i] =  Can_Modbus.u16_receive_buf[i+14];
                }
                for(i = 0;i<(Can_Modbus.u16_receive_buf[13]/2);i++)
                {
                    //FlashBuffer1[i] = (FlashBuffer[2 * i]<<8) + FlashBuffer[2 * i +1];
                    Buffer[i] =  (Buffer[2 * i]<<8) + Buffer[2 * i +1];
                }
                temp =(uint32)((Can_Modbus.u16_receive_buf[10]));
                temp =temp<<16;
                temp1 =(uint32)((Can_Modbus.u16_receive_buf[12]));
                temp =temp+temp1;
                temp1 =(uint32)((Can_Modbus.u16_receive_buf[11]));
                temp1 =temp1<<8;
                iap_start_adddress =temp+temp1;
                if( (iap_start_adddress >= FLASH_START_ADDRESS) &&
                   ((iap_start_adddress+Can_Modbus.u16_receive_buf[13]/2)<=FLASH_STOP_ADDRESS) )
                {
                    p_Flash = iap_start_adddress;
                    ProgramDataLength=Can_Modbus.u16_receive_buf[13]/2;

                    DINT;
                    //u16_Status = Memory_WriteDataToFlash(p_Flash,(Can_Modbus.u16_receive_buf[13]/2),&FlashBuffer1);
                    Example_ProgramUsingAutoECC();
                    EINT;
                    if (u16_Status != STATUS_SUCCESS)
                    {
                        Boot_err.field.bit_program  = 1;
                    }
                    else
                    {
                        total_iap_length +=(Can_Modbus.u16_receive_buf[13]/2);
                        SendFrame.CANData[2] = 0x03;  //д��ɹ�
                        SendFrame.CANData[3] = (total_iap_length>>16)&0x00ff;
                        SendFrame.CANData[4] = (total_iap_length>>8)&0x00ff;
                        SendFrame.CANData[5] = total_iap_length&0x00ff;
                        //SendFrame.CANData[6] = Can_Modbus.u16_receive_buf[13];
                    }
                }
                else
                {
                    Boot_err.field.bit_program = 1;
                    SendFrame.CANData[2] = 0x02;
                    SendFrame.CANData[3] = 0xFF;
                    SendFrame.CANData[4] = 0xFF;
                    SendFrame.CANData[5] = 0;
                }

                break;
            case 0x44:
                Can_Modbus.u16_last_pack_flag = SET;
                break;
            default:
                break;
        }
        SendFrame.CANId  = MODBUS_ID;
        SendFrame.CANDlc = 8;
        SendFrame.CANData[0] = Can_Modbus.u16_ctr_ID;
        SendFrame.CANData[1] = Can_Modbus.u16_softverion;
        SendFrame.CANData[6] = Boot_err.u16_value;

        Can_Modbus.u16_crc_value  = 0;
        for(i=0;i<7;i++)
        {
            Can_Modbus.u16_crc_value += SendFrame.CANData[i];
        }
        SendFrame.CANData[7]  = Can_Modbus.u16_crc_value & 0x00ff;

        if(can_485_flg==1){
            //DEVICE_DELAY_US(8000);   //8ms
            DEVICE_DELAY_US(frameSpaceTime);
            //SysCtl_delay(20000);
            /*for(temp=0;temp<55000;temp++){        //8ms
              asm("nop");
            };*/
        }
        Can_Modbus.u16_can_mode = SEND_MODE;   //��ȡ����֮�󣬽��뷢��ģʽ
        Can_Modbus.u16_receive_data_flag = CLEAR;
    }
}

/****************************************************************************************
** ��������: CRC(ʹ��ʱ�뱣����������)
****************************************************************************************/ 
uint16   Crc_Caculate(uint16 crc_temp, uint16 input_data)
{
	uint16 i = 0;

	crc_temp = crc_temp ^ input_data;

	for (i=0;i<8;i++)
	{
		if ((crc_temp & 0x0001)>0)
		{
		    crc_temp = crc_temp >> 1;
		    crc_temp = crc_temp ^ 0xa001;
		}
		else
		{
		    crc_temp = crc_temp >> 1;
		}
	}
    return(crc_temp);
}

uint16 GetU16(uint16* value)
{
    return (value[0]<<8)|
           (value[1]);
}

void  Flash_FlagProgram_Para(uint16* p_Flash, uint16* p_Array)
{

}



