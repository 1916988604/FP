/*
 * com_modbus.c
 *
 *  Created on: 2024��11��8��
 *      Author: shujixiang
 */
#ifndef SRC_APP_COM_MODBUS_C_
#define SRC_APP_COM_MODBUS_C_

#include "f280015x_device.h"
#include "device.h"
#include "board.h"
#include "Types.h"
#include "Flash_Update.h"
#include "FlashTech.h"
#include "flash_programming_f280015x.h"
#include "mcuSel.h"
#include "com_modbus.h"



volatile struct SCI_REGS *SciRegs;
extern CAN_MODBUS  Can_Modbus;
extern uint16_t txMsgData[8];

uint16 can_485_flg=0;
uint16 dataSend485_over=0;


/******���������ñ�**********************************************/
#define     BAUD_NUM_MAX    12
typedef struct
{
    Uint16 baudRate;    // _*100bps
    Uint16 high;
    Uint16 low;
} DSP_BAUD_REGISTER_DATA;

#if XTAL_PLL_FREQ==0
const unsigned int dspBaudRegData[BAUD_NUM_MAX + 1][3] =  // LSPCLK = SYSCLKOUT/2=60MHz
{
    {   3, 0x0061, 0x00A7},           //  0, 300bps
    {   6, 0x0030, 0x00D3},           //  1, 600bps
    {  12, 0x0018, 0x0069},           //  2, 1200bps
    {  24, 0x000C, 0x0034},           //  3, 2400bps
    {  48, 0x0006, 0x0019},           //  4, 4800bps
    {  96, 0x0003, 0x000C},           //  5, 9600bps
    { 192, 0x0001, 0x0085},           //  6, 19200bps
    { 384, 0x0000, 0x00c2},           //  7, 38400bps
    { 576, 0x0000, 0x0081},           //  8, 57600bps
    {1152, 0x0000, 0x0040},           //  9, 115200bps
    {1280, 0x0000, 0x0023},           // 10, 208300bps
    {2560, 0x0000, 0x001c},           // 11, 256000bps
    {5120, 0x0000, 0x000d},           // 12,512000bps
};
#elif  XTAL_PLL_FREQ==1
const unsigned int dspBaudRegData[BAUD_NUM_MAX + 1][3] =  // LSPCLK = SYSCLKOUT/2=50MHz
{
    {   3, 0x0051, 0x0060},           //  0, 300bps
    {   6, 0x0028, 0x00af},           //  1, 600bps
    {  12, 0x0014, 0x0057},           //  2, 1200bps
    {  24, 0x000a, 0x002b},           //  3, 2400bps
    {  48, 0x0005, 0x0015},           //  4, 4800bps
    {  96, 0x0002, 0x008a},           //  5, 9600bps
    { 192, 0x0001, 0x0044},           //  6, 19200bps
    { 384, 0x0000, 0x00a1},           //  7, 38400bps
    { 576, 0x0000, 0x006b},           //  8, 57600bps
    {1152, 0x0000, 0x0035},           //  9, 115200bps
    {1280, 0x0000, 0x001d},           // 10, 208300bps
    {2560, 0x0000, 0x0017},           // 11, 256000bps
    {5120, 0x0000, 0x000b},           // 12,512000bps
};
#elif   XTAL_PLL_FREQ==2
const unsigned int dspBaudRegData[BAUD_NUM_MAX + 1][3] =  // LSPCLK = SYSCLKOUT/4=30MHz
{
    {   3, 0x0030, 0x00d3},           //  0, 300bps
    {   6, 0x0018, 0x0069},           //  1, 600bps
    {  12, 0x000c, 0x0034},           //  2, 1200bps
    {  24, 0x0006, 0x0019},           //  3, 2400bps
    {  48, 0x0003, 0x000c},           //  4, 4800bps
    {  96, 0x0001, 0x0085},           //  5, 9600bps
    { 192, 0x0000, 0x00c2},           //  6, 19200bps
    { 384, 0x0000, 0x0060},           //  7, 38400bps
    { 576, 0x0000, 0x0040},           //  8, 57600bps
    {1152, 0x0000, 0x001f},           //  9, 115200bps
    {1280, 0x0000, 0x0011},           // 10, 208300bps
    {2560, 0x0000, 0x000d},           // 11, 256000bps
    {5120, 0x0000, 0x0006},           // 12,512000bps
};
#else
const unsigned int dspBaudRegData[BAUD_NUM_MAX + 1][3] =  // LSPCLK = SYSCLKOUT/4=25MHz
{
    {   3, 0x0028, 0x00af},           //  0, 300bps
    {   6, 0x0014, 0x0057},           //  1, 600bps
    {  12, 0x000a, 0x002b},           //  2, 1200bps
    {  24, 0x0005, 0x0015},           //  3, 2400bps
    {  48, 0x0002, 0x008a},           //  4, 4800bps
    {  96, 0x0001, 0x0044},           //  5, 9600bps
    { 192, 0x0000, 0x00a1},           //  6, 19200bps
    { 384, 0x0000, 0x0050},           //  7, 38400bps
    { 576, 0x0000, 0x0035},           //  8, 57600bps
    {1152, 0x0000, 0x001a},           //  9, 115200bps
    {1280, 0x0000, 0x000e},           // 10, 208300bps
    {2560, 0x0000, 0x000b},           // 11, 256000bps
    {5120, 0x0000, 0x0005},           // 12,512000bps
};
#endif



void f_rs485_ComInit()
{
#if sci_numeber_Mod==0    //
    SciRegs = &SciaRegs;
#elif sci_numeber_Mod==1    //
    SciRegs = &ScibRegs;
#else
    SciRegs = &ScicRegs;
#endif

    EALLOW;
    SciRegs->SCICTL1.all = 0;       //SCIϵͳ��λʱ,�ָ���ʼ״̬
    SciRegs->SCICCR.all = 0x0007;   // 1ֹͣλ������żУ��λ����LOOPBACKģʽ��idleѡ��8λ�ַ�
    SciRegs->SCIPRI.bit.FREESOFT = 1;       //����������ʱ��SCI��������

    //9600bit/s
    baudrate = 5;
    SciRegs->SCIHBAUD.all = dspBaudRegData[baudrate][1];//2;      //2;   //50000000/((0x28a+1)*8) = 50000000/((650+1)*8) = 50000000/5208 = 9600
    SciRegs->SCILBAUD.all = dspBaudRegData[baudrate][2];//0x8a;   //0x8A;
    //38400bit/s
    /*SciRegs->SCIHBAUD.all = 0;
    SciRegs->SCILBAUD.all = 0xa1; //38400  */
    frameSpaceTime = (Uint16)(385.0*1745.0/dspBaudRegData[baudrate][0])+250;   // 3.5 char time=3.5*(1+8+2)/baud
    frameStoRSpaceTime = (Uint16)(385.0*249.0/dspBaudRegData[baudrate][0])+750;

    SciRegs->SCICTL1.all = 0x0021;  // ����
    SciRegs->SCICTL2.all = 0x0002;  // ���������ж�

#if sci_numeber_Mod!=2
    GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 0;
    GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 0;
    GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;
    GpioDataRegs.GPADAT.bit.GPIO28 = 0;   //DE: 0--receiver;1--transmit
    GpioCtrlRegs.GPADIR.bit.GPIO28 = 1;   //output
    SET_RTS_R;  // RTS��Ϊ����
#endif
#if sci_numeber_Mod==2
    PieVectTable.SCIC_TX_INT =  &SCI_TXD_isr;
    PieVectTable.SCIC_RX_INT =  &SCI_RXD_isr;
    PieCtrlRegs.PIEIER8.bit.INTx5 = 1;
    PieCtrlRegs.PIEIER8.bit.INTx6 = 1;
    IER |= M_INT8;                  //  Enable interrupts:
#elif sci_numeber_Mod==0
    PieVectTable.SCIA_TX_INT =  &SCI_TXD_isr;
    PieVectTable.SCIA_RX_INT =  &SCI_RXD_isr;
    PieCtrlRegs.PIEIER9.bit.INTx1 = 1;
    PieCtrlRegs.PIEIER9.bit.INTx2 = 1;
    IER |= M_INT9;                  //  Enable interrupts:
#else
    PieVectTable.SCIB_TX_INT =  &SCI_TXD_isr;
    PieVectTable.SCIB_RX_INT =  &SCI_RXD_isr;

    /*SET_RTS_T;  // RTS��Ϊ����
    ScibRegs.SCICTL1.all = 0x0022;  // ����
    ScibRegs.SCICTL2.all = 0x00C1;  // ���������ж�
    txMsgData[0]=1;
    txMsgData[1]=2;
    txMsgData[2]=3;
    txMsgData[3]=4;
    txMsgData[4]=5;
    txMsgData[5]=6;
    txMsgData[6]=7;
    txMsgData[7]=8;
    SciRegs->SCITXBUF.all = txMsgData[0];*/

    PieCtrlRegs.PIEIER9.bit.INTx3 = 1;
    PieCtrlRegs.PIEIER9.bit.INTx4 = 1;
    IER |= M_INT9;                  //  Enable interrupts:

#endif
    EDIS;
}

interrupt void SCI_RXD_isr(void)
{
    Can_Modbus.u16_receive_buf[Can_Modbus.u16_receive_ptr] = SciRegs->SCIRXBUF.all;

    /*if(commTicker > frameSpaceTime){
        Can_Modbus.u16_receive_buf[0] = SciRegs->SCIRXBUF.all;
    }else*/{
        if(Can_Modbus.u16_receive_data_flag == CLEAR){
            Can_Modbus.u16_receive_ptr++;
            if(Can_Modbus.u16_receive_ptr>2){
                if((Can_Modbus.u16_receive_buf[1] != Can_Modbus.u16_softverion))//�����汾����
                {
                      Can_Modbus.u16_receive_ptr=0;
                      Can_Modbus.u16_crc_value = 0;
                }else if((Can_Modbus.u16_receive_buf[0] != Can_Modbus.u16_ctr_ID))//�������ͺŲ���
                {
                      Can_Modbus.u16_receive_ptr=0;
                      Can_Modbus.u16_crc_value = 0;
                }
                else
                {
                       Can_Modbus.u16_send_sum = Can_Modbus.u16_receive_buf[2]; //�ܵ����ݳ���
                }
            }

            if(Can_Modbus.u16_receive_ptr>=Can_Modbus.u16_send_sum)
            {
                 Can_Modbus.u16_receive_ptr=0;
                 Can_Modbus.u16_crc_value = 0;

                 if(Can_Modbus.u16_receive_buf[Can_Modbus.u16_send_sum-1] == 0xFF)
                 {
                     Can_Modbus.u16_crc_flag = SET;
                     can_485_flg = 1;
                 }
                 else
                 {
                     Can_Modbus.u16_crc_value = 0;
                 }
            }
        }else{
            Can_Modbus.u16_receive_ptr=0;
            Can_Modbus.u16_crc_value = 0;
        }
    }

    commTicker=0;
#if sci_numeber_Mod==2
    PieCtrlRegs.PIEACK.bit.ACK8 = 1;    // Issue PIE ACK
#else
    PieCtrlRegs.PIEACK.bit.ACK9 = 1;    // Issue PIE ACK
#endif
}


interrupt void SCI_TXD_isr(void)
{
    static uint16 i=1;

    if(i==8){
        i=1;
        dataSend485_over=2;
    }else{
        dataSend485_over=1;
        SciRegs->SCITXBUF.all = txMsgData[i];
        i++;
    }

#if sci_numeber_Mod==2
    PieCtrlRegs.PIEACK.bit.ACK8 = 1;    // Issue PIE ACK
#else
    PieCtrlRegs.PIEACK.bit.ACK9 = 1;    // Issue PIE ACK
#endif
}


#endif
