
//aiģ�������ݶ�ȡ��DI���ݶ�ȡ

#ifndef SRC_APP_ADI_C_
#define SRC_APP_ADI_C_

#include "app_include.h"

/**********************************************************************/
//���������
   //aiDeal��  ---���ư�AD����
   //pwmDuTy�� ---���ư�inputPWM
   //temperature ---���ư��¶ȼ��
   //u_speed_canfd�� ---���ư�CANFDͨѶ
   //u_speed_can�� ---���ư�CANͨѶ
   //u_speed_lin�� ---���ư�LINͨѶ
   //u_sci_enable ---���ư�ͨѶʹ��λ
//���������
    //sysSci_mode.mode  ---�԰����ģʽ

//����źţ�
   //u_enable_exsci��  ---ͨѶʹ��λ
   //u_speed_exsci��   ---ͨѶ�ٶ�����
   //sys_param.mode   ---ģʽ�������

/**********************************************************************/

LowPassFilter aiLpf[7] = {LPF_DEFALUTS, LPF_DEFALUTS, LPF_DEFALUTS, LPF_DEFALUTS, LPF_DEFALUTS, LPF_DEFALUTS, LPF_DEFALUTS};

// PT100�Ĳ�������DSP������ѹ���¶ȵĶ�Ӧ��ϵ��
const Uint16 voltageTempPT100[] =
{// ��ѹmV      �¶ȡ�
    0       ,   //  0
    162     ,   //  4
    325     ,   //  8
    487     ,   //  12
    648     ,   //  16
    810     ,   //  20
    971     ,   //  24
    1132    ,   //  28
    1292    ,   //  32
    1453    ,   //  36
    1613    ,   //  40
    1773    ,   //  44
    1932    ,   //  48
    2091    ,   //  52
    2250    ,   //  56
    2409    ,   //  60
    2567    ,   //  64
    2725    ,   //  68
    2883    ,   //  72
    3041    ,   //  76
    3198    ,   //  80
    3355    ,   //  84
    3511    ,   //  88
    3668    ,   //  92
    3824    ,   //  96
    3980    ,   //  100
    4135    ,   //  104
    4290    ,   //  108
    4444    ,   //  112
    4599    ,   //  116
    4754    ,   //  120
    4908    ,   //  124
    5061    ,   //  128
    5215    ,   //  132
    5368    ,   //  136
    5521    ,   //  140
    5674    ,   //  144
    5827    ,   //  148
    5979    ,   //  152
    6130    ,   //  156
    6282    ,   //  160
    6433    ,   //  164
    6584    ,   //  168
    6735    ,   //  172
    6886    ,   //  176
    7036    ,   //  180
    7186    ,   //  184
    7336    ,   //  188
    7485    ,   //  192
    7634    ,   //  196
    7784    ,   //  200
};

// PT1000�Ĳ�������DSP������ѹ���¶ȵĶ�Ӧ��ϵ��
const Uint16 voltageTempPT1000[] =
{// ��ѹmV      �¶ȡ�
    0       ,   //  0
    163     ,   //  4
    325     ,   //  8
    487     ,   //  12
    649     ,   //  16
    810     ,   //  20
    971     ,   //  24
    1132    ,   //  28
    1293    ,   //  32
    1453    ,   //  36
    1613    ,   //  40
    1773    ,   //  44
    1932    ,   //  48
    2091    ,   //  52
    2250    ,   //  56
    2409    ,   //  60
    2567    ,   //  64
    2725    ,   //  68
    2883    ,   //  72
    3040    ,   //  76
    3197    ,   //  80
    3354    ,   //  84
    3511    ,   //  88
    3667    ,   //  92
    3823    ,   //  96
    3979    ,   //  100
    4134    ,   //  104
    4290    ,   //  108
    4445    ,   //  112
    4599    ,   //  116
    4754    ,   //  120
    4908    ,   //  124
    5062    ,   //  128
    5215    ,   //  132
    5368    ,   //  136
    5521    ,   //  140
    5674    ,   //  144
    5826    ,   //  148
    5979    ,   //  152
    6130    ,   //  156
    6282    ,   //  160
    6433    ,   //  164
    6584    ,   //  168
    6735    ,   //  172
    6886    ,   //  176
    7036    ,   //  180
    7186    ,   //  184
    7336    ,   //  188
    7485    ,   //  192
    7634    ,   //  196
    7783    ,   //  200
};
// NTC10K�Ĳ�������DSP������ѹ���¶ȵĶ�Ӧ��ϵ��
const Uint16 voltageTempNTC10K[] =
{// ��ѹmV      �¶ȡ�
     90  ,   //  180
     97  ,   //  176
     105 ,   //  172
     113 ,   //  168
     123 ,   //  164
     133 ,   //  160
     145 ,   //  156
     157 ,   //  152
     171 ,   //  148
     186 ,   //  144
     203 ,   //  140
     222 ,   //  136
     243 ,   //  132
     266 ,   //  128
     291 ,   //  124
     320 ,   //  120
     351 ,   //  116
     387 ,   //  112
     426 ,   //  108
     469 ,   //  104
     518 ,   //  100
     571 ,   //  96
     631 ,   //  92
     697 ,   //  88
     771 ,   //  84
     851 ,   //  80
     941 ,   //  76
     1038    ,   //  72
     1145    ,   //  68
     1261    ,   //  64
     1386    ,   //  60
     1520    ,   //  56
     1662    ,   //  52
     1812    ,   //  48
     1969    ,   //  44
     2130    ,   //  40
     2295    ,   //  36
     2460    ,   //  32
     2625    ,   //  28
     2785    ,   //  24
     2940    ,   //  20
     3087    ,   //  16
     3224    ,   //  12
     3351    ,   //  8
     3465    ,   //  4
     3568    ,   //  0
     3658    ,   //  -4
     3736    ,   //  -8
     3804    ,   //  -12
     3861    ,   //  -16
     3908    ,   //  -20
     3948    ,   //  -24
     3980    ,   //  -28
     4006    ,   //  -32
     4027    ,   //  -36
     4043    ,   //  -40
};

void AiCalc_init(void)
{
    unsigned int i;

    for(i=0;i<7;i++)
    {
        u_speed_vi[i] = 0;
        aiLpf[i].out = 0;
        aiDeal[i] = 0;
    }
    aiFilterTime[0] = 0.05;
    aiFilterTime[1] = 0.05;
    aiFilterTime[2] = 0.05;
    aiFilterTime[3] = 0.05;
    aiFilterTime[4] = 0.01;
    aiFilterTime[5] = 0.05;//0.125;  //�����˲�
    aiFilterTime[6] = 0.05;  //�ߵ�ѹ�˲�
    temoSensorType = NTC10K;
    temoSensorExType = NTC10K;

    u16_DI2_sta = 0;
    u16_DI3_sta = 0;
    f_speed_gear = 0;
    u_speed_can = 0;    //���ư��ź�

#if USER_MOTOR1== FPUN600_motor
   vcu_speedDirCmd = -1;    //������ῴ��˳ʱ��
#else
    vcu_speedDirCmd = -1;
#endif
    u_speed_canfd = 0;
    u_speed_lin = 0;
    u_speed_exsci = 0;
    u_enable_exsci = 0;
    modeNightFlg=0;

    ai_vol_E = 1.0;
    ai_vol_F = 9.0;
    ai_vol_G = 8.5;

    tempValue_set = 25;
    tempDifValue_set = 25;
    tempSoruceSel = TEMP_IN;
    sysSoruceSel = HEAT;
}

//�¶�1
void Ai1Calc(void)
{
    aiLpf[0].t = aiFilterTime[0]; // �˲�ϵ��
    aiLpf[0].in = aiDeal[0];      //AD����ֵ
    aiLpf[0].calc(&aiLpf[0]);
    GetTemperature();
    u_speed_vi[0] = temperature;//aiLpf[0].out;
}

//�¶�2
void Ai2Calc(void)
{
    aiLpf[1].t = aiFilterTime[1]; // �˲�ϵ��
    aiLpf[1].in = aiDeal[1];      //AD����ֵ
    aiLpf[1].calc(&aiLpf[1]);
    GetTempMediumEx();
    u_speed_vi[1] = tempeMediumEx;
}

//0-10V
void Ai3Calc(void)
{
    aiLpf[2].t = aiFilterTime[2]; //�˲�ϵ��
    aiLpf[2].in = aiDeal[2];      //AD����ֵ
    aiLpf[2].calc(&aiLpf[2]);
    if(ai1InMode == AI_VI){   //0-10V
        u_speed_vi[2] = aiLpf[2].out * 0.003546;
    }else if(ai1InMode == AI_HEAD){ //ѹ��
        u_speed_vi[2] = aiLpf[2].out;
    }else{  //����
        u_speed_vi[2] = aiLpf[2].out;
    }
}

//4-20mA
void Ai4Calc(void)
{
    aiLpf[3].t = aiFilterTime[3]; // �˲�ϵ��
    aiLpf[3].in = aiDeal[3];      //AD����ֵ
    aiLpf[3].calc(&aiLpf[3]);
    if(ai2InMode == AI_VI){   //4-20mA
        u_speed_vi[3] = aiLpf[3].out * 0.005372;
    }else if(ai2InMode == AI_HEAD){ //ѹ��
        u_speed_vi[3] = aiLpf[3].out;
    }else{ //����
        u_speed_vi[3] = aiLpf[3].out;
    }
}

//ѹ��
void Ai5Calc(void)
{
    float f_temp;
    aiLpf[4].t = aiFilterTime[4]; // �˲�ϵ��
    aiLpf[4].in = aiDeal[4];      //AD����ֵ
    aiLpf[4].calc(&aiLpf[4]);
    f_temp = aiLpf[4].out;
    f_temp = (f_temp*5.0/3.3-0.5)*1000/16.0;    //0.1m
    if(f_temp < 0){
        f_temp = 0;
    }
    sys_param.headSensor = (Uint16)f_temp;
}

//����
void Ai6Calc(void)
{
    float f_temp;
    aiLpf[5].t = aiFilterTime[5]; // �˲�ϵ��
    aiLpf[5].in = outpower;
    aiLpf[5].calc(&aiLpf[5]);
    f_temp = outpower;//aiLpf[5].out;
    motorPwr_Lpf = f_temp;
}

//�ߵ�ѹ
void Ai7Calc(void)
{
    float f_temp;
    aiLpf[6].t = aiFilterTime[6]; // �˲�ϵ��
    aiLpf[6].in = Temp_IGBT.V_LN;
    aiLpf[6].calc(&aiLpf[6]);
    f_temp = aiLpf[6].out;
    Temp_IGBT.V_LN_Lpf = Temp_IGBT.V_LN;//f_temp;
}

void DiStatus(void)
{
    static int di1cnt_L=0,di1cnt_H=0;
    static int di2cnt_L=0,di2cnt_H=0;
    static int di3cnt_L=0,di3cnt_H=0;

    if(GPIO_readPin(K1_DI)==0){
        di1cnt_L = 0;
        di1cnt_H++;
        if(di1cnt_H>3){
            di1cnt_H=3;
            u16_DI1_sta = 1;
        }
    }else{
        di1cnt_H = 0;
        di1cnt_L++;
        if(di1cnt_L>3){
            di1cnt_L=3;
            u16_DI1_sta = 0;
        }
    }

    if(GPIO_readPin(K2_DI)==0){
        di2cnt_L = 0;
        di2cnt_H++;
        if(di2cnt_H>3){
            di2cnt_H=3;
            u16_DI2_sta = 1;
        }
    }else{
        di2cnt_H = 0;
        di2cnt_L++;
        if(di2cnt_L>3){
            di2cnt_L=3;
            u16_DI2_sta = 0;
        }
    }

    if(GPIO_readPin(K3_DI)==0){
        di3cnt_L = 0;
        di3cnt_H++;
        if(di3cnt_H>3){
            di3cnt_H=3;
            u16_DI3_sta = 1;
        }
    }else{
        di3cnt_H = 0;
        di3cnt_L++;
        if(di3cnt_L>3){
            di3cnt_L=3;
            u16_DI3_sta = 0;
        }
    }
}

//10MS
void adi_Ctrl(void)
{
    static float temperature_old[11]={0,0,0,0,0,0,0,0,0,0,0};
    static Uint32 tempTime=0;
    static Uint16 enable = 0,speed = 0;
    static Uint16 mode=AUTO;
    Uint16 i;
    LINE_STRUCT aiLine = LINE_STRTUCT_DEFALUTS;
    static Uint16 speedTemp = 0,speedTempCnt=0;
    float tempera_ctrl;

    static Uint32 u_DpumpTime=0;

    if(u16_DI1_sta==0){
        enable = 0;
    }/*else if(u_enable_HandC == 0){
        enable = 0;
    }*/else{
        if(sys_param.mode > LIN_GEAR){
            enable = 1;
            speed = SPD_MAX;
        }else{
            mode = sys_param.mode;
        }

        if((mode != HTEMP_I)||(mode != HTDIFF_I)){
            speedTemp = 0;
            speedTempCnt = 0;
        }

        if(u16_DI2_sta == 1){
            speed = SPD_MAX;
            enable = 1;
        }else if(u_ctrl_logic.bit.spdMaxEn==1){
            speed = SPD_MAX;
            enable = 1;
        }else if(u16_DI3_sta==1){
            speed = SPD_MIN;
            enable = 1;
        }else if(u_ctrl_logic.bit.spdMinEn==1){
            enable = 1;
            speed = SPD_MIN;
        }else if((mode == AUTO) || (mode == AUTOLIMIT) || (mode == HS_I) || \
                (mode == HD_I) || (mode == BL_I) || (mode == HL_I)){
            enable = 1;
            speed = u_speed_HandC;
        }else if( (mode == HTEMP_I) || (mode == HTDIFF_I) ){
            if(tempSoruceSel == TEMP_IN){
                tempera_ctrl = temperature;
            }else if(tempSoruceSel == TEMP_EXT){
                tempera_ctrl = tempeMediumEx;
            }else{
                tempera_ctrl = temperature - tempeMediumEx;
            }
            if( (sysSoruceSel == HEAT) && ((tempSoruceSel == TEMP_IN) || (tempSoruceSel == TEMP_DIFF)) ){
                if(tempera_ctrl < (tempValue_set-3)){
                    speedTemp++;
                }else if(tempera_ctrl < (tempValue_set-1)){
                    speedTempCnt++;
                    if(speedTempCnt>100){
                        speedTempCnt = 0;
                        speedTemp++;
                    }
                }else if(tempera_ctrl > tempValue_set){
                    speedTempCnt++;
                    if(speedTempCnt>100){   //10s
                        speedTempCnt = 0;
                        speedTemp--;
                    }
                }
            }else{
                if(tempera_ctrl > (tempValue_set+3)){
                    speedTemp--;
                }else if(tempera_ctrl > (tempValue_set+1)){
                    speedTempCnt++;
                    if(speedTempCnt>100){
                        speedTempCnt = 0;
                        speedTemp--;
                    }
                }else if(tempera_ctrl < tempValue_set){
                    speedTempCnt++;
                    if(speedTempCnt>100){   //10s
                        speedTempCnt = 0;
                        speedTemp++;
                    }
                }
            }
            if(speedTemp > SPD_MAX){
                speedTemp = SPD_MAX;
            }else if(speedTemp < SPD_MID){
                speedTemp = SPD_MID;
            }
            speed = speedTemp;
            enable = 1;
        }else if(mode == VOL_GEAR){
            if(u_ctrl_logic.bit.ai2_ctrlDir==AI_A){
                aiLine.mode = 0;
                aiLine.x1 = 1.0;
                aiLine.y1 = SPD_MAX;
                aiLine.x2 = 8.0;
                aiLine.y2 = SPD_MIN;
                aiLine.x = u_speed_vi[2];
                if(u_speed_vi[2] > 9.0){
                    enable = 0;
                }else if(u_speed_vi[2] < 8.5){
                    enable = 1;
                }
            }else if(u_ctrl_logic.bit.ai2_ctrlDir==AI_B){
                aiLine.mode = 0;
                aiLine.x1 = 1.0;
                aiLine.y1 = SPD_MAX;
                aiLine.x2 = 8.0;
                aiLine.y2 = SPD_MIN;
                aiLine.x = u_speed_vi[2];
                enable = 1;
            }else if(u_ctrl_logic.bit.ai2_ctrlDir==AI_C){
                aiLine.mode = 0;
                aiLine.x1 = 2.0;
                aiLine.y1 = SPD_MIN;
                aiLine.x2 = 10.0;
                aiLine.y2 = SPD_MAX;
                aiLine.x = u_speed_vi[2];
                if(u_speed_vi[2] > 1.5){
                    enable = 1;
                }else if(u_speed_vi[2] < 1.0){
                    enable = 0;
                }
            }else{
                aiLine.mode = 0;
                aiLine.x1 = 2.0;
                aiLine.y1 = SPD_MIN;
                aiLine.x2 = 10.0;
                aiLine.y2 = SPD_MAX;
                aiLine.x = u_speed_vi[2];
                enable = 1;
            }
            aiLine.calc(&aiLine);
            speed = (Uint16)aiLine.y;
            if(speed<SPD_MID){
                speed = SPD_MID;
            }
        }else if(mode == CUR_GEAR){
            if(u_ctrl_logic.bit.ai3_ctrlDir==AI_A){
                aiLine.mode = 0;
                aiLine.x1 = 2.0;
                aiLine.y1 = SPD_MAX;
                aiLine.x2 = 16.0;
                aiLine.y2 = SPD_MIN;
                aiLine.x = u_speed_vi[3];
                if(u_speed_vi[3] > 18.0){
                    enable = 0;
                }else if(u_speed_vi[3] < 17.0){
                    enable = 1;
                }
            }else if(u_ctrl_logic.bit.ai3_ctrlDir==AI_B){
                aiLine.mode = 0;
                aiLine.x1 = 2.0;
                aiLine.y1 = SPD_MAX;
                aiLine.x2 = 16.0;
                aiLine.y2 = SPD_MIN;
                aiLine.x = u_speed_vi[3];
                enable = 1;
            }else if(u_ctrl_logic.bit.ai3_ctrlDir==AI_C){
                aiLine.mode = 0;
                aiLine.x1 = 4.0;
                aiLine.y1 = SPD_MIN;
                aiLine.x2 = 20.0;
                aiLine.y2 = SPD_MAX;
                aiLine.x = u_speed_vi[3];
                if(u_speed_vi[3] > 3.0){
                    enable = 1;
                }else if(u_speed_vi[3] < 2.0){
                    enable = 0;
                }
            }else{
                aiLine.mode = 0;
                aiLine.x1 = 4.0;
                aiLine.y1 = SPD_MIN;
                aiLine.x2 = 20.0;
                aiLine.y2 = SPD_MAX;
                aiLine.x = u_speed_vi[3];
                enable = 1;
            }
            aiLine.calc(&aiLine);
            speed = (Uint16)aiLine.y;
            if(speed<SPD_MID){
                speed = SPD_MID;
            }
        }else if(mode == PWM_GEAR){
            enable = pwmInEnable;
            speed = pwmInSpdRef;
        }else if(mode == MODBUS_GEAR){
            enable = u_sci_enable.bit.e485_enable;
            speed = u_speed_e485;
        }else if(mode == CAN_GEAR){
            enable = u_sci_enable.bit.can_enable;
            speed = u_speed_can;
        }else if(mode == LIN_GEAR){
            enable = u_sci_enable.bit.lin_enable;
            speed = u_speed_lin;
        }else if(mode == CANFD_GEAR){
            enable = u_sci_enable.bit.canfd_enable;
            speed = u_speed_canfd;
        }else{
            enable = 1;
            speed = SPD_MAX;
            mode = HS_I;
        }
    }

/*********************************************/

/**ҹ��ģʽ************************************************************************************************/
    tempTime++;     //2Сʱ�ڣ��¶Ƚ���10-15��
    if(tempTime<2){
        for(i=0;i<10;i++){
            temperature_old[i] = temperature;
        }
    }else{
        if(tempTime > 72000){       //72000*10=720000; 2*60*60*1000=7200000
            for(i=0;i<9;i++){
                temperature_old[i] = temperature_old[i+1];
            }
            temperature_old[9] = temperature;
            tempTime = 100;
        }
    }
    if((u_ctrl_logic.bit.night_ctrlMode==1) && ((mode == AUTO) || (mode == AUTOLIMIT) || (mode == HD_I)||(mode == BL_I) || (mode == HL_I)) ){
        if((temperature_old[9] - temperature_old[0]) < -12){
            modeNightFlg = 1;
        }else if((temperature_old[9] - temperature_old[0]) > 12){
            modeNightFlg = 0;
        }
    }else{
        modeNightFlg = 0;
    }
/****************************************************/
    if(modeNightFlg == 1){
        sysSci_mode.mode = HS_I;
        u_speed_exsci = SPD_MIN;
        u_enable_exsci = enable;
    }else{
        u_speed_exsci = speed;
        u_enable_exsci = enable;
        if((mode == AUTO) || (mode == AUTOLIMIT) || (mode == HS_I) || (mode == HD_I) || (mode == BL_I) ||(mode == HL_I)){
            sysSci_mode.mode = mode;
        }else{
            sysSci_mode.mode = HS_I;
        }
    }

//˫ͷ���߼�
    u_DpumpTime++;
    if((sysSci_mode.mode != HS_I)||(u_enable_exsci==0)){
        if(u_DpumpTime>0){
            u_DpumpTime--;
        }
    }else if(u_DpumpMode_HtoC == SINGLE){     //��ͷ��
        mas_sla_sel_sci = SLAVE;
        u_DpumpTime = 0;
    }else{
        if(sci_motor_fault != 0){
            sci_motor_spdCmd = u_speed_exsci;
            sci_motor_GearCmd = 1;
        }else if(u_DpumpMode_HtoC == D_ALTER){  //˫ͷ�ã��滻����  //24Сʱ=24*60*60*1000/10=8640000
            mas_sla_sel_sci = MASTER;
            if(u_DpumpTime > 17280000){         //24Сʱ����
                sci_motor_GearCmd = 0;
                u_DpumpTime = 0;
            }else if(u_DpumpTime > 8640000){    //24Сʱͣ��
                sci_motor_GearCmd = u_enable_exsci;
            }
            sci_motor_spdCmd = u_speed_exsci;
        }else if(u_DpumpMode_HtoC == D_BACKUP){ //˫ͷ�ã���������
            mas_sla_sel_sci = MASTER;
            if(u_DpumpTime > 8700000){  //����10min
                sci_motor_GearCmd = 0;
                u_DpumpTime = 0;
            }else if(u_DpumpTime > 8640000){    //24Сʱ�ȴ�
                sci_motor_GearCmd = u_enable_exsci;
            }
            sci_motor_spdCmd = u_speed_exsci;
        }else{      //˫ͷ�ã���������
            mas_sla_sel_sci = MASTER;
            if(u_speed_exsci>900){
                sci_motor_GearCmd = u_enable_exsci;
            }else if(u_speed_exsci<500){
                sci_motor_GearCmd = 0;
            }
            sci_motor_spdCmd = u_speed_exsci;
        }
    }
}

//========================================================================
// ����¶�ֵ
//========================================================================
void GetTemperature()
{
    const Uint16 *p;
    Uint16 size;

// �¶ȴ���������
    if (temoSensorType == PTC100)
    {
        p = voltageTempPT100;
        size = sizeof(voltageTempPT100);
    }
    else if (temoSensorType == PTC1000)
    {
        p = voltageTempPT1000;
        size = sizeof(voltageTempPT1000);
    }else if (temoSensorType == NTC10K)
    {
        p = voltageTempNTC10K;
        size = sizeof(voltageTempNTC10K);
    }else{
        p = voltageTempNTC10K;
        size = sizeof(voltageTempNTC10K);
    }

    temperature = GetTemperatureCalc(aiLpf[0].out, p, size, 0);
}

void GetTempMediumEx()
{
    const Uint16 *p;
    Uint16 size;

    // �¶ȴ���������
    if (temoSensorExType == NTC10K)
    {
        p = voltageTempNTC10K;
        size = sizeof(voltageTempNTC10K);
    }else{
        p = voltageTempNTC10K;
        size = sizeof(voltageTempNTC10K);
    }

    tempeMediumEx = GetTemperatureCalc(aiLpf[1].out, p, size, 1);
}
// ���ݲ�����ѹ����ѹ���¶ȵĶ�Ӧ��ϵ��������¶�
float GetTemperatureCalc(float voltage, const Uint16 *p, Uint16 len, Uint16 sensorSel)
{
    int16 i;
    LINE_STRUCT temperatureLine = LINE_STRTUCT_DEFALUTS;
    Uint16 Sel;

    for (i = 1; i < len; i++)
    {
        if (voltage < *(p + i))
            break;
    }
    if (i >= len)  // ��������
    {
        i = len - 1;
    }

    temperatureLine.mode = 0;
    temperatureLine.x1 = *(p + i - 1);
    temperatureLine.x2 = *(p + i);
    if(sensorSel==0){
        Sel = temoSensorType;
    }else if(sensorSel==1){
        Sel = temoSensorExType;
    }else if(sensorSel==2){
        Sel = CRM60;
    }else{
        Sel = DPM15C60DG1;
    }
    if (Sel == NTC10K){
        temperatureLine.y1 = -4 * (i - 1) + 180;
        temperatureLine.y2 = -4 * i + 180;
    }else{
        temperatureLine.y1 = (i - 1) * 4;
        temperatureLine.y2 = i * 4;
    }
    temperatureLine.x = voltage;
    temperatureLine.calc(&temperatureLine);

    return (temperatureLine.y);
}


//=====================================================================
// ��ͨ�˲�������
//=====================================================================
void LpfCalc(LowPassFilter *p)
{
    if (p->t < 0.001)
    {
        p->out = p->in;
    }
    else
    {
        p->out = p->in * p->t + p->outOld * (1-p->t);
        p->outOld = p->out;
    }
}

void LineCalc(LINE_STRUCT *p)
{
    float tmp;

    tmp=((p->x - p->x1)/(p->x2 - p->x1))*(p->y2 - p->y1)+p->y1;

    // ��x1 < x2. ��x > x1, y = y2; ��x <= x1, y = y1.
    if((p->mode == 2) && (p->x < p->x1))    // �޷��ҵ�������ʱΪ0
        p->y = 0;
    else if (p->x <= p->x1)
        p->y = p->y1;
    else if (p->x >= p->x2)
        p->y = p->y2;
    else
        p->y = tmp;

    if (p->mode == 1)    // 1����ʾ���޷�
        p->y = tmp;

}


#endif


