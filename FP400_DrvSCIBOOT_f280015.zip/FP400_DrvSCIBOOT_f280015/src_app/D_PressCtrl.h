#ifndef APP_PRESS_H_
#define APP_PRESS_H_





#ifdef  APP_PRESSCTRL_C
    #define APP_PRESSCTR
#else
    #define APP_PRESSCTR  extern
#endif
APP_PRESSCTR    void  f_pressCtrl_Init(void);
APP_PRESSCTR    void  f_pressCtrl(void);
APP_PRESSCTR    void  PID_Ctrl_int(void);

APP_PRESSCTR    int s16_temper_medium;
APP_PRESSCTR    unsigned int u16_press,u16_pressCmdHMI,u16_pressCmd;
APP_PRESSCTR    unsigned int u16_pressCtrlEn,u16_SCI_CtrlEn,u16_SCI_FreezeEn,u16_StopCtrlFlg,u16_display_ver;
APP_PRESSCTR    unsigned int u16_runStopCnt,u16_runPressOLcnt,u16_runStop2Cnt,su_distDir,su_distCnt;
APP_PRESSCTR    unsigned long   u16_runSelfPrimecnt;
APP_PRESSCTR    unsigned int u16_SelPrimeFlg;
APP_PRESSCTR    unsigned int u16_tmpSensorErrFlg;
APP_PRESSCTR    unsigned int u16_spdBackFlg;
APP_PRESSCTR    unsigned int u16_antiFreezeFlg;
#endif
