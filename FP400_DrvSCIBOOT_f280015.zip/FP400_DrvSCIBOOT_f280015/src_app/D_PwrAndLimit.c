#ifndef	APP_PWRANDLIMIT_C_
#define	APP_PWRANDLIMIT_C_

#include "app_include.h"

float iq_limitData=1.3;
float iq_k_data=1.0;
unsigned int temp_medFlg=0; //400w

extern volatile MOTOR_Vars_t motorVars_M1;
extern float vs_pwrBAK,iq_pwrBAK,vs_pwr,iq_pwr;
void powerAndLmtInit()
{
	sPID_pwrLmt.kp = 0.1;			//kp
	sPID_pwrLmt.ki = 0.005;			//ki
	sPID_pwrLmt.integral_sum = 0;	//������
	sPID_pwrLmt.out_value = 0;
	sPID_pwrLmt.integral_max = 500;		//���������ֵ��500RPM
	outpower = 0;		//���㹦��

	sPID_pwrLmt.power_max = MAX_POWER;  //1200;		//�����趨���ֵ��1200w
	sPID_pwrLmt.outlimit_upper = SPEED_MAX; //3500;	//������ֵ��3500rpm
	sPID_pwrLmt.outlimit_lower = 0;

	//outpowerCal_k = 0.8;
	outpowerCal_k = 4.05621699736;//1.541362459;   //3.1;//3;//2.8 * 1.05;
}

//250ms
void powerCal()
{
	float temp,temp2,tempId,tempIq,tempVd,tempVq;
    static float f_power[8]={0,0,0,0,0,0,0,0};
    static unsigned int cntPwrCal=0;
    static float sf_temp=0;

    //���ݵ�ѹ�����������
    /*if(motorPwr_Lpf < 300){
        objUser->maxCurrent_A = 1.8;
        motorHandle_M1->maxCurrent_A = 1.8;
    }else*/ /*if(Temp_IGBT.V_LN_Lpf > 240){
        objUser->maxCurrent_A = USER_MOTOR1_MAX_CURRENT_A;
        motorHandle_M1->maxCurrent_A = USER_MOTOR1_MAX_CURRENT_A;
    }else if(Temp_IGBT.V_LN_Lpf < 180){
        objUser->maxCurrent_A = 1.0;
        motorHandle_M1->maxCurrent_A = 1.0;
    }else if(Temp_IGBT.V_LN_Lpf < 200){
        objUser->maxCurrent_A = 1.2;
        motorHandle_M1->maxCurrent_A = 1.2;
    }else{
        objUser->maxCurrent_A = USER_MOTOR1_MAX_CURRENT_A;
        motorHandle_M1->maxCurrent_A = USER_MOTOR1_MAX_CURRENT_A;
    }*/

    //����ĸ�ߵ�ѹ��������������
    LINE_STRUCT iqK_UlnLimit = LINE_STRTUCT_DEFALUTS;
    iqK_UlnLimit.mode=0;
    iqK_UlnLimit.x = fabsf(Temp_IGBT.V_LN_Lpf);//motorVars_M1.adcData.VdcBus_V);
    iqK_UlnLimit.y1 = 1.1;
    iqK_UlnLimit.y2 = 0.8;
    iqK_UlnLimit.x1 = 200;
    iqK_UlnLimit.x2 = 280;
    iqK_UlnLimit.calc(&iqK_UlnLimit);
    temp = iqK_UlnLimit.y;

    if(s16_temper_medium > 30 ){
        temp_medFlg=1;
    }else if(s16_temper_medium < 25){
        temp_medFlg=0;
    }

    //temp_medFlg=0;//400W
    LINE_STRUCT iq_k = LINE_STRTUCT_DEFALUTS;
    LINE_STRUCT iqLimit = LINE_STRTUCT_DEFALUTS;
    if(temp_medFlg==0){
        iq_k.mode=0;
        iq_k.x = fabsf(iq_ref_f);
        iq_k.y1 = 1.026867;
        iq_k.y2 = 0.996469;
        iq_k.x1 = 1.15;
        iq_k.x2 = 1.5;
        iq_k.calc(&iq_k);
        iq_k_data = iq_k.y;

        temp=1.00;   //����Ҫ���ݵ�ѹ����ϵ��
        iqLimit.mode=0;
        iqLimit.x = fabsf(motorSpd);
        iqLimit.y1 = 1.45;
        iqLimit.y2 = 1.15;
        iqLimit.x1 = 4200;
        iqLimit.x2 = 5700;
        iqLimit.calc(&iqLimit);
        temp = temp*iqLimit.y;
        iq_limitData = iqLimit.y;
        powerLmt.targetMax = 400;
        //powerLmt.Max = 5400;
    }else{
        iq_k.mode=0;
        iq_k.x = fabsf(iq_ref_f);
        iq_k.y1 = 1.038235;
        iq_k.y2 = 1.005865;
        iq_k.x1 = 0.92;
        iq_k.x2 = 1.25;
        iq_k.calc(&iq_k);
        iq_k_data = iq_k.y;

        temp=1.00;
        iqLimit.mode=0;
        iqLimit.x = fabsf(motorSpd);
        iqLimit.y1 = 1.35;
        iqLimit.y2 = 1.0;
        iqLimit.x1 = 4000;
        iqLimit.x2 = 5700;
        iqLimit.calc(&iqLimit);
        temp = temp*iqLimit.y;
        iq_limitData = iqLimit.y;
        powerLmt.targetMax = 340;
        //powerLmt.Max = 5400;
    }
    if(u16_SelPrimeFlg==1){
        powerLmt.Max = 6500;//5700;
    }else{
        powerLmt.Max = SPEED_MAX;//5700;
    }

    //iq_limitData = 1.55;
    //powerLmt.targetMax = 425;
    /*if(temp_medFlg==0){  //400w
        temp=1.00;   //����Ҫ���ݵ�ѹ����ϵ��
        iqLimit.mode=0;
        iqLimit.x = fabsf(motorSpd);
        iqLimit.y1 = 1.48;//1.39;
        iqLimit.y2 = 1.06;
        iqLimit.x1 = 4200;
        iqLimit.x2 = 5700;
        iqLimit.calc(&iqLimit);
        temp = temp*iqLimit.y;
        iq_limitData = iqLimit.y;
        powerLmt.targetMax = 405;
    }else{
        //340W��
        temp=1.02;   //����Ҫ���ݵ�ѹ����ϵ��
        iqLimit.mode=0;
        iqLimit.x = fabsf(motorSpd);
        iqLimit.y1 = 1.35;
        iqLimit.y2 = 0.85;
        iqLimit.x1 = 3500;
        iqLimit.x2 = 5800;
        iqLimit.calc(&iqLimit);
        temp = temp*iqLimit.y;
        iq_limitData = iqLimit.y;
        powerLmt.targetMax = 345;
    }*/
    //340W������������
    /*iqLimit.mode=0;
    iqLimit.x = fabsf(motorSpd);
    iqLimit.y1 = 1.21;//1.35;
    iqLimit.y2 = 0.98;
    iqLimit.x1 = 3800;
    iqLimit.x2 = 5700;
    iqLimit.calc(&iqLimit);
    temp = temp*iqLimit.y;
    iq_limitData = iqLimit.y;*/


	//���������ѹ�͵������м���
    outpowerCal_k = 3.1;
    cntPwrCal++;
    if(cntPwrCal>1)
    {
        cntPwrCal=0;
        f_power[0] = f_power[1];
        f_power[1] = f_power[2];
        f_power[2] = f_power[3];
        f_power[3] = f_power[4];
        f_power[4] = f_power[5];
        f_power[5] = f_power[6];
        f_power[6] = f_power[7];
        /*f_power[3] = motorVars_M1.Vs_V;
        temp2 = f_power[0] + f_power[1] + f_power[2] + f_power[3];
        temp2 = temp2*0.25;*/
        f_power[7] = vs_pwr;//vs_pwrBAK;//motorVars_M1.Vs_V;
        temp2 = f_power[0] + f_power[1] + f_power[2] + f_power[3] + f_power[4] + f_power[5] + f_power[6] + f_power[7];
        temp2 = temp2*0.125;
        temp = fabsf(outpowerCal_k *temp2 * iq_pwr);//iq_ref_f);
        sf_temp = sf_temp*0.5+temp*0.5;
        outpower = sf_temp;//temp;
    }
}

float pmsm_pi_controller(float given, float feedback, _sPID_ *pid)
{
    float error;
    float proportion;
    float integral;
    static float out_value=0;
    static float integral_sum_tmp=0;

    error = given - feedback;
    proportion = error * (pid->kp);				//������

    integral = error * (pid->ki);
    integral_sum_tmp = pid->integral_sum + integral;	//�����ۼ���
    if(integral_sum_tmp>pid->outlimit_upper){
    	integral_sum_tmp=pid->outlimit_upper;
    }else if(integral_sum_tmp < pid->outlimit_lower){
    	integral_sum_tmp=pid->outlimit_lower;
    }
    out_value = proportion + integral_sum_tmp;	//�������ֵ
    if (out_value > pid->outlimit_upper){		//�����������ֵ��������
        out_value = pid->outlimit_upper;
    }else if (out_value < pid->outlimit_lower){	//�����������ֵ��������
        out_value = pid->outlimit_lower;
    }else{
        pid->integral_sum = integral_sum_tmp;	//��ʼʱִ��
    }
    return out_value;
}

#endif
