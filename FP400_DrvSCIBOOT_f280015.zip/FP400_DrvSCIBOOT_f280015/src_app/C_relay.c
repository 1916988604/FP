
//����̵�������

#ifndef SRC_APP_RELAY_C_
#define SRC_APP_RELAY_C_

#include "app_include.h"
#include "gpio.h"


/**********************************************************************/
//���������motor_err_sci��motor_runFlg_sci��motor_readyFlg_sci
//������Դ��������SCIͨѶ����

//���������u16RelaySta��u16Relay2Sta��
//������Դ����ʾ��SCIͨѶ����

//������̵����ź�
/**********************************************************************/
void relay_init(void)
{
    GPIO_writePin(Relay1_IO,0);
    GPIO_writePin(Relay2_IO,0);
    relay1OutMode = RUN_SCI_STA;
    relay2OutMode = ERR_SCI_STA;
    motor_err_sci = 0;
    motor_runFlg_sci = 0;
    motor_readyFlg_sci = 0;
    debug_cmd.Relay1En = 0;
    debug_cmd.Relay2En = 0;
    debug_cmd.PWMoutValue = 0;
    debug_cmd.debugEn = 0;
}

void relay_ctrl(void)
{
    if(debug_cmd.debugEn == 1){
        if(debug_cmd.Relay1En == 1){
            GPIO_writePin(Relay1_IO,1);
        }else{
            GPIO_writePin(Relay1_IO,0);
        }
    }else{
        switch (relay1OutMode)
        {
            case ERR_SCI_STA:
                if(motor_err_sci == 0 ){
                    GPIO_writePin(Relay1_IO,0);
                }else{
                    GPIO_writePin(Relay1_IO,1);
                }
            break;

            case READY_SCI_STA:
                if(motor_readyFlg_sci == 0 ){
                    GPIO_writePin(Relay1_IO,0);
                }else{
                    GPIO_writePin(Relay1_IO,1);
                }
            break;

            case RUN_SCI_STA:
                if(motor_runFlg_sci == 0 ){
                    GPIO_writePin(Relay1_IO,0);
                }else{
                    GPIO_writePin(Relay1_IO,1);
                }
            break;

            default:
                if(motor_err_sci == 0 ){
                    GPIO_writePin(Relay1_IO,0);
                }else{
                    GPIO_writePin(Relay1_IO,1);
                }
            break;
        }
    }

    if(debug_cmd.debugEn == 1){
        if(debug_cmd.Relay2En == 1){
            GPIO_writePin(Relay2_IO,1);
        }else{
            GPIO_writePin(Relay2_IO,0);
        }
    }else{
        switch (relay2OutMode)
        {
            case ERR_SCI_STA:
                if(motor_err_sci ==0 ){
                    GPIO_writePin(Relay2_IO,0);
                }else{
                    GPIO_writePin(Relay2_IO,1);
                }
            break;

            case READY_SCI_STA:
                if(motor_readyFlg_sci ==0 ){
                    GPIO_writePin(Relay2_IO,0);
                }else{
                    GPIO_writePin(Relay2_IO,1);
                }
            break;

            case RUN_SCI_STA:
                if(motor_runFlg_sci ==0 ){
                    GPIO_writePin(Relay2_IO,0);
                }else{
                    GPIO_writePin(Relay2_IO,1);
                }
            break;

            default:
                if(motor_err_sci ==0 ){
                    GPIO_writePin(Relay2_IO,0);
                }else{
                    GPIO_writePin(Relay2_IO,1);
                }
            break;
        }
    }
}


#endif
