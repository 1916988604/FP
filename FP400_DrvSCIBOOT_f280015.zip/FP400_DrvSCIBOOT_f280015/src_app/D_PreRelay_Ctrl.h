#ifndef APP_PRERELAY_H_
#define APP_PRERELAY_H_

#include "f280015x_device.h"

#define     PRE_RELAY_VOL_ON    160     //V
#define     PRE_RELAY_VOL_OFF   140     //V

//���������ã�δ��
#define     PRE_RELAY_ON_CTRL   (GpioDataRegs.GPHDAT.bit.GPIO227 = 1)
#define     PRE_RELAY_OFF_CTRL  (GpioDataRegs.GPHDAT.bit.GPIO227 = 0)

#define     MOTOR_EN_CTRL
#define     MOTOR_EN_DISBLE_CTRL

#define     PFC_ON_CTRL   (GpioDataRegs.GPHDAT.bit.GPIO230 = 0)
#define     PFC_OFF_CTRL  (GpioDataRegs.GPHDAT.bit.GPIO230 = 1)

typedef  struct	PreRelay_Ctrl
{
	unsigned int  preRelayOnCnt;
	unsigned int  preRelayOffCnt;
    unsigned int  preRelayVol;

    unsigned int  pfcCtrlOnCnt;
    unsigned int  pfcCtrlOffCnt;
}_PreRelay_Ctrl_;

typedef  struct	PreRelay_Sta_Bit
{
	unsigned int  preRelayOn	:1;
    unsigned int  pfcCtrlOn     :1;
	unsigned int  rsv			:14;
}_PreRelay_Sta_Bit_;

typedef	union PreRelay_Sta {
    unsigned int  all;
    struct  PreRelay_Sta_Bit  bit;
}_PreRelay_Sta_;

#ifdef  APP_PRERELAYCTRL_C
    #define APP_PRERELAY_CTRL
#else
    #define APP_PRERELAY_CTRL  extern
#endif

APP_PRERELAY_CTRL struct	PreRelay_Ctrl	u16_PreRelayCtrl;
APP_PRERELAY_CTRL union		PreRelay_Sta	u16_PreRelaySta;
APP_PRERELAY_CTRL void f_preRelayCtrlInit(void);
APP_PRERELAY_CTRL void f_preRelayCtrl(void);

#endif
