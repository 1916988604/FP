#ifndef	APP_IGBT_TEMP_C
#define	APP_IGBT_TEMP_C

#include "app_include.h"

#define IPM_TYPE    1   //0:CRM60 IPM;  1:DPM15C60DG1 IPM

/*************************************************************************************************/
//���������Temp_IGBT.igbtAdcData�� Temp_IGBT.ntcAdcData�� Temp_IGBT.idcAdcData�� Temp_IGBT.hvilAdcData
//������Դ��������AD�������

//�����Temp_IGBT.igbtTemp�� Temp_IGBT.idc�� Temp_IGBT.ntcTemp�� Temp_IGBT.hvilFlg
/*************************************************************************************************/

// CRM60 IPM�Ĳ�������DSP������ѹ���¶ȵĶ�Ӧ��ϵ����3.3V��׼
const Uint16 voltageTempCRM60[] =
{// ��ѹmV      �¶ȡ�
    410 ,   //  0   1
    493 ,   //  4   2
    575 ,   //  8   3
    657 ,   //  12  4
    739 ,   //  16  5
    821 ,   //  20  6
    903 ,   //  24  7
    986 ,   //  28  8
    1068    ,   //  32  9
    1150    ,   //  36  10
    1232    ,   //  40  11
    1314    ,   //  44  12
    1397    ,   //  48  13
    1479    ,   //  52  14
    1561    ,   //  56  15
    1643    ,   //  60  16
    1725    ,   //  64  17
    1807    ,   //  68  18
    1890    ,   //  72  19
    1972    ,   //  76  20
    2054    ,   //  80  21
    2136    ,   //  84  22
    2218    ,   //  88  23
    2301    ,   //  92  24
    2383    ,   //  96  25
    2465    ,   //  100 26
    2547    ,   //  104 27
    2629    ,   //  108 28
    2711    ,   //  112 29
    2794    ,   //  116 30
    2876    ,   //  120 31
    2958    ,   //  124 32
    3040    ,   //  128 33
    3122    ,   //  132 34
    3204    ,   //  136 35
    3287    ,   //  140 36
    3369    ,   //  144 37
    3451    ,   //  148 38
    3533    ,   //  152 39
    3615    ,   //  156 40
    3698    ,   //  160 41
};

// DPM15C60DG1 IPM�Ĳ�������DSP������ѹ���¶ȵĶ�Ӧ��ϵ����3.3V��׼
const Uint16 voltageTemp_DPM15C60DG1[] =
{// ��ѹmV      �¶ȡ�
     421 ,   //  0   1
     505 ,   //  4   2
     589 ,   //  8   3
     672 ,   //  12  4
     756 ,   //  16  5
     840 ,   //  20  6
     924 ,   //  24  7
     1008    ,   //  28  8
     1092    ,   //  32  9
     1175    ,   //  36  10
     1259    ,   //  40  11
     1343    ,   //  44  12
     1427    ,   //  48  13
     1511    ,   //  52  14
     1595    ,   //  56  15
     1678    ,   //  60  16
     1762    ,   //  64  17
     1846    ,   //  68  18
     1930    ,   //  72  19
     2014    ,   //  76  20
     2097    ,   //  80  21
     2181    ,   //  84  22
     2265    ,   //  88  23
     2349    ,   //  92  24
     2433    ,   //  96  25
     2517    ,   //  100 26
     2600    ,   //  104 27
     2684    ,   //  108 28
     2768    ,   //  112 29
     2852    ,   //  116 30
     2936    ,   //  120 31
     3020    ,   //  124 32
     3103    ,   //  128 33
     3187    ,   //  132 34
     3271    ,   //  136 35
     3355    ,   //  140 36
     3439    ,   //  144 37
     3522    ,   //  148 38
     3606    ,   //  152 39
     3690    ,   //  156 40
     3774    ,   //  160 41
};


void  f_igbtTemp_Init(void)
{
	Temp_IGBT.igbtTemp = 25;
	Temp_IGBT.ntcTemp = 25;
	Temp_IGBT.idc = 0;
	Temp_IGBT.hvilFlg = 0;
	Temp_IGBT.hvilFiltCnt = 0;

	Temp_IGBT.igbtAdcData = 2800;
	Temp_IGBT.ntcAdcData= 912;
	Temp_IGBT.idcAdcData = 4040;
    Temp_IGBT.hvilAdcData = 0;

    Temp_IGBT.V_LN = 0;
    Temp_IGBT.vLNCnt = 0;
    Temp_IGBT.V_LNFlg = 0;
}
extern float uln_data[21];
void  f_igbtTemp_Cal(void)		//10ms
{
    float temp;
	static float IGBT_Temp[5]={0,0,0,0,0};
    const Uint16 *p;
    Uint16 size;

    //ģ���¶�
#if    IPM_TYPE==0
    p = voltageTempCRM60;
    size = sizeof(voltageTempCRM60);
    temp = GetTemperatureCalc(aiDeal[0], p, size, 2);
#elif IPM_TYPE==1
    p = voltageTemp_DPM15C60DG1;
    size = sizeof(voltageTemp_DPM15C60DG1);
    temp = GetTemperatureCalc(aiDeal[0], p, size, 3);
#else
    p = voltageTempCRM60;
    size = sizeof(voltageTempCRM60);
    temp = GetTemperatureCalc(aiDeal[0], p, size, 2);
#endif
    IGBT_Temp[0] = IGBT_Temp[0] * 0.9 + temp * 0.1;
    if(IGBT_Temp[0] < 0){
        IGBT_Temp[0] = 0;
    }
    Temp_IGBT.igbtTemp = IGBT_Temp[0];

    //�ߵ�ѹ
#if  PCBA_TYPE ==  driverES_PCBA
    //temp = uln_data[20]*0.006116;   //220Vacʱ��ʵ��ֻ��1.45V��������1.55V������6.5%��0.114432/0.935=0.006116
    //temp = uln_data[20]*0.006287032;    //0.006106609;    //0.005691155;    //0.005585273;    //0.005767969;
    temp = uln_data[20]*0.005564;
    IGBT_Temp[4] = IGBT_Temp[4] * 0.9 + temp * 0.1;
    if(motorVars_M1.flagEnableRunAndIdentify==0){
        if(IGBT_Temp[4] > 250){
            Temp_IGBT.V_LN = IGBT_Temp[4]+5;
        }else{
            Temp_IGBT.V_LN = IGBT_Temp[4]+4;
        }
    }else{
        if(IGBT_Temp[4] > 250){
            Temp_IGBT.V_LN = IGBT_Temp[4]+8;
        }else{
            Temp_IGBT.V_LN = IGBT_Temp[4];
        }
    }

#else
    temp = aiDeal[1]* 0.13263662115;
    if(temp > 266)                //267V PFC������
    {
        Temp_IGBT.V_LN = temp  / 1.09;
    }else{
        Temp_IGBT.V_LN = temp;
    }
#endif


/*����ƽ���޷��˳�Ч��*/
	/*tempZeroFlg++;
	if(tempZeroFlg<17){
	    tempZeroSum =+ Temp_IGBT.idcAdcData;
		Temp_IGBT.idc = 0;
	}else if(tempZeroFlg==17){
	    tempZero = tempZeroSum * 0.0625;
	}else{
		tempZeroFlg = 200;
		temp = (tempZero- Temp_IGBT.idcAdcData)*0.245238;
		IGBT_Temp[2] = temp * 0.10 + IGBT_Temp[3] * 0.90;
		IGBT_Temp[3] = IGBT_Temp[2];

		if(IGBT_Temp[3] > 1000){
			Temp_IGBT.idc = 1000;
		}else if(IGBT_Temp[3]<0){
			Temp_IGBT.idc = 0;
		}else{
			Temp_IGBT.idc = IGBT_Temp[3];
		}
	}*/

    if(motorVars_M1.adcData.VdcBus_V<1){
        Temp_IGBT.idc = 0;
    }else{
        //IGBT_Temp[2] = motorVars_M1.Irms_A[0];
        //IGBT_Temp[2] = IGBT_Temp[2]*motorVars_M1.Vs_V;
        //IGBT_Temp[2] = IGBT_Temp[2]/motorVars_M1.adcData.VdcBus_V;
        IGBT_Temp[2] = motorPwr_Lpf;
        IGBT_Temp[2] = IGBT_Temp[2] / (Temp_IGBT.V_LN + 30) * 1.03;
#if  PCBA_TYPE ==  driverES_PCBA
        Temp_IGBT.idc = 0;
#else
        Temp_IGBT.idc = IGBT_Temp[2] *100;
#endif
    }

	//NTC,�����¶�
	IGBT_Temp[1] = IGBT_Temp[1] * 0.3 + Temp_IGBT.ntcTemp * 0.7;
	if(IGBT_Temp[1] < -40){
		IGBT_Temp[1] = -40;
	}
	Temp_IGBT.ntcTemp = 25;

	if(Temp_IGBT.hvilAdcData > 2000){
		Temp_IGBT.hvilFiltCnt++;
		if(Temp_IGBT.hvilFiltCnt > 3){
			Temp_IGBT.hvilFlg = 1;
			Temp_IGBT.hvilFiltCnt = 3;
		}
	}else{
		Temp_IGBT.hvilFiltCnt = 0;
		Temp_IGBT.hvilFlg = 0;
	}
}

#endif



