
#ifndef SRC_APP_C_COM_COMMON_C_
#define SRC_APP_C_COM_COMMON_C_

#include "app_include.h"

const Uint16 crc16Table[256] =
{
0x0000, 0xC1C0, 0x81C1, 0x4001, 0x01C3, 0xC003, 0x8002, 0x41C2, 0x01C6, 0xC006, 0x8007, 0x41C7,
0x0005, 0xC1C5, 0x81C4, 0x4004, 0x01CC, 0xC00C, 0x800D, 0x41CD, 0x000F, 0xC1CF, 0x81CE, 0x400E,
0x000A, 0xC1CA, 0x81CB, 0x400B, 0x01C9, 0xC009, 0x8008, 0x41C8, 0x01D8, 0xC018, 0x8019, 0x41D9,
0x001B, 0xC1DB, 0x81DA, 0x401A, 0x001E, 0xC1DE, 0x81DF, 0x401F, 0x01DD, 0xC01D, 0x801C, 0x41DC,
0x0014, 0xC1D4, 0x81D5, 0x4015, 0x01D7, 0xC017, 0x8016, 0x41D6, 0x01D2, 0xC012, 0x8013, 0x41D3,
0x0011, 0xC1D1, 0x81D0, 0x4010, 0x01F0, 0xC030, 0x8031, 0x41F1, 0x0033, 0xC1F3, 0x81F2, 0x4032,
0x0036, 0xC1F6, 0x81F7, 0x4037, 0x01F5, 0xC035, 0x8034, 0x41F4, 0x003C, 0xC1FC, 0x81FD, 0x403D,
0x01FF, 0xC03F, 0x803E, 0x41FE, 0x01FA, 0xC03A, 0x803B, 0x41FB, 0x0039, 0xC1F9, 0x81F8, 0x4038,
0x0028, 0xC1E8, 0x81E9, 0x4029, 0x01EB, 0xC02B, 0x802A, 0x41EA, 0x01EE, 0xC02E, 0x802F, 0x41EF,
0x002D, 0xC1ED, 0x81EC, 0x402C, 0x01E4, 0xC024, 0x8025, 0x41E5, 0x0027, 0xC1E7, 0x81E6, 0x4026,
0x0022, 0xC1E2, 0x81E3, 0x4023, 0x01E1, 0xC021, 0x8020, 0x41E0, 0x01A0, 0xC060, 0x8061, 0x41A1,
0x0063, 0xC1A3, 0x81A2, 0x4062, 0x0066, 0xC1A6, 0x81A7, 0x4067, 0x01A5, 0xC065, 0x8064, 0x41A4,
0x006C, 0xC1AC, 0x81AD, 0x406D, 0x01AF, 0xC06F, 0x806E, 0x41AE, 0x01AA, 0xC06A, 0x806B, 0x41AB,
0x0069, 0xC1A9, 0x81A8, 0x4068, 0x0078, 0xC1B8, 0x81B9, 0x4079, 0x01BB, 0xC07B, 0x807A, 0x41BA,
0x01BE, 0xC07E, 0x807F, 0x41BF, 0x007D, 0xC1BD, 0x81BC, 0x407C, 0x01B4, 0xC074, 0x8075, 0x41B5,
0x0077, 0xC1B7, 0x81B6, 0x4076, 0x0072, 0xC1B2, 0x81B3, 0x4073, 0x01B1, 0xC071, 0x8070, 0x41B0,
0x0050, 0xC190, 0x8191, 0x4051, 0x0193, 0xC053, 0x8052, 0x4192, 0x0196, 0xC056, 0x8057, 0x4197,
0x0055, 0xC195, 0x8194, 0x4054, 0x019C, 0xC05C, 0x805D, 0x419D, 0x005F, 0xC19F, 0x819E, 0x405E,
0x005A, 0xC19A, 0x819B, 0x405B, 0x0199, 0xC059, 0x8058, 0x4198, 0x0188, 0xC048, 0x8049, 0x4189,
0x004B, 0xC18B, 0x818A, 0x404A, 0x004E, 0xC18E, 0x818F, 0x404F, 0x018D, 0xC04D, 0x804C, 0x418C,
0x0044, 0xC184, 0x8185, 0x4045, 0x0187, 0xC047, 0x8046, 0x4186, 0x0182, 0xC042, 0x8043, 0x4183,
0x0041, 0xC181, 0x8180, 0x4040,
};

/******���������ñ�**********************************************/
#define     BAUD_NUM_MAX    12
typedef struct
{
    Uint16 baudRate;    // _*100bps
    Uint16 high;
    Uint16 low;
} DSP_BAUD_REGISTER_DATA;

#if XTAL_PLL_FREQ==0
const unsigned int dspBaudRegData[BAUD_NUM_MAX + 1][3] =  // LSPCLK = SYSCLKOUT/2=60MHz
{
    {   3, 0x0061, 0x00A7},           //  0, 300bps
    {   6, 0x0030, 0x00D3},           //  1, 600bps
    {  12, 0x0018, 0x0069},           //  2, 1200bps
    {  24, 0x000C, 0x0034},           //  3, 2400bps
    {  48, 0x0006, 0x0019},           //  4, 4800bps
    {  96, 0x0003, 0x000C},           //  5, 9600bps
    { 192, 0x0001, 0x0085},           //  6, 19200bps
    { 384, 0x0000, 0x00c2},           //  7, 38400bps
    { 576, 0x0000, 0x0081},           //  8, 57600bps
    {1152, 0x0000, 0x0040},           //  9, 115200bps
    {1280, 0x0000, 0x0023},           // 10, 208300bps
    {2560, 0x0000, 0x001c},           // 11, 256000bps
    {5120, 0x0000, 0x000d},           // 12,512000bps
};
#elif  XTAL_PLL_FREQ==1
const unsigned int dspBaudRegData[BAUD_NUM_MAX + 1][3] =  // LSPCLK = SYSCLKOUT/2=50MHz
{
    {   3, 0x0051, 0x0060},           //  0, 300bps
    {   6, 0x0028, 0x00af},           //  1, 600bps
    {  12, 0x0014, 0x0057},           //  2, 1200bps
    {  24, 0x000a, 0x002b},           //  3, 2400bps
    {  48, 0x0005, 0x0015},           //  4, 4800bps
    {  96, 0x0002, 0x008a},           //  5, 9600bps
    { 192, 0x0001, 0x0044},           //  6, 19200bps
    { 384, 0x0000, 0x00a1},           //  7, 38400bps
    { 576, 0x0000, 0x006b},           //  8, 57600bps
    {1152, 0x0000, 0x0035},           //  9, 115200bps
    {1280, 0x0000, 0x001d},           // 10, 208300bps
    {2560, 0x0000, 0x0017},           // 11, 256000bps
    {5120, 0x0000, 0x000b},           // 12,512000bps
};
#elif   XTAL_PLL_FREQ==2
const unsigned int dspBaudRegData[BAUD_NUM_MAX + 1][3] =  // LSPCLK = SYSCLKOUT/4=30MHz
{
    {   3, 0x0030, 0x00d3},           //  0, 300bps
    {   6, 0x0018, 0x0069},           //  1, 600bps
    {  12, 0x000c, 0x0034},           //  2, 1200bps
    {  24, 0x0006, 0x0019},           //  3, 2400bps
    {  48, 0x0003, 0x000c},           //  4, 4800bps
    {  96, 0x0001, 0x0085},           //  5, 9600bps
    { 192, 0x0000, 0x00c2},           //  6, 19200bps
    { 384, 0x0000, 0x0060},           //  7, 38400bps
    { 576, 0x0000, 0x0040},           //  8, 57600bps
    {1152, 0x0000, 0x001f},           //  9, 115200bps
    {1280, 0x0000, 0x0011},           // 10, 208300bps
    {2560, 0x0000, 0x000d},           // 11, 256000bps
    {5120, 0x0000, 0x0006},           // 12,512000bps
};
#else
const unsigned int dspBaudRegData[BAUD_NUM_MAX + 1][3] =  // LSPCLK = SYSCLKOUT/4=25MHz
{
    {   3, 0x0028, 0x00af},           //  0, 300bps
    {   6, 0x0014, 0x0057},           //  1, 600bps
    {  12, 0x000a, 0x002b},           //  2, 1200bps
    {  24, 0x0005, 0x0015},           //  3, 2400bps
    {  48, 0x0002, 0x008a},           //  4, 4800bps
    {  96, 0x0001, 0x0044},           //  5, 9600bps
    { 192, 0x0000, 0x00a1},           //  6, 19200bps
    { 384, 0x0000, 0x0050},           //  7, 38400bps
    { 576, 0x0000, 0x0035},           //  8, 57600bps
    {1152, 0x0000, 0x001a},           //  9, 115200bps
    {1280, 0x0000, 0x000e},           // 10, 208300bps
    {2560, 0x0000, 0x000b},           // 11, 256000bps
    {5120, 0x0000, 0x0005},           // 12,512000bps
};
#endif

/********************************************************************/

/*******��żУ��λ����*****************************************************/
const Uint16 commParitys[4] = {0x87, 0x67, 0x27, 0x07};
/**********************************************************************/

// *dataΪ�ֽ�
Uint16 CrcValueByteCalc(Uint16 *data, Uint16 length)
{
    Uint16 crcValue = 0xFFFF;
    Uint16 tmp;
    Uint16 tmpRec;
    Uint16 tmpLength;

    tmpLength = length;
    while (tmpLength--)
    {
        tmpRec= *data++;
       tmp = crc16Table[(crcValue ^ tmpRec) & 0x00FF];
        crcValue = ((tmp & 0x00FF) << 8) + ((tmp ^ crcValue) >> 8);
    }
    return (crcValue);
}

void sci_comm_init()
{
    //DandC
    sysSci_mode.mode = AUTO;
    sysSci_mode.headValid = 0;
    sysSci_mode.errRstEn = 0;
    sysSci_mode.headSensor = 0;
    sysSci_mode.liquidLimtEn = 0;
    sysSci_mode.liquidLimtMax = 120;    //0.1,m^3/h
    sysSci_mode.varInit = 0;
    sysSci_mode.TempMax = 500;  //0.1
    sysSci_mode.Address485 = 0x20;
    sysSci_mode.AddressCan = 0x0;
    sysSci_mode.AddressLIN = 0x0;

    sci_motor_spd     = 0;
    sci_motor_udcVol  = 0;
    sci_motor_idc     = 0;
    sci_motor_gridVol = 0;
    sci_motor_igbtT   = 0;
    sci_motor_ntcT    = 0;
    sci_motor_fault   = 0;
    sci_motor_runFlg  = 0;
    sci_motor_pwrLmtFlg  = 0;
    sci_motor_gear   = 0;
    sci_motor_flow   = 0;
    sci_motor_lift   = 0;
    sci_motor_power  = 0;
    sci_motor_heat   = 0;
    sci_motor_Hauto = 10;
    sci_motor_Hmin = 20;
    sci_motor_Hmax = 100;
    sci_motor_CHmin = 10;
    sci_motor_CHmax = 100;
    sci_motor_softVer = 0;
    sci_motor_hardVer = 0;
    sci_motor_bootVer = 0;

    //HandC
    u_speed_exsci = 0;
    u_enable_HandC = 0;
    u_ctrl_logic.all = 0;

    sys_param.headValid = 0;
    sys_param.errRstEn = 0;
    sys_param.headSensor = 0;
    sys_param.liquidLimtEn = 0;
    sys_param.liquidLimtMax = 1000;
    sys_param.varInit = 0;
    sys_param.TempMax = 500;  //0.1
    sys_param.Address485 = 0x20;
    sys_param.AddressCan = 0x0;
    sys_param.AddressLIN = 0x0;

    relay1OutMode = ERR_SCI_STA;
    relay2OutMode = RUN_SCI_STA;
    ai1InMode = AI_VI;
    ai2InMode = AI_VI;
    pwmOutMode = PWR_OUT_STA;
    u_DpumpMode_HtoC = SINGLE;
    pwmInMode=PWMIN_C;
/******��ʼ��ʱĬ��״̬**************************************************/
    #if PMSM_DEBUG==0
        u16_DI1_sta = 1;
        sys_param.mode = CAN_GEAR;      //������
        u_enable_HandC = 1;
    #elif PCBA_TYPE == driverES_PCBA
        u16_DI1_sta = 1;
        sys_param.mode = PWM_GEAR;
        u_enable_HandC = 1;
        pwmInMode=PWMIN_E;
        pwmOutMode = SPEED_OUT_STA;
    #else
        u16_DI1_sta = 0;
        sys_param.mode = AUTO;
    #endif
/****************************************************************/

    //modbus
    u_speed_e485 = 0;
    u_sci_enable.bit.e485_enable = 0;
    u_sci_enable.bit.e485_errRst = 0;

    u16_pressCmd = 2000;    //0.01m
    u16_press = 2000;       //0.01m
    s16_temper_medium = 25;
    u16_display_ver=0;
}



#endif

