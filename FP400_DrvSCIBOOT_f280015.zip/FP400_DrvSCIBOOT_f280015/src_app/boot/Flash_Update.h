#ifndef CAN_UPDATA_H
#define CAN_UPDATA_H

#include "device.h"
#include "board.h"
//#include "types.h"

typedef unsigned char          boolean;
typedef unsigned int           uint8; //This is 16bits in C28x
typedef unsigned int           uint16;
typedef unsigned long int      uint32;
typedef unsigned long long int uint64;


/**********************************************
* ����1��2��ΪBOOT����
* ����1����������
* ����2����������
**********************************************/

#define XTAL_PLL_FREQ  1  //0:120MHz��SCI60MHz��  1:100MHz��SCI50MHz��   2:120Mhz��SCI30MHz��  3:100Mhz��SCI25MHz��

/*****************************************************/
#define BAUDRATE_SEL  0  //0:500K  1:250K

/*****************************************************/
#define  controller     0   //0�����ư壻    1��������

#if controller == 0                 //ˮ��1
#define  MODBUS_ID      0x07E0
#define  DSP_ID         0x07E8
#define  TM_ID          0x11
#elif controller == 1               //ˮ��2
#define  MODBUS_ID      0x07E1
#define  DSP_ID         0x07E9
#define  TM_ID          0x12
#elif controller == 2               //���1
#define  MODBUS_ID      0x07E2
#define  DSP_ID         0x07EA
#define  TM_ID          0x13
#elif controller == 3               //���2
#define  MODBUS_ID      0x07E3
#define  DSP_ID         0x07EB
#define  TM_ID          0x14
#elif controller == 4               //��ѹ��1
#define  MODBUS_ID      0x07E4
#define  DSP_ID         0x07EC
#define  TM_ID          0x15
#else                               //����
#define  MODBUS_ID      0x07E5
#define  DSP_ID         0x07ED
#define  TM_ID          0x16
#endif

#define  BOOT_VERION  0x01

#define  RECEIVE_MODE  0x01
#define  SEND_MODE     0x03


typedef  union
{
    struct
    {
         unsigned bit_CRC         :   1;
         unsigned bit_shake       :   1;
         unsigned bit_receive_data:   1;
         unsigned bit_erase       :   1;
         unsigned bit_verorid     :   1;
         unsigned bit_program     :   1;
         unsigned bit_reserved    :   2;
    }field;
    uint16 u16_value;
}BOOT_ERR;


#ifdef CAN_UPDATA_C
#define EXTERN_CAN_UPDATA
#else
#define EXTERN_CAN_UPDATA   extern
#endif

EXTERN_CAN_UPDATA   uint16_t rxMsgData[8];

EXTERN_CAN_UPDATA void Cana_Modbus_Initial(void);
EXTERN_CAN_UPDATA void Cana_Process(void);
EXTERN_CAN_UPDATA void Cana_Data_Process(void);

EXTERN_CAN_UPDATA BOOT_ERR    Boot_err;
EXTERN_CAN_UPDATA uint16 CanA_BusoffFlg(void);
EXTERN_CAN_UPDATA void CanA_Restart(void);

EXTERN_CAN_UPDATA uint16_t boot_ver;
EXTERN_CAN_UPDATA uint16_t boot_Baud;
EXTERN_CAN_UPDATA uint16_t boot_RevID;
EXTERN_CAN_UPDATA uint16_t boot_SendID;
EXTERN_CAN_UPDATA uint16_t boot_Year;
EXTERN_CAN_UPDATA uint16_t boot_Month;
EXTERN_CAN_UPDATA uint16_t boot_Day;


#endif
















