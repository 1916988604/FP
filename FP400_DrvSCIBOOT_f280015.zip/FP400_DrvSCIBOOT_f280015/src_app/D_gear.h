
#ifndef SRC_APP_D_GEAR_H_
#define SRC_APP_D_GEAR_H_

#include "libraries/math/include/math.h"

#define PUMP_MODEL_NUM  1000   //0:25-40;  1:FPUN600_motor; 2:FP400; 1000:debug

//************���ݱõ��ͺŽ��и���*******************/
#if     PUMP_MODEL_NUM==0
    #define SPEED_MAX    3500   //rpm
    #define SPEED_MIN    500   //rpm
    #define MAX_POWER    1200   //W
#elif     PUMP_MODEL_NUM==1
    #define SPEED_MAX    5000   //rpm
    #define SPEED_MIN    1000   //rpm
    #define MAX_POWER    800   //W
#elif     PUMP_MODEL_NUM==2
    #define SPEED_MAX    4900   //rpm
    #define SPEED_MIN    1000   //rpm
    #define MAX_POWER    400   //W
#else
    #define SPEED_MAX    5700//6600//6600//4900//4500//5200//3000//4500//4050////5200//4050:03-30EC PRO//6000   //rpm
    #define SPEED_MIN    500   //rpm
    #define MAX_POWER    400//345//400//360//450//570//400//610//750//610//650//625//630   //W
#endif
/**********************************************/

typedef enum
{
    AUTO,
    AUTOLIMIT,
    HS_I,
    HD_I,
    BL_I,
    HL_I,           //5
    HTEMP_I,
    HTDIFF_I,
    VOL_GEAR,
    CUR_GEAR,
    PWM_GEAR,
    MODBUS_GEAR,    //10
    CAN_GEAR,
    LIN_GEAR,
    CANFD_GEAR,
    TOTAL_NUM       //14
} WORK_MODE;

typedef struct
{
    float max_speed;
    float min_speed;
    float limit_power;
    float max_Iq;
    float curve_k;
    float curve_b;
    float curve_c;
} GEAR_PARAM;

typedef struct
{
    Uint16 mode;             // ϵͳ����ģʽ
    GEAR_PARAM gear[TOTAL_NUM]; // ÿ����λ����ز���
    Uint16 errRstEn;
    Uint16 liquidLimtEn;
    Uint16 liquidLimtMax;
    Uint16 headValid;
    Uint16 varInit;
    Uint16 headSensor;
    Uint16 TempMax;
    Uint16 Address485;
    Uint16 AddressCan;
    Uint16 AddressLIN;
} SYS_PARAM;


typedef struct
{
    uint32_t mode;      // ����ģʽ
    uint32_t flag_num;  // ����ģʽ
    uint32_t checkcrc;  // У����
}FLASH_STORE;


typedef struct PID_STRUCT_DEF {
    float    Total;          //�����ۼ�ֵ
    float    Out;            //���ֵ
    float     Max;            //���ֵ����
    float     Min;            //��Сֵ����
    float     Deta;           //ƫ��ֵ
    float     KP;             //KP����
    float     KI;             //KI����
    float     KD;             //KD����
    Uint16     Flag;            //��־λ
    int16     OutFlag;         //���ͱ�־λ
    float     targetMax;
}PID_STRUCT;//PID�����õ����ݽṹ(���������ݽṹ)


#ifdef  SRC_APP_GEAR_C_
    #define SRC_APP_GEAR
#else
    #define SRC_APP_GEAR  extern
#endif

SRC_APP_GEAR SYS_PARAM sys_param;
SRC_APP_GEAR SYS_PARAM sysSci_mode;
SRC_APP_GEAR void process_gear(void);
SRC_APP_GEAR void gear_init(void);
SRC_APP_GEAR uint16_t u_speed_exsci;       //������ͳһ�ź�
SRC_APP_GEAR float f_speed_gear;
SRC_APP_GEAR uint16_t u_enable_exsci;
SRC_APP_GEAR PID_STRUCT liquidLmt;
SRC_APP_GEAR PID_STRUCT powerLmt;
SRC_APP_GEAR PID_STRUCT pressCtrlLmt;
SRC_APP_GEAR void PID(PID_STRUCT * pid);
SRC_APP_GEAR void liquidLmtInit();

#endif /* SRC_APP_D_GEAR_H_ */
