/*
 * C_lin.h
 *
 *  Created on: 2024��9��27��
 *      Author: shujixiang
 */

#ifndef SRC_APP_C_LIN_H_
#define SRC_APP_C_LIN_H_

//ID
#define     LIN_ID_COMMREC          0x10
#define     LIN_ID_COMMREC_CRC      0x50

#define     LIN_ID_COMMSEND         0x11
#define     LIN_ID_COMMSEND_CRC     0x17

//DEBUG ID
#define     LIN_ID_DIAGREC          0x3C
#define     LIN_ID_DIAGREC_CRC      0x3C

#define     LIN_ID_DIAGSEND         0x3D
#define     LIN_ID_DIAGSEND_CRC     0x7D

#ifdef SRC_APP_LIN_C_
    #define SRC_APP_LIN_C
#else
    #define SRC_APP_LIN_C   extern
#endif

SRC_APP_LIN_C void Lin_init();
SRC_APP_LIN_C void Lin_Deal();



#endif /* SRC_APP_C_LIN_H_ */
