
#ifndef APP_UDC_ADJUST_H_
#define APP_UDC_ADJUST_H_


#ifdef  APP_UDCT_ADJUST_C
    #define APP_UDC_ADJUST
#else
    #define APP_UDC_ADJUST  extern
#endif

APP_UDC_ADJUST void f_udcAdjust_k(void);
APP_UDC_ADJUST void f_udcAdjust_init(void);
APP_UDC_ADJUST int  udcAdjustTempBase;
APP_UDC_ADJUST float udcAdjEnd;
APP_UDC_ADJUST float udcAdjOut;

#endif /* APP_UDC_ADJUST_H_ */
