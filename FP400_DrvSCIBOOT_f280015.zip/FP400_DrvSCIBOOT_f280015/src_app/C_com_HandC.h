#ifndef SRC_APP_COM_HANDC_H_
#define SRC_APP_COM_HANDC_H_


#ifdef  SRC_APP_COM_HANDC_C_
    #define SRC_APP_COM_HANDC
#else
    #define SRC_APP_COM_HANDC  extern
#endif

#define SCI_SLAVE_ADDRESS_HtoC           0x21            //�ӻ���ַ

#define RTU_READ_ADDRESS_HtoC     5000
#define RTU_WRITE_ADDRESS_HtoC    4000

#define RTU_READ_DATANUM_HtoC     40    // ����ȡ���ݸ���
#define RTU_WRITE_DATANUM_HtoC    30

typedef enum
{
    SINGLE,
    D_ALTER,
    D_BACKUP,
    D_CASCAD
} DOUBLE_PUMP_TYPE;


#define SET_RTS_R_HtoC
#define SET_RTS_T_HtoC

SRC_APP_COM_HANDC void f_rs485_HtoC_ComInit(void);

SRC_APP_COM_HANDC interrupt void SCI_HtoC_RXD_isr(void);
SRC_APP_COM_HANDC interrupt void SCI_HtoC_TXD_isr(void);
SRC_APP_COM_HANDC void SciDeal_HtoC(void);
SRC_APP_COM_HANDC void commStatusDeal_HtoC();
SRC_APP_COM_HANDC void CommRcvDataDealHtoC(void);
SRC_APP_COM_HANDC void CommDataReRcvHtoC(Uint16 tmp);
SRC_APP_COM_HANDC void ModbusRcvDataDealHtoC(void);
SRC_APP_COM_HANDC Uint16 ModbusStartDealHtoC(Uint16 tmp);

SRC_APP_COM_HANDC unsigned int commTickerHtoC;
SRC_APP_COM_HANDC COMM_RCV_DATA commRcvDataHtoC;
SRC_APP_COM_HANDC COMM_SEND_DATA commSendDataHtoC;
SRC_APP_COM_HANDC union SCI_FLAG sciFlagHtoC;   // SCIʹ�õı�־
SRC_APP_COM_HANDC Uint16 sendFrameHtoC[100];        // �ӻ���Ӧ֡
SRC_APP_COM_HANDC Uint16 rcvFrameHtoC[100];         // ������������(��������֡)
SRC_APP_COM_HANDC Uint16 commReadDataHtoC[40];     // ��ȡ������
SRC_APP_COM_HANDC Uint16 rcvFrameMoreHtoC[40];
SRC_APP_COM_HANDC Uint16 baudrateHtoC;
SRC_APP_COM_HANDC void CommSendDataDealHtoC(void);
SRC_APP_COM_HANDC unsigned int commSendTickerHtoC;
SRC_APP_COM_HANDC void CommReadHtoC(void);
SRC_APP_COM_HANDC void CommWriteHtoC(void);

SRC_APP_COM_HANDC Uint16 u_DpumpMode_HtoC;
SRC_APP_COM_HANDC Uint16 u_speed_HandC;
#endif /* SRC_APP_COM_HANDC_H_ */
