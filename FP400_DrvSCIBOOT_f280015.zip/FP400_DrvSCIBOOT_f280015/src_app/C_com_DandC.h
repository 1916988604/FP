#ifndef SRC_APP_C_COM_DANDC_H_
#define SRC_APP_C_COM_DANDC_H_


#ifdef  SRC_APP_COM_DANDC_C_
    #define SRC_APP_COM_DANDC
#else
    #define SRC_APP_COM_DANDC  extern
#endif

#define SCI_SLAVE_ADDRESS_DtoC           0x22            //�ӻ���ַ

#define RTU_READ_ADDRESS_DtoC     5000
#define RTU_WRITE_ADDRESS_DtoC    4000

#define RTU_READ_DATANUM_DtoC     40
#define RTU_WRITE_DATANUM_DtoC    39


#define SET_RTS_R_DtoC
#define SET_RTS_T_DtoC

SRC_APP_COM_DANDC void f_rs485_DtoC_ComInit(void);

SRC_APP_COM_DANDC interrupt void SCI_DtoC_RXD_isr(void);
SRC_APP_COM_DANDC interrupt void SCI_DtoC_TXD_isr(void);
SRC_APP_COM_DANDC void SciDeal_DtoC(void);
SRC_APP_COM_DANDC void commStatusDeal_DtoC();
SRC_APP_COM_DANDC void CommRcvDataDealDtoC(void);
SRC_APP_COM_DANDC void CommDataReRcvDtoC(Uint16 tmp);
SRC_APP_COM_DANDC void ModbusRcvDataDealDtoC(void);
SRC_APP_COM_DANDC Uint16 ModbusStartDealDtoC(Uint16 tmp);

SRC_APP_COM_DANDC unsigned int commTickerDtoC;
SRC_APP_COM_DANDC COMM_RCV_DATA commRcvDataDtoC;
SRC_APP_COM_DANDC COMM_SEND_DATA commSendDataDtoC;
SRC_APP_COM_DANDC union SCI_FLAG sciFlagDtoC;   // SCIʹ�õı�־
SRC_APP_COM_DANDC Uint16 sendFrameDtoC[100];        // �ӻ���Ӧ֡
SRC_APP_COM_DANDC Uint16 rcvFrameDtoC[100];         // ������������(��������֡)
SRC_APP_COM_DANDC Uint16 commReadDataDtoC[40];     // ��ȡ������
SRC_APP_COM_DANDC Uint16 rcvFrameMoreDtoC[40];
SRC_APP_COM_DANDC Uint16 baudrateDtoC;
SRC_APP_COM_DANDC void CommSendDataDealDtoC(void);
SRC_APP_COM_DANDC unsigned int commSendTickerDtoC;
SRC_APP_COM_DANDC void CommWriteBackDtoC(void);
SRC_APP_COM_DANDC void CommReadDtoC(void);
SRC_APP_COM_DANDC void CommWriteDtoC(void);
SRC_APP_COM_DANDC void CommReadBackDtoC(void);

SRC_APP_COM_DANDC Uint16     sci_motor_spd;
SRC_APP_COM_DANDC Uint16     sci_motor_udcVol;
SRC_APP_COM_DANDC Uint16     sci_motor_idc;
SRC_APP_COM_DANDC Uint16     sci_motor_gridVol;
SRC_APP_COM_DANDC Uint16     sci_motor_igbtT;
SRC_APP_COM_DANDC Uint16     sci_motor_ntcT;
SRC_APP_COM_DANDC Uint16     sci_motor_fault;
SRC_APP_COM_DANDC Uint16     sci_motor_runFlg;
SRC_APP_COM_DANDC Uint16     sci_motor_pwrLmtFlg;
SRC_APP_COM_DANDC Uint16     sci_motor_gear;
SRC_APP_COM_DANDC Uint16     sci_motor_flow;
SRC_APP_COM_DANDC Uint16     sci_motor_lift;
SRC_APP_COM_DANDC Uint16     sci_motor_power;
SRC_APP_COM_DANDC Uint16     sci_motor_heat;
SRC_APP_COM_DANDC Uint16     sci_motor_Hauto;
SRC_APP_COM_DANDC Uint16     sci_motor_Hmin;
SRC_APP_COM_DANDC Uint16     sci_motor_Hmax;
SRC_APP_COM_DANDC Uint16     sci_motor_CHmin;
SRC_APP_COM_DANDC Uint16     sci_motor_CHmax;
SRC_APP_COM_DANDC Uint16     sci_motor_softVer;
SRC_APP_COM_DANDC Uint16     sci_motor_hardVer;
SRC_APP_COM_DANDC Uint16     sci_motor_bootVer;

SRC_APP_COM_DANDC Uint16    sci_motor_cmd;
SRC_APP_COM_DANDC float     sci_motor_adi;
SRC_APP_COM_DANDC float     sci_motor_Qref;
SRC_APP_COM_DANDC float     sci_motor_Href;
SRC_APP_COM_DANDC float     sci_motor_QminRef;
SRC_APP_COM_DANDC float     sci_motor_QmaxRef;

SRC_APP_COM_DANDC float     sci_motor_spdCmd;
SRC_APP_COM_DANDC float     sci_motor_GearCmd;

SRC_APP_COM_DANDC unsigned int CANtest_flg;
#endif /* SRC_APP_C_COM_DANDC_H_ */
