
#ifndef APP_PRESSCTRL_C
#define APP_PRESSCTRL_C

#include <app_include.h>

#define SPD_NUM_PWR    12
//FP400
//unsigned int  u16_liquid_sps_min_pwr[SPD_NUM_PWR]  ={11,16,25,45, 64, 95, 120,164, 220, 270, 330,330};
/*unsigned int  u16_liquid_sps_min_pwr[SPD_NUM_PWR] =
{8,  18,  35,  46,  69,
 102,140, 200, 270, 335,
 470,470};//������ṹ*/
//��֤����
unsigned int  u16_liquid_sps_min_pwr[SPD_NUM_PWR] =
{8,  18,  35,  46,  69,     //1000-3000
 98,135, 194, 260, 335,     //3500-5500
 460,460};//������ṹ         //6000-6500

/*unsigned int  u16_liquid_sps_min_pwr[SPD_NUM_PWR] =
{8,  18,  35,  46,  62,     //1000-3000
 95,127, 183, 245, 310,     //3500-5500
 350,350};//������ṹ         //6000-6500
*/


#define SELF_PRIME_MAXPWR   280 //W
#define SELF_PRIME_MAXTIME  (unsigned long)15*60*1000/250 //15MIN
#define IN_CLOSE_TIME  (unsigned long)5*1000/250 //5S
#define MS3_TIME_CNT  (unsigned long)3*1000/250 //3S

void  f_pressCtrl_Init(void)
{
    u16_runPressOLcnt=0;
    u16_pressCtrlEn=0;
    u16_SCI_FreezeEn=0;
    u16_runSelfPrimecnt=0;
    u16_runStopCnt=0;
    u16_runStop2Cnt=0;
    su_distDir=0;
    su_distCnt=0;
    PID_Ctrl_int();
    u16_StopCtrlFlg=0;
    u16_SelPrimeFlg=0;
    u16_tmpSensorErrFlg=0;
}

//250ms
void  f_pressCtrl(void)
{
    float f_temp,f_temp1;
    float f_spd_temp,f_pwr_temp;
    unsigned int    u16_temp;
    static unsigned int cntPwrLimit=0;
    static unsigned int press_set=0;
    static unsigned int start_flg=0,start_cnt=0;
    static Uint16 u16_pressSave=0,u16_pressScnt=0,u16_pressFlg=0;
    static float u16_SpdSet=0;
    static float u16_runCnt=0,u16_self_overFlg=0;
    static  unsigned int u16_satStopCnt=0,u16_satStopAlltime=0;
    static unsigned int u16_runRecCnt=0;
    static unsigned int u16_stopPressSaveFlg=0;
    static unsigned long u16_antiFreezeTime=0;
    static unsigned int u16_antiFreezeFlg=0;
    static unsigned int u16_startCnt=0;

    f_spd_temp = fabsf(motorSpd);
    f_pwr_temp = fabsf(motorPwr_f);//motorPwr_Lpf);

    //��������
    if(u_enable_HandC==1){
        if(u16_press>=(u16_pressCmd+500)){          //���Źص���ѹ��һֱ��������
           u16_runPressOLcnt++;
           if(u16_runPressOLcnt>12){     //3s
             u16_runPressOLcnt = 12;
             u16_pressCtrlEn=0;
             u16_stopPressSaveFlg=0;
           }
           u16_startCnt=0;
         }else if(u16_pressCmd>1500){
             if(u16_stopPressSaveFlg==1){
                 if(u16_pressSave<1400){
                     u16_pressSave=1400;
                 }
                 if((u16_press+400) <= u16_pressSave){
                    u16_pressCtrlEn=1;
                    u16_stopPressSaveFlg=0;
                    u16_StopCtrlFlg=0;
                 }
             }else{
                 if((u16_press+400) <= u16_pressCmd){
                      u16_pressCtrlEn=1;
                      u16_stopPressSaveFlg=0;
                      u16_StopCtrlFlg=0;
                 }
             }
             u16_runPressOLcnt = 0;
            // u16_StopCtrlFlg=0;
         }else if((u16_press+400) <= u16_pressCmd){//ʵ��ѹ���½�2.0�ף���������,΢©�½�2.0m��ʱ��
            u16_startCnt++;
            if(u16_startCnt>0){   //0s //1s
                u16_startCnt=0;
                if((u16_stopPressSaveFlg==1)&&(u16_pressCmd>1500)){
                   if(u16_pressSave<1400){
                       u16_pressSave=1400;
                   }
                   if((u16_press+400) <= u16_pressSave){
                       u16_pressCtrlEn=1;
                       u16_stopPressSaveFlg=0;
                       u16_StopCtrlFlg=0;
                   }
               }else{
                   u16_stopPressSaveFlg=0;
                   u16_pressCtrlEn=1;
                   u16_StopCtrlFlg=0;
               }
           }
           u16_runPressOLcnt = 0;
           //u16_StopCtrlFlg=0;
         }else{
           u16_startCnt=0;
           u16_runPressOLcnt=0;
         }
    }else{
        u16_startCnt=0;
        u16_runPressOLcnt=0;
        u16_pressCtrlEn=0;
        u16_stopPressSaveFlg=0;
        //u_fault_sta.bit.SelfPrimErr=0;
    }

    //E03�������ϣ��Զ���������
    //if((f_pwr_temp < SELF_PRIME_MAXPWR) && ((f_spd_temp+150) > powerLmt.Max)){  //SPEED_MAX)){     //15����δ���ϱ�E03
    if((u16_press < 200) && ((f_spd_temp+150) > SPEED_MAX)){//powerLmt.Max)){
        if( u16_press < 200 ){
           u16_runSelfPrimecnt++;
            if(u16_runSelfPrimecnt>SELF_PRIME_MAXTIME){
                u16_runSelfPrimecnt=SELF_PRIME_MAXTIME;
                //u16_pressCtrlEn=0;
                u_fault_sta.bit.SelfPrimErr = 1;
            }
            u16_SelPrimeFlg=1;
       }else if(u_fault_sta.bit.SelfPrimErr == 0){
           u16_runSelfPrimecnt = 0;
       }
       /*if(u16_press>300){
           u16_SelPrimeFlg=0;
       }*/
    }else{
        u16_runSelfPrimecnt = 0;
        u16_SelPrimeFlg=0;
    }

    //����ʱ�ط���
    /*if(motorVars_M1.flagEnableRunAndIdentify==1){
        if(u16_self_overFlg==0){
            if(u16_press > 200){
                u16_runCnt++;
                if(u16_runCnt>20){  //5s
                    u16_self_overFlg=1;
                    u16_runCnt=0;
                }
            }else{
                u16_runCnt=0;
            }
        }
        if(u16_self_overFlg==1){
            if((u16_press < 200) && ((f_spd_temp+150) > powerLmt.Max)){//SPEED_MAX)){
                u16_runCnt++;
                if(u16_runCnt>12){  //3s
                    u_fault_sta.bit.inCloseErr=1;
                    u16_runCnt = 0;
                }
            }else{
               u16_runCnt=0;
            }
        }
    }else{
        u16_runCnt=0;
        //u16_self_overFlg=0;
    }
    if(u_fault_sta.bit.inCloseErr==1){
        u16_runRecCnt++;
        if(u16_runRecCnt>28){    //7s+1s
            u16_runRecCnt=0;
            u_fault_sta.bit.inCloseErr=0;
        }
    }else{
        u16_runRecCnt=0;
    }*/

    //�����ж�
    if((s16_temper_medium<5)&&(u16_antiFreezeFlg==0)&&(motorVars_M1.flagEnableRunAndIdentify==0)){
        u16_antiFreezeTime++;
        if(u16_antiFreezeTime>80){     //20s*1000/250=80
            u16_antiFreezeTime=0;
            u16_antiFreezeFlg=1;
        }
    }else if(u16_pressCtrlEn==1){
        u16_antiFreezeTime=0;
        u16_antiFreezeFlg=0;
    }else{
        if(u16_antiFreezeFlg==0){
            u16_antiFreezeTime=0;
        }
    }


    //����PI����
    /*if((u16_SCI_FreezeEn==1)&&(u_enable_HandC==1)){    //��ʾ���������Ϳ�������
        f_temp = 500;   //50%
        PID_Ctrl_int();
        u16_runStopCnt = 0;
        u16_runStop2Cnt=0;
        su_distDir=0;
        su_distCnt=0;
        u16_pressCtrlEn=1;
        u16_StopCtrlFlg=0;
        u16_satStopCnt=0;
        u16_satStopAlltime=0;
        u16_stopPressSaveFlg=0;
    }else */if(u16_pressCtrlEn==1){
        if(su_distDir==1){
            pressCtrlLmt.Deta = u16_pressCmd + 300; //�Ŷ�3m
        }else{
            pressCtrlLmt.Deta = u16_pressCmd;
        }
        press_set= (unsigned int)pressCtrlLmt.Deta;
        //pressCtrlLmt.Deta = u16_pressCmd;
        pressCtrlLmt.Deta = pressCtrlLmt.Deta - u16_press;
        if(f_pwr_temp > (powerLmt.targetMax-20)){
            f_temp1 = f_spd_temp;
            f_temp1 = f_temp1*1000/SPEED_MAX;
            if(pressCtrlLmt.Out > (f_temp1+30)){
                cntPwrLimit++;
                if(cntPwrLimit>2){
                    cntPwrLimit=2;
                    pressCtrlLmt.Max = f_temp1+20;
                }
            }
        }else{
            cntPwrLimit=0;
            pressCtrlLmt.Max = 1000;
        }
        if(u16_StopCtrlFlg==0){
            PID((PID_STRUCT *)&pressCtrlLmt);
        }
        f_temp = pressCtrlLmt.Out;

        LINE_STRUCT pwr_spd_min = LINE_STRTUCT_DEFALUTS;
        //***����1��
        if(f_spd_temp < 1000){
            f_temp1 = u16_liquid_sps_min_pwr[0];
        }else if(f_spd_temp>6000){
            f_temp1 = u16_liquid_sps_min_pwr[SPD_NUM_PWR-1];
        }else{
            u16_temp = (f_spd_temp-1000)/500;
            if(u16_temp>(SPD_NUM_PWR-1)){
                u16_temp = SPD_NUM_PWR-1;
            }
            pwr_spd_min.x1 = u16_temp*500+1000;
            pwr_spd_min.x2 = pwr_spd_min.x1 + 500;
            pwr_spd_min.y1 = u16_liquid_sps_min_pwr[u16_temp];
            pwr_spd_min.y2 = u16_liquid_sps_min_pwr[u16_temp+1];
            pwr_spd_min.x =  f_spd_temp;
            pwr_spd_min.calc(&pwr_spd_min);
            f_temp1 = pwr_spd_min.y;    //ֵ��Ĳ���
        }
        //���п�ʼʱ����ʱ
        if(motorVars_M1.flagEnableRunAndIdentify==1){
            start_flg=1;
        }else{
            start_flg=0;
        }

        if(start_flg==0){
            u16_runStopCnt = 0;
            u16_runStop2Cnt=0;
            su_distDir=0;
            su_distCnt=0;
            start_cnt=0;
        }else if(start_flg==1){
            start_cnt++;
            if(start_cnt<12){ //3s  //16){    //4s
                u16_runStopCnt = 0;
                u16_runStop2Cnt=0;
                su_distDir=0;
                su_distCnt=0;
            }else{
                start_cnt = 17;
            }
        }

        //����ʱ���ж�
        if( (u16_press < 150 ) && ((f_spd_temp+150) > powerLmt.Max)){//SPEED_MAX)){
            u16_runStopCnt = 0;
            u16_runStop2Cnt=0;
            su_distDir=0;
            su_distCnt=0;
        }

        static unsigned int lowSPdCnt=0;
        //�����Ŷ�
        if(f_spd_temp < 3000){
            if(su_distDir==0){
                if( (u16_press < (press_set+100)) && ((u16_press+100) > press_set) ){
                    u16_runStop2Cnt=0;
                }else{
                    u16_runStop2Cnt++;
                }
            }else{
                u16_runStop2Cnt=0;
            }

            if(u16_runStop2Cnt>30){         //16*250=4s������δ������ѹ���仯ֵ��ͣ����
                u16_runStop2Cnt = 0;
                u16_pressCtrlEn=0;
                f_temp = 0;
            }
            su_distCnt++;
            if(su_distCnt>40){ //10s�Ŷ�һ��
              if( (u16_press < (press_set+100)) && ((u16_press+100) > press_set) ){
                if(su_distDir==0){
                     su_distDir=1;
                }else{
                     su_distDir=0;
                }
                su_distCnt = 0;
              }
            }
            u16_runStopCnt=0;
            lowSPdCnt=0;
        }else{
            //su_distCnt=0;
            lowSPdCnt++;
            if(lowSPdCnt>12){
                lowSPdCnt=0;
                u16_runStop2Cnt=0;
                su_distDir=0;
            }

            if((f_pwr_temp < f_temp1)&&(u16_StopCtrlFlg==0)){
                u16_runStopCnt++;
                if(u16_runStopCnt > 12){    //3s    //20){   //5s
                    u16_runStopCnt = 0;
                    u16_pressCtrlEn=0;
                    f_temp = 0;
                    /*if(u16_pressCmd>2800){
                        u16_StopCtrlFlg=0;
                    }else{
                        u16_StopCtrlFlg=1;
                    }*/
                    u16_StopCtrlFlg=1;
                }
            }else{
               u16_runStopCnt = 0;
            }
            f_temp1 = f_temp1+15;
            if(f_pwr_temp>f_temp1){
                //u16_StopCtrlFlg=0;
            }
            if((u16_StopCtrlFlg==1)&&(u16_stopPressSaveFlg==0)){
                u16_pressSave = u16_press;
                u16_stopPressSaveFlg=1;
            }
        }


        if((u16_StopCtrlFlg==0)&&(u16_satStopCnt==0)){
            u16_satStopAlltime=0;
        }
        if(u16_satStopAlltime>100){
            u16_satStopAlltime=0;
        }
        /*u16_satStopAlltime++;
        if(u16_satStopAlltime<50){      //12.5s������ͣ����
            if(u16_satStopCnt>1){
                u16_pressCtrlEn=0;
                u16_StopCtrlFlg=0;
                u16_satStopAlltime=0;
                u16_satStopCnt=0;
                u16_stopPressSaveFlg=1;
            }
        }*/
        /*static unsigned int time_cnt=0;
        if(u16_StopCtrlFlg==1){
            if(u16_pressFlg==0){
                f_temp = fabsf(motorSpd)/powerLmt.Max;
                if(fabsf(motorSpd)>4500){
                    f_temp = f_temp*1000-46;//19;
                }else{
                    f_temp = f_temp*1000-46;
                }
                //f_temp = f_temp*1000-46;//37;  //19:103; 27:150; 37:200; 46:250; 55:300; 74:400; 92:500
                u16_SpdSet = f_temp;
                u16_pressFlg=1;
                u16_pressCtrlEn=1;
                u16_pressSave = u16_press;
                u16_pressScnt=0;
                u16_satStopCnt++;
            }else{
                u16_pressScnt++;
                time_cnt++;
                if(time_cnt<3){
                    f_temp = u16_SpdSet+34;
                }else if(time_cnt<6){
                    f_temp = u16_SpdSet+22;
                }else if(time_cnt<9){
                    f_temp = u16_SpdSet+10;
                }else if(time_cnt<12){
                    f_temp = u16_SpdSet;
                    time_cnt=10;
                }

                if(u16_pressScnt>12){       //3s->5s
                    u16_StopCtrlFlg=0;
                    u16_pressScnt=20;
                    time_cnt=0;
                    if(u16_pressSave<(u16_press+130)){//130)){
                        u16_pressCtrlEn=0;
                        u16_satStopCnt=0;
                        u16_stopPressSaveFlg=1;
                        u16_startCnt=0;
                    }
                    else{
                        u16_pressCtrlEn=1;
                        //u16_stopPressSaveFlg=0;
                    }
                }else{
                    u16_pressCtrlEn=1;
                }
            }
        }else{
            u16_pressFlg=0;
            u16_pressScnt=0;
        }*/
        if(CANtest_flg==1){
        }else{
      #if HMI_CONTROL_EN==3
             u_sci_enable.bit.can_enable = u16_pressCtrlEn;
      #endif
        }
    }else if((u16_SCI_FreezeEn==1)||(u16_antiFreezeFlg==1)||(u16_tmpSensorErrFlg==1)){//&&(u_enable_HandC==1)){    //��ʾ���������Ϳ�������
        f_temp = 500;   //50%
        PID_Ctrl_int();
        u16_runStopCnt = 0;
        u16_runStop2Cnt=0;
        su_distDir=0;
        su_distCnt=0;
        if(CANtest_flg==1){
        }else{
    #if HMI_CONTROL_EN==3
            if(u16_tmpSensorErrFlg==1){
                u_sci_enable.bit.can_enable=1;
            }else if(u_enable_HandC==1){
                u_sci_enable.bit.can_enable=1;
            }else{
                if((u16_antiFreezeFlg==1)&&(u16_SCI_FreezeEn==1)){
                    u16_antiFreezeTime++;
                    if(u16_antiFreezeTime>9600){     //40min*60*1000/250=9600
                       u_sci_enable.bit.can_enable=0;
                       u16_antiFreezeFlg=0;
                       u16_antiFreezeTime=0;
                    }else{
                       u_sci_enable.bit.can_enable=1;
                    }
                }else{
                    u_sci_enable.bit.can_enable=0;
                }
            }
    #endif
        }
        //u16_pressCtrlEn=1;
        u16_StopCtrlFlg=0;
        u16_satStopCnt=0;
        u16_satStopAlltime=0;
        u16_stopPressSaveFlg=0;
    }else{
        if(u16_StopCtrlFlg==0){
            PID_Ctrl_int();
            f_temp = 0;
            u16_runStopCnt = 0;
            u16_runStop2Cnt=0;
            su_distDir=0;
            su_distCnt=0;

            u16_pressFlg=0;
            u16_pressScnt=0;
            //u16_stopPressSaveFlg=0;
        }else{
            f_temp=f_spd_temp*1000.0f;
            f_temp=f_temp/powerLmt.Max;
        }
        u16_satStopCnt=0;
        u16_satStopAlltime=0;
        if(CANtest_flg==1){
        }else{
    #if HMI_CONTROL_EN==3
            u_sci_enable.bit.can_enable = u16_pressCtrlEn;
    #endif
        }
    }

    if(CANtest_flg==1){ //ͨѶ����ʱ��Ч
        PID_Ctrl_int();
        f_temp = 0;
        u16_runStopCnt = 0;
    }else{
#if HMI_CONTROL_EN==3
        //PI���ڸ�ֵ
        u_speed_HandC = (unsigned int)f_temp;
        u_speed_can = u_speed_HandC;
        //u_sci_enable.bit.can_enable = u16_pressCtrlEn;
#endif
    }

}

void PID_Ctrl_int(void)
{
    pressCtrlLmt.KP = 0.08;
    pressCtrlLmt.KI = 0.03;
    pressCtrlLmt.KD = 0;
    pressCtrlLmt.Max = 1000;    //���ת��100.0%
    pressCtrlLmt.Min = 200;
    pressCtrlLmt.Total = 200;
    pressCtrlLmt.Out = 200;
    pressCtrlLmt.Deta = 0;
    pressCtrlLmt.Flag = 0;
    pressCtrlLmt.OutFlag = 0;
}

#endif
