#ifndef	APP_PWRANDLIMIT_C_
#define	APP_PWRANDLIMIT_C_

#include "app_include.h"

extern volatile MOTOR_Vars_t motorVars_M1;

void powerAndLmtInit()
{
	sPID_pwrLmt.kp = 0.1;			//kp
	sPID_pwrLmt.ki = 0.005;			//ki
	sPID_pwrLmt.integral_sum = 0;		//������
	sPID_pwrLmt.out_value = 0;
	sPID_pwrLmt.integral_max = 500;		//���������ֵ��500RPM
	outpower = 0;		//���㹦��

	sPID_pwrLmt.power_max = MAX_POWER;  //1200;		//�����趨���ֵ��1200w
	sPID_pwrLmt.outlimit_upper = SPEED_MAX; //3500;	//������ֵ��3500rpm
	sPID_pwrLmt.outlimit_lower = 0;

	//outpowerCal_k = 0.8;
	outpowerCal_k = 3.1;//3;//2.8 * 1.05;
}

void powerCal()
{
	float temp,temp2,tempId,tempIq,tempVd,tempVq;
    static float f_power[4]={0,0,0,0};
	//��ʽ1��ֱ�Ӳ�������
	/*temp = 0;
	outpower = temp * 1 + outpower * 9;
	outpower = outpower/10;		//��λw*/

	//���������ѹ�͵������м���
    /*f_power[0] = f_power[1];
    f_power[1] = f_power[2];
    f_power[2] = f_power[3];
    f_power[3] = motorVars_M1.Vs_V;
    temp2 = f_power[0] + f_power[1] + f_power[2] + f_power[3];
    temp2 = temp2*0.25;
    temp = fabs(outpowerCal_k *temp2 * iq_ref_f);*/

    /*temp = vq_fbk_f;//motorVars_M1.Vs_V;
    f_power[0] = temp * 0.1 + f_power[0] * 0.9;
    temp = fabs(outpowerCal_k * f_power[0] * iq_ref_f);*/

	temp = fabs(outpowerCal_k * motorVars_M1.Vs_V * iq_ref_f);//iq_fbk_f);//iq_ref_f);//motorVars_M1.Is_A;
	outpower = temp;// * 0.1 + outpower * 0.9;

    /*temp = 0;//id_ref_f*vd_fbk_f;   //id_ref_f,id_fbk_f
    temp2 = iq_ref_f * motorVars_M1.Vs_V ;//vq_fbk_f;  //iq_ref_f,iq_fbk_f
    temp = temp+temp2;
    outpower = fabs(temp);*/


	/*temp = fabs(outpowerCal_k * (vd_fbk_f * id_fbk_f + vq_fbk_f * iq_fbk_f));//iq_fbk_f);
	f_power[0] = f_power[1];
    f_power[1] = f_power[2];
    f_power[2] = f_power[3];
    f_power[3] = temp;
	temp = f_power[0] + f_power[1] + f_power[2] + f_power[3];
	outpower = temp/4;*/
}

float pmsm_pi_controller(float given, float feedback, _sPID_ *pid)
{
    float error;
    float proportion;
    float integral;
    static float out_value=0;
    static float integral_sum_tmp=0;

    error = given - feedback;
    proportion = error * (pid->kp);				//������

    integral = error * (pid->ki);
    integral_sum_tmp = pid->integral_sum + integral;	//�����ۼ���
    if(integral_sum_tmp>pid->outlimit_upper){
    	integral_sum_tmp=pid->outlimit_upper;
    }else if(integral_sum_tmp < pid->outlimit_lower){
    	integral_sum_tmp=pid->outlimit_lower;
    }
    out_value = proportion + integral_sum_tmp;	//�������ֵ
    if (out_value > pid->outlimit_upper){		//�����������ֵ��������
        out_value = pid->outlimit_upper;
    }else if (out_value < pid->outlimit_lower){	//�����������ֵ��������
        out_value = pid->outlimit_lower;
    }else{
        pid->integral_sum = integral_sum_tmp;	//��ʼʱִ��
    }
    return out_value;
}

#endif
