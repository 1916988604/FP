#ifndef	APP_SPEEDRAMP_C_
#define	APP_SPEEDRAMP_C_

#include "app_include.h"

/*************************************************************************************************/
//���������u16_PreRelaySta.bit.preRelayOn�� motorVars_M1.flagEnableRunAndIdentify�� f_speed_gear
//������Դ��������Ԥ���߼�

//�����speed_ramp_cmd��
/*************************************************************************************************/

void speedRamp_init()
{
    speed_ramp_cmd = 0;
    f_speed_gear = 0;
    vcu_speedRampCmd = 0;
}

void LinearRamp(float cmd, float* ref, float upStep, float downStep, float upLimit, float downLimit)
{
//========================================================================================
// Temporary variable definition (execute time: ?? CPUCLK)
//========================================================================================
	float		step	= 0;
	float   temp;
//========================================================================================
// ���������޷� (execute time: ?? CPUCLK)
//========================================================================================
	cmd	= min(cmd, upLimit);
	cmd	= max(cmd, downLimit);
//========================================================================================
// Ramp���򼰲���ȷ�� (execute time: ?? CPUCLK)
//========================================================================================
	temp = (*ref) * cmd;
	if (temp < 0)
	{
		step = downStep;
	}
	else
	{
		step = (fabsf(*ref) < fabsf(cmd)) ? upStep : downStep;
	}
//========================================================================================
// Ramp (execute time: ?? CPUCLK)
//========================================================================================
	if ((*ref) + step < cmd)
	{
		(*ref) += step;
	}
	else if ((*ref) - step > cmd)
	{
		(*ref) -= step;
	}
	else
	{
		(*ref)	= cmd;
	}
	//=====================
	(*ref)	= min((*ref), upLimit);
	(*ref)  = max((*ref), downLimit);
}


void speedRamp()
{
	float upStep,downStep,upLimit,downLimit;

	upLimit = SPEED_MAX;
	downLimit = -upLimit;
    upStep = UP_STEP_SPEED;         //50;
    downStep = DOWN_STEP_SPEED;     //50;       //50RPM

    if((u16_PreRelaySta.bit.preRelayOn == 1) && (u16_PreRelaySta.bit.pfcCtrlOn == 1)){
        if(u_motor_ctrl.bit.run_enable == 1){
            LinearRamp(vcu_speedRampCmd,&f_speed_gear,upStep,downStep, upLimit, downLimit);
        }else{
            f_speed_gear = 0;
            vcu_speedRampCmd = 0;
        }
        motorVars_M1.speedRef_Hz = f_speed_gear*0.016666 * USER_MOTOR1_NUM_POLE_PAIRS*vcu_speedDirCmd;
        motorVars_M1.flagEnableRunAndIdentify = u_motor_ctrl.bit.run_enable;
    }else{
        speed_ramp_cmd = 0;
        vcu_speedRampCmd = 0;
        f_speed_gear = 0;
        motorVars_M1.speedRef_Hz = 0;
        motorVars_M1.flagEnableRunAndIdentify = 0;
    }
}


#endif
