
#ifndef SRC_APP_C_ADI_H_
#define SRC_APP_C_ADI_H_

#include "f280015x_device.h"


#define     SCI_DtoC_EN     1
#define     SCI_HtoC_EN     0
#define     SCI_485_EN      0

#define    control_PCBA     0
#define    driverES_PCBA    1
#define    display_PCBA     2
#define    driverMegaS_PCBA 3

#define     PCBA_TYPE   driverES_PCBA   //0:���ư壻 1��������(����);  2:��ʾ��;  3�������壨MegaS��

/************************************************************************/

#define     SPD_MAX     1000     //100.0%, 0.1�ֱ���
#define     SPD_MIN     200
#define     SPD_MID     200

//���ư����ã�������δ�ô˹���
#if PCBA_TYPE != control_PCBA
    #define     K1_DI       6
    #define     K2_DI       6
    #define     K3_DI       6
    #define     Relay1_IO   6
    #define     Relay2_IO   6
#endif

//led ��ʾ�⣬δ��
#define setclk      GPIO_writePin(0,1);
#define resetclk    GPIO_writePin(0,0);
#define setdio      GPIO_writePin(1,1);
#define resetdio    GPIO_writePin(1,0);
#define datadio     GPIO_readPin(1)

/****************************************************************************/


typedef enum
{
    AI_A=0,
    AI_B=1,
    AI_C=2,
    AI_D=3
} AI_MODE;

typedef enum
{
    PTC100,
    PTC1000,
    NTC10K,
    CRM60,
    DPM15C60DG1
} TEMPSENSOR_TYPE;

typedef enum
{
    AI_VI,
    AI_HEAD,
    AI_LIQUID
} ADI_TYPE;

typedef enum
{
    TEMP_IN,
    TEMP_EXT,
    TEMP_DIFF,
} TEMP_TYPE;

typedef enum
{
    HEAT,
    COLD
} SYS_TYPE;


// ����(x1,y1), (x2,y2), �������(x, y)��y
// ��ȷ��: x1 < x2
typedef struct
{
    void (*calc)(void *);     // Pointer to calculation functon

    int16 mode;               // 1����ʾx��y���޷���0���޷�

    /*int32 x1;
    int32 y1;                 // (x1,y1)
    int32 x2;
    int32 y2;                 // (x2,y2)

    int32 x;                  // ��Ҫ����(x,y)��x, ����
    int32 y;                  // ��Ҫ����(x,y)��y, ���
    */
    float x1;
    float y1;                 // (x1,y1)
    float x2;
    float y2;                 // (x2,y2)

    float x;                  // ��Ҫ����(x,y)��x, ����
    float y;                  // ��Ҫ����(x,y)��y, ���
} LINE_STRUCT;


#define LINE_STRTUCT_DEFALUTS       \
{                                   \
    (void (*)(void *))LineCalc      \
}

typedef struct
{
    void (*calc)(void *);         // Pointer to calculation functon

    /*int32 t;                      // �˲�ʱ��

    int32 in;                     // ����
    int32 out;                    // ���

    int32 outOld;                 // ��һ�ε����
    int32 remainder;              // ��������е�����*/

    float t;                      // �˲�ʱ��
    float in;                     // ����
    float out;                    // ���

    float outOld;                 // ��һ�ε����

} LowPassFilter;


#define LPF_DEFALUTS            \
{                               \
    (void (*)(void *))LpfCalc   \
}

typedef  struct MOTOR_EN_SCI_BIT
{
    unsigned int  ai1_enable    :1;
    unsigned int  pwm_enable    :1;
    unsigned int  lin_enable    :1;
    unsigned int  can_enable    :1;

    unsigned int  canfd_enable  :1;
    unsigned int  e485_enable   :1;
    unsigned int  lin_errRst    :1;
    unsigned int  can_errRst    :1;

    unsigned int  canfd_errRst  :1;
    unsigned int  e485_errRst   :1;
    unsigned int  rsv           :6;
}_MOTOR_EN_SCI_BIT_;

typedef union MOTOR_ENSCI {
    unsigned int  all;
    struct  MOTOR_EN_SCI_BIT  bit;
}_MOTOR_ENSCI_;


typedef  struct MOTOR_CTRL_LOGIC_BIT
{
    unsigned int  ai2_ctrlDir    :2;    //0:���߼��� 1�����߼�
    unsigned int  ai3_ctrlDir    :2;
    unsigned int  night_ctrlMode :1;
    unsigned int  spdMaxEn       :1;
    unsigned int  spdMinEn       :1;
    unsigned int  rsv            :9;
}_MOTOR_CTRL_LOGIC_BIT_;

typedef union MOTOR_CTRL_LOGIC {
    unsigned int  all;
    struct  MOTOR_CTRL_LOGIC_BIT  bit;
}_MOTOR_CTRL_LOGIC_;

#ifdef  SRC_APP_ADI_C_
    #define SRC_APP_ADI
#else
    #define SRC_APP_ADI  extern
#endif

SRC_APP_ADI void LineCalc(LINE_STRUCT *p);
SRC_APP_ADI void LpfCalc(LowPassFilter *p);
SRC_APP_ADI void Ai1Calc(void);
SRC_APP_ADI void Ai2Calc(void);
SRC_APP_ADI void Ai3Calc(void);
SRC_APP_ADI void Ai4Calc(void);
SRC_APP_ADI void Ai5Calc(void);
SRC_APP_ADI void Ai6Calc(void);
SRC_APP_ADI void Ai7Calc(void);
SRC_APP_ADI void AiCalc_init(void);
SRC_APP_ADI void adi_Ctrl(void);
SRC_APP_ADI float aiFilterTime[7];
SRC_APP_ADI float aiDeal[5];
SRC_APP_ADI TEMPSENSOR_TYPE temoSensorType,temoSensorExType;
SRC_APP_ADI void GetTemperature();
SRC_APP_ADI void GetTempMediumEx();
SRC_APP_ADI float GetTemperatureCalc(float voltage, const Uint16 *p, Uint16 len, Uint16 sensorSel);
SRC_APP_ADI float temperature,tempeMediumEx;
SRC_APP_ADI Uint16 u16_DI1_sta;
SRC_APP_ADI Uint16 u16_DI2_sta;
SRC_APP_ADI Uint16 u16_DI3_sta;
SRC_APP_ADI Uint16 ai1InMode;
SRC_APP_ADI Uint16 ai2InMode;
SRC_APP_ADI Uint16 e485Mode;

SRC_APP_ADI float ai_vol_E;
SRC_APP_ADI float ai_vol_F;
SRC_APP_ADI float ai_vol_G;
SRC_APP_ADI float tempValue_set;
SRC_APP_ADI float tempDifValue_set;
SRC_APP_ADI Uint16 tempSoruceSel;
SRC_APP_ADI Uint16 sysSoruceSel;
SRC_APP_ADI union MOTOR_ENSCI u_sci_enable;
SRC_APP_ADI union MOTOR_CTRL_LOGIC u_ctrl_logic;
//���ư��ź�
SRC_APP_ADI uint16_t u_speed_can;
SRC_APP_ADI uint16_t u_speed_lin;
SRC_APP_ADI uint16_t u_speed_e485;
SRC_APP_ADI uint16_t u_speed_canfd;
SRC_APP_ADI float u_speed_vi[4];
SRC_APP_ADI uint16_t u_enable_HandC;
SRC_APP_ADI uint16_t modeNightFlg;


#endif /* SRC_APP_C_ADI_H_ */
