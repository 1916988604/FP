
#ifndef SRC_APP_APP_INCLUDE_H_
#define SRC_APP_APP_INCLUDE_H_

#define     SW_VER_NUMBER        1
#define     HW_VER_NUMBER        11
#define     PUMP_VER_NUMBER      12

#include "f280015x_device.h"
#include "sys_main.h"

#include <C_adi.h>
#include <C_com_lin.h>
#include <C_inputPWM.h>
#include <C_led.h>
#include <C_outputPWM.h>
#include <C_relay.h>
#include <C_com_common.h>
#include <C_com_Modbus.h>
#include <C_lin.h>

#include <C_relay.h>
#include <D_gear.h>
#include <D_PreRelay_Ctrl.h>
#include <D_PwrAndLimit.h>
#include <D_QHcal.h>
#include <D_SpeedRamp.h>
#include <D_SpeedRamp.h>
#include <D_UDC_Adjust.h>
#include <C_com_DandC.h>
#include <C_com_HandC.h>
#include <D_IGBT_Temp.h>
#include <C_i2c.h>
#include <C_menu.h>

#include "Flash_Update.h"
#include "App_CanDebug.h"
#include "App_Fault_Shinhoo.h"
#include "timertask.h"


#endif /* SRC_APP_APP_INCLUDE_H_ */
