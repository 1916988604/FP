
#ifndef APP_SPEEDRAMP_H_
#define APP_SPEEDRAMP_H_

#define     UP_STEP_SPEED     50
#define     DOWN_STEP_SPEED   50

#define min(a,b)                (((a) < (b)) ? (a) : (b))
#define max(a,b)                (((a) > (b)) ? (a) : (b))


#ifdef  APP_SPEEDRAMP_C_
    #define APP_SPEEDRAMP
#else
    #define APP_SPEEDRAMP  extern
#endif

APP_SPEEDRAMP void speedRamp();
APP_SPEEDRAMP void LinearRamp(float cmd, float* ref, float upStep, float downStep, float upLimit, float downLimit);
APP_SPEEDRAMP void speedRamp_init();

APP_SPEEDRAMP float speed_ramp_cmd;

#endif /* APP_SPEEDRAMP_H_ */
