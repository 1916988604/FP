#ifndef	APP_PRERELAYCTRL_C
#define	APP_PRERELAYCTRL_C


#include <app_include.h>


#define     test_1      0   //0:����Ԥ���߼���1:DEBUG����
#define     PRERELAY_VALID      1   //Ԥ��̵�����·��Чʹ�ܡ� 0:��Ч��1:��Ч
#define     PFC_CTRL_VALID      0   //PFC��·��Чʹ�ܡ� 0:��Ч��1:��Ч
/*************************************************************************************************/
//���������motorVars_M1.adcData.VdcBus_V��
//������Դ��������AD������ѹֵ���

//�����u16_PreRelaySta.bit.preRelayOn
/*************************************************************************************************/

void f_preRelayCtrlInit()
{
	u16_PreRelayCtrl.preRelayOnCnt=0;
	u16_PreRelayCtrl.preRelayOffCnt=0;
	u16_PreRelayCtrl.preRelayVol = 0;
	u16_PreRelaySta.all = 0;
    u16_PreRelayCtrl.pfcCtrlOnCnt=0;
    u16_PreRelayCtrl.pfcCtrlOffCnt=0;
/**************relay control. ����Ч***************************/
	PRE_RELAY_OFF_CTRL;
/**************PFC control. ����Ч***********************************************/
	PFC_OFF_CTRL;
}

//10ms����
void f_preRelayCtrl()
{
    //Ԥ��̵�������
#if test_1==1
    if((debug_cmd.debugEn == 1)&&(motorVars_M1.flagEnableRunAndIdentify==0)){
        if(debug_cmd.Relay1En == 1){
            PRE_RELAY_ON_CTRL;
        }else{
            PRE_RELAY_OFF_CTRL;
        }
        if(debug_cmd.Relay2En == 1){
            PFC_ON_CTRL;
        }else{
            PFC_OFF_CTRL;
        }
        if((debug_cmd.Relay1En == 1)&&(debug_cmd.Relay2En == 1)){
            u16_PreRelaySta.bit.preRelayOn=1;
            u16_PreRelaySta.bit.pfcCtrlOn =1;
        }else{
            u16_PreRelaySta.bit.preRelayOn=0;
            u16_PreRelaySta.bit.pfcCtrlOn =0;
        }
    }else{}
#elif test_1==0
        //����ĸ�ߵ�ѹ�͵�����ѹ�ж�Ԥ�䣬�ʺϽ�����ѹ����
        u16_PreRelayCtrl.preRelayVol = (Uint16)(motorVars_M1.adcData.VdcBus_V);
        if( (u16_PreRelayCtrl.preRelayVol > ((Uint16)(Temp_IGBT.V_LN_Lpf*1.2))) && (Temp_IGBT.V_LN_Lpf > 140) ){
            u16_PreRelayCtrl.preRelayOffCnt=0;
            u16_PreRelayCtrl.preRelayOnCnt++;
            if(u16_PreRelayCtrl.preRelayOnCnt>60){
                PRE_RELAY_ON_CTRL;
                u16_PreRelayCtrl.preRelayOnCnt = 60;
                u16_PreRelaySta.bit.preRelayOn = 1;     //�̵����պϱ�־λ
            }else if(u16_PreRelayCtrl.preRelayOnCnt>49){    //0.5s
                PRE_RELAY_ON_CTRL;      //H���̵����պ�
            }
        }else if(Temp_IGBT.V_LN_Lpf < 160){//PRE_RELAY_VOL_OFF){
            u16_PreRelayCtrl.preRelayOnCnt = 0;
            u16_PreRelayCtrl.preRelayOffCnt++;
            if(u16_PreRelayCtrl.preRelayOffCnt>30){
                PRE_RELAY_OFF_CTRL;     //L���̵����Ͽ�
                u16_PreRelayCtrl.preRelayOffCnt = 3;
            }else if(u16_PreRelayCtrl.preRelayOffCnt>20){
                u16_PreRelaySta.bit.preRelayOn = 0;
                MOTOR_EN_DISBLE_CTRL;       //�����ر�
            }
        }

        //����ĸ�ߵ�ѹ�ж�Ԥ�䣬�ʺ�ֱ���糡��
        /*u16_PreRelayCtrl.preRelayVol = (Uint16)(motorVars_M1.adcData.VdcBus_V);
        if(u16_PreRelayCtrl.preRelayVol > PRE_RELAY_VOL_ON){
            u16_PreRelayCtrl.preRelayOffCnt=0;
            u16_PreRelayCtrl.preRelayOnCnt++;
            if(u16_PreRelayCtrl.preRelayOnCnt>60){
                PRE_RELAY_ON_CTRL;
                u16_PreRelayCtrl.preRelayOnCnt = 60;
                u16_PreRelaySta.bit.preRelayOn = 1;		//�̵����պϱ�־λ
            }else if(u16_PreRelayCtrl.preRelayOnCnt>49){	//0.5s
                PRE_RELAY_ON_CTRL;		//H���̵����պ�
            }
        }else if(u16_PreRelayCtrl.preRelayVol < PRE_RELAY_VOL_OFF){
            u16_PreRelayCtrl.preRelayOnCnt = 0;
            u16_PreRelayCtrl.preRelayOffCnt++;
            if(u16_PreRelayCtrl.preRelayOffCnt>30){
                PRE_RELAY_OFF_CTRL;     //L���̵����Ͽ�
                u16_PreRelayCtrl.preRelayOffCnt = 3;
            }else if(u16_PreRelayCtrl.preRelayOffCnt>20){
                u16_PreRelaySta.bit.preRelayOn = 0;
                MOTOR_EN_DISBLE_CTRL;       //�����ر�
            }
        }*/
        //u16_PreRelaySta.bit.preRelayOn = 1;
#if   PFC_CTRL_VALID==1
        //PFC����
        if(u_motor_ctrl.bit.run_enable == 1){
            u16_PreRelayCtrl.pfcCtrlOffCnt = 0;
            PFC_ON_CTRL;
            u16_PreRelayCtrl.pfcCtrlOnCnt++;
            if(u16_PreRelayCtrl.pfcCtrlOnCnt > 5){  //60ms
                u16_PreRelaySta.bit.pfcCtrlOn = 1;
                u16_PreRelayCtrl.pfcCtrlOnCnt = 6;
            }
        }else{
            u16_PreRelayCtrl.pfcCtrlOnCnt = 0;
            if(motorVars_M1.flagEnableRunAndIdentify==0){
                u16_PreRelayCtrl.pfcCtrlOffCnt++;
                if(u16_PreRelayCtrl.pfcCtrlOffCnt > 1){ //20ms
                    PFC_OFF_CTRL;
                    u16_PreRelaySta.bit.pfcCtrlOn = 0;
                    u16_PreRelayCtrl.pfcCtrlOffCnt = 2;
                }
            }
        }
#else
        u16_PreRelaySta.bit.pfcCtrlOn = 1;
#endif

#endif
}



#endif
