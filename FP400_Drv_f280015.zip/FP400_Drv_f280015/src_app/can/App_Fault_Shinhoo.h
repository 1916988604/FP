#ifndef APP_FAULT_SHINHOO_H_
#define APP_FAULT_SHINHOO_H_

typedef  struct	MOTOR_CTRL_BIT
{
	unsigned int  run_enable	:1;
	unsigned int  err_reset		:1;
	unsigned int  run_enaDly	:1;
	unsigned int  err_rstFbk	:1;

	unsigned int  run_enaFbk	:1;
    unsigned int  enableCAN     :1;
    unsigned int  enableCANFD   :1;
    unsigned int  enable485     :1;

    unsigned int  enablePWM     :1;
    unsigned int  enableLIN     :1;
    unsigned int  enable        :1;
    unsigned int  rsv           :5;

}_MOTOR_CTRL_BIT_;

typedef	union MOTOR_CTRL {
    unsigned int  all;
    struct  MOTOR_CTRL_BIT  bit;
}_MOTOR_CTRL_;

typedef  struct	FAULT_BIT
{
	unsigned int  igbt_OTwarn	:1;		//IGBT����2��
	unsigned int  canErr		:1;
	unsigned int  idc_warn		:1;		//ĸ�߹���2��
	unsigned int  oc_warn		:1;		//�����2��
	unsigned int  udc_ov		:1;		//ĸ�߹�ѹ1��
	unsigned int  udc_lv		:1;		//ĸ��Ƿѹ1��
	unsigned int  ol			:1;
	unsigned int  igbt_OT		:1;		//IGBT����1��

	unsigned int  load_no		:1;
	unsigned int  zeroSpd		:1;
	unsigned int  os			:1;
	unsigned int  revSpd		:1;
	unsigned int  tz			:1;
	unsigned int  oc			:1;		//�����1��
	unsigned int  udc_oc		:1;		//ĸ�߹���1��
	unsigned int  checkErr		:1;

	unsigned int  sersorOpen	:1;
	unsigned int  sersorShort	:1;
	unsigned int  hilErr		:1;
	unsigned int  selfchkErr	:1;
	unsigned int  startErr		:1;
	unsigned int  spdHighErr2	:1;
	unsigned int  spdLowErr		:1;
	unsigned int  spdLowErr2	:1;

	unsigned int  spdDifHighErr2	:1;
	unsigned int  spdDifHighErr3	:1;
	unsigned int  spdDifLowErr2		:1;
	unsigned int  spdDifLowErr3		:1;
	unsigned int  udc_ov2		:1;		//ĸ�߹�ѹ2��
	unsigned int  udc_lv2		:1;		//ĸ��Ƿѹ2��
	unsigned int  canwarn		:1;
	//unsigned int  checkwarn		:1;
	unsigned int  pfcErr        :1;
}_FAULT_BIT_;

typedef	union FAULT_STA {
    unsigned long  all;
    struct  FAULT_BIT  bit;
}_FAULT_STA_;

typedef  struct	WARN_BIT
{
	unsigned int  igbt_OTwarn	:1;		//IGBT����3��
	unsigned int  canwarn		:1;
	unsigned int  idc_warn		:1;		//ĸ�߹���3��
	unsigned int  oc_warn		:1;		//�����3��
	unsigned int  udcovwarn		:1;		//ĸ�߹�ѹ3��
	unsigned int  udclvwarn		:1;		//ĸ��Ƿѹ3��
	unsigned int  rsv1			:1;
	unsigned int  rsv2			:1;

	unsigned int  loadNcWarn	:1;
	unsigned int  zeroSpd		:1;
	unsigned int  rsv5			:1;
	unsigned int  rsv6			:1;
	unsigned int  rsv7			:1;
	unsigned int  udc_err		:1;
	unsigned int  outPwrWarnFlg	:2;		//���ʱ���
}_WARN_BIT_;

typedef	union WARN_STA {
    unsigned int  all;
    struct  WARN_BIT  bit;
}_WARN_STA_;

typedef  struct	FAULT_CNT
{
	unsigned int  udc_ov_cnt		:16;
	unsigned int  udc_lv_cnt		:16;
	unsigned int  oc_cnt			:16;
	unsigned int  ol_cnt			:16;
	unsigned int  igbt_OT_cnt		:16;
	unsigned int  load_no_cnt		:16;
	unsigned int  zeroSpd_cnt		:16;
	unsigned int  canErr_cnt		:16;

	unsigned int  os_cnt			:16;
	unsigned int  recSpd_cnt		:16;
	unsigned int  udcoc_cnt			:16;
	unsigned int  idc_warncnt		:16;
	unsigned int  oc_warn_cnt		:16;
	unsigned int  phaseCnc_cnt		:16;

	unsigned int  igbt_OT2_cnt		:16;
	unsigned int  igbt_OT3_cnt		:16;
	unsigned int  oc_warn3_cnt		:16;
	unsigned int  idc_warn3_cnt		:16;

	unsigned int  udc_ov2_cnt		:16;
	unsigned int  udc_ov3_cnt		:16;
	unsigned int  udc_lv2_cnt		:16;
	unsigned int  udc_lv3_cnt		:16;
	unsigned int  hvilcnt			:16;
	unsigned int  sersSht_cnt		:16;
	unsigned int  sersOpn_cnt		:16;

	unsigned int  os_warncnt		:16;
	unsigned int  spdL_warncnt		:16;
	unsigned int  spdL_cnt			:16;
	unsigned int  spddiffL2_cnt		:16;
	unsigned int  spddiffL3_cnt		:16;
	unsigned int  spddiffH2_cnt		:16;
	unsigned int  spddiffH3_cnt		:16;

	unsigned int  crc_cnt			:16;
	unsigned int  pwrWarn_cnt		:16;
	unsigned int  loadNcWarn_cnt	:16;
	unsigned int  pfc_cnt           :16;
    unsigned int  uln_ov_cnt        :16;
    unsigned int  uln_lv_cnt        :16;

    unsigned int  zero_spdErrCnt    :16;

	float udc_errChk;
    float spd_errChk;
    float is_errChk;
    float idc_errChk;
    float Vln_errChk;

}_FAULT_CNT_;

#ifdef  APP_FAULTSHINHOO_C
    #define APPFAULT
#else
    #define APPFAULT  extern
#endif

APPFAULT union	WARN_STA	u_warn_sta;
APPFAULT union	FAULT_STA	u_fault_sta;
APPFAULT union	FAULT_STA	u_fault_recFlg;

APPFAULT struct	FAULT_CNT	fault_cnt;
APPFAULT struct	FAULT_CNT	fault_recCnt;
APPFAULT union	MOTOR_CTRL	u_motor_ctrl;
APPFAULT void f_faultCheck_Init(void);
APPFAULT void f_faultCheck(void);
APPFAULT void speedRamp(void);
APPFAULT float  vcu_speedDirCmd;
APPFAULT float	vcu_speedCmd;
APPFAULT float	vcu_speedRampCmd;

#endif /* APP_FAULT_SHINHOO_H_ */
