
//���ݿ���ģʽ���趨���Ŀ���ٶ�

#ifndef SRC_APP_GEAR_C_
#define SRC_APP_GEAR_C_

#include <app_include.h>

/*************************************************************************************************/
//���������sys_param.mode��u_speed_exsci��u_enable_exsci
//������Դ�����ư�SCIͨѶ����

//�����f_speed_gear�� u_motor_ctrl.bit.enable�ź�
/*************************************************************************************************/
//powerH_table����Ӧ����С��̺�������
const int minH_maxH_table[2][2] =
{
     {1, 3,},
     {5, 25,},
};

//����ٺ�����٣���̣����1m����Ӧ����
const int powerH_table[2][30] =
{
     {50, 51, 52, 53, 54, 55, 56, 57, 58, 60,
      61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
      71, 72, 73, 74, 75, 76, 77, 78, 79, 80,},
     {200, 205, 210, 215, 220, 225, 230, 235, 240, 245,
      255, 265, 275, 285, 295, 305, 315, 325, 335, 345,
      355, 365, 375, 385, 395, 405, 415, 425, 435, 440,},
};


void gear_init(void)
{
    sys_param.gear[AUTO].max_speed = 4800;
    sys_param.gear[AUTO].min_speed = 2960;
    sys_param.gear[AUTO].max_Iq = 2;
    sys_param.gear[AUTO].limit_power = MAX_POWER;
    sys_param.gear[AUTO].curve_k = 0.25319026;
    sys_param.gear[AUTO].curve_b = 2589.07221578;

    sys_param.gear[BL_I].max_speed = 4700;
    sys_param.gear[BL_I].min_speed = 2700;
    sys_param.gear[BL_I].limit_power = MAX_POWER;
    sys_param.gear[BL_I].max_Iq = 2;
    sys_param.gear[BL_I].curve_k = 0.26281530;
    sys_param.gear[BL_I].curve_b = 2365.78275020;

    sys_param.gear[HD_I].max_speed = 4700;
    sys_param.gear[HD_I].min_speed = 3850;
    sys_param.gear[HD_I].limit_power = MAX_POWER;
    sys_param.gear[HD_I].max_Iq = 2;
    sys_param.gear[HD_I].curve_k = 0.00001841;
    sys_param.gear[HD_I].curve_b = -0.08712828;
    sys_param.gear[HD_I].curve_c = 3973.85355544;

    sys_param.gear[HS_I].max_speed = 4375;
    sys_param.gear[HS_I].limit_power = 1000;
    sys_param.gear[HS_I].max_Iq = 1;

    sPID_liquidLmt.power_max = 1600;       //�����趨���ֵ��950w
    sPID_liquidLmt.outlimit_upper = 5000;  //������ֵ��5000rpm
    sPID_liquidLmt.outlimit_lower = 500;

}

void liquidLmtInit()
{
    sPID_liquidLmt.kp = 0.1;           //kp
    sPID_liquidLmt.ki = 0.005;         //ki
    sPID_liquidLmt.integral_sum = 0;   //������
    sPID_liquidLmt.out_value = 0;
    sPID_liquidLmt.integral_max = SPEED_MAX;

    liquidLmt.KP = 0.1;
    liquidLmt.KI = 0.001;
    liquidLmt.KD = 0;
    liquidLmt.Deta = 0;
    liquidLmt.Max = SPEED_MAX;
    liquidLmt.Min = 500;
    liquidLmt.Out = 0;
    liquidLmt.Total = SPEED_MAX;
    liquidLmt.OutFlag = SPEED_MAX;

    powerLmt.KP = 1.0;//4.0;
    powerLmt.KI = 0.1;
    powerLmt.KD = 0;
    powerLmt.Deta = 0;
    powerLmt.Max = SPEED_MAX;
    powerLmt.Min = SPEED_MIN;
    powerLmt.Out = SPEED_MIN;
    powerLmt.Total = SPEED_MIN;
    powerLmt.OutFlag = 0;
    powerLmt.targetMax = MAX_POWER;
}

float f_test_qCMD=0;
extern const int QH_table[14][100];
float pumpHrefMax,pumpHrefMin,pumpQrefMax;
float curve_b,curve_k,curve_c;
float curve_b_hd,curve_k_hd,curve_c_hd;

float pumpHrefSpeedMid2_Pwr,pumpHrefSpeedMid1_Pwr,pumpHrefSpeedMidEnd_Pwr,pumpHrefSpeedMinPwr,pumpHrefSpeedMaxPwr;
float pumpHrefSpeedMid,pumpHrefSpeedMax,pumpHrefSpeedMin;
float deltaP1P0,deltaS1S0,deltaP2P0,deltaS2S0,addP2P0,addP1P0;
Uint16 speednum;

void process_gear(void)
{
    float rpmPwrLmt;
    Uint16 motor_enableFlg;

    float ftemp,ftemp2,ftemp3;
    float h_pumpCal,rpmstep;
    static float rpm=0;

    Uint16 i,j;

    float QIq;
    QIq = iq_ref_f;

#if 1
//H0 = P0 * K + B
//H1 = P1 * K + B
/**����ģʽ��k,bֵ����*****************************************************************************/
    pumpHrefMax = f_test_qCMD;//u_speed_exsci;      //������̵�
    pumpHrefMin = pumpHrefMax*0.5;

    j=1;
    for(i=0; i<50; i++){
        if(QH_table[13][j] < pumpHrefMax){      //�������������̵�
            i = 50;
        }else{
            j=j+2;
        }
    }
    if(j>99){
        j = 99;
    }else if(j<3){
        j = 3;
    }
    ftemp = pumpHrefMax - QH_table[13][j-2];
    ftemp2 = QH_table[13][j] - QH_table[13][j-2];
    ftemp3 = QH_table[13][j-1] - QH_table[13][j-3];
    ftemp = ftemp/ftemp2*ftemp3 + QH_table[13][j-3];
    pumpQrefMax = ftemp;

    curve_b = pumpHrefMin;      //һ�������µ�Bֵ
    curve_k = (pumpHrefMax - pumpHrefMin)/pumpQrefMax;      //һ�������µ�Kֵ
    //����curve_b��curve_kֵ�����ݵ�ǰQ,Hֵ��׷���ٶȣ�ֱ��Q/H��������������
/********************************************************************************************/
#endif


#if 1
//S0 = P0*P0*K + P0*B + C
//S1 = P1*P1*K + P1*B + C
//S2 = P2*P2*K + P2*B + C
    //S2-S0 = (P2^2-P0^2)*K + (P2-P0)*B
    //S1-S0 = (P1^2-P0^2)*K + (P1-P0)*B
        //B = [S1-S0 - (P1^2 - P0^2)*K]/(P1-P0)
        //(P2-P0)*[(P2+P0)-(P1+P0)]*K = S2-S0-(P2-P0)*(S1-S0)/(P1-P0)
/**��ѹģʽ��k,b,cֵ����****************************************************************************/
    pumpHrefMax = f_test_qCMD;      //������̵�
    for(i=0; i<RPM_CELL; i++){
        if(QH_table[i][1] > pumpHrefMax){
           j = i-1;
           i = 100;
        }
    }
    if(j<1){
        j=1;
    }

    ftemp = QH_table[j][1] - QH_table[j-1][1];
    ftemp2 = pumpHrefMax - QH_table[j-1][1];
    ftemp2 = ftemp2/ftemp*QH_SPDSTEP + (j-1)*QH_SPDSTEP;
    pumpHrefSpeedMin = ftemp2;
    ftemp2 = pumpHrefMax - QH_table[j-1][1];
    ftemp2 = ftemp2/ftemp*QH_PWRSTEP + (j-1)*QH_PWRSTEP;
    pumpHrefSpeedMinPwr = ftemp2;

    pumpHrefSpeedMax = 6500;        //����ٶȵ�
    for(i=1; i<(PWR_CELL); i++){
        if(QH_table[RPM_CELL-1][i] < pumpHrefMax){
            break;
        }else{
            i = i+1;
        }
    }
    j = i-1;
    if(j<3){
        j=3;
    }
    ftemp = QH_table[RPM_CELL-1][j] - QH_table[RPM_CELL-1][j-1];
    ftemp2 = pumpHrefMax - QH_table[RPM_CELL-1][j-1];
    ftemp2 = ftemp2/ftemp*QH_PWRSTEP + (j-1)*QH_PWRSTEP;
    pumpHrefSpeedMaxPwr = ftemp2;


    pumpHrefSpeedMid = (pumpHrefSpeedMin + pumpHrefSpeedMax)*0.5;
    ftemp = pumpHrefSpeedMid*0.002;
    speednum = (int)ftemp;
    for(i=1; i<(PWR_CELL); i++){
        if(QH_table[speednum][i] < pumpHrefMax){
            break;
        }else{
            i = i+1;
        }
    }
    j = i - 1;
    if(j<3){
        j=3;
    }
    ftemp = QH_table[speednum][j] - QH_table[speednum][j-1];
    ftemp2 = pumpHrefMax - QH_table[speednum][j-1];
    ftemp2 = ftemp2/ftemp*QH_PWRSTEP + (j-1)*QH_PWRSTEP;
    pumpHrefSpeedMid1_Pwr = ftemp2;

    for(i=1; i<(PWR_CELL); i++){
        if(QH_table[speednum+1][i] < pumpHrefMax){
            break;
        }else{
            i++;
        }
    }
    j = i-1;
    if(j<3){
        j=3;
    }
    ftemp = QH_table[speednum+1][j] - QH_table[speednum+1][j-1];
    ftemp2 = pumpHrefMax - QH_table[speednum+1][j-1];
    ftemp2 = ftemp2/ftemp*QH_PWRSTEP + (j-1)*QH_PWRSTEP;
    pumpHrefSpeedMid2_Pwr = ftemp2;
    ftemp = pumpHrefSpeedMid - speednum * QH_SPDSTEP;
    ftemp = ftemp*0.002*(pumpHrefSpeedMid2_Pwr-pumpHrefSpeedMid1_Pwr);
    ftemp = ftemp+pumpHrefSpeedMid1_Pwr;
    pumpHrefSpeedMidEnd_Pwr = ftemp;

    /*pumpHrefSpeedMin =5170;
    pumpHrefSpeedMid =5270;
    pumpHrefSpeedMax = 5360;
    pumpHrefSpeedMinPwr = 6750;
    pumpHrefSpeedMidEnd_Pwr=17050;
    pumpHrefSpeedMaxPwr=18650;*/
    /*pumpHrefSpeedMin =2830;
    pumpHrefSpeedMid =2980;
    pumpHrefSpeedMax = 3415;
    pumpHrefSpeedMinPwr = 2350;
    pumpHrefSpeedMidEnd_Pwr=6120;
    pumpHrefSpeedMaxPwr=9000;*/

    deltaP1P0 = pumpHrefSpeedMidEnd_Pwr - pumpHrefSpeedMinPwr;
    deltaS1S0 = pumpHrefSpeedMid - pumpHrefSpeedMin;
    deltaP2P0 = pumpHrefSpeedMaxPwr - pumpHrefSpeedMinPwr;
    deltaS2S0 = pumpHrefSpeedMax - pumpHrefSpeedMin;

    addP2P0 = pumpHrefSpeedMaxPwr + pumpHrefSpeedMinPwr;
    addP1P0 = pumpHrefSpeedMidEnd_Pwr + pumpHrefSpeedMinPwr;
    ftemp = deltaS2S0 - ((deltaP2P0 * deltaS1S0) / deltaP1P0);
    ftemp2 = deltaP2P0 * (addP2P0 - addP1P0);
    curve_k_hd = ftemp/ftemp2;     //�������Kֵ

    ftemp = curve_k_hd;
    ftemp = -ftemp * deltaP1P0 * addP1P0 + deltaS1S0;
    ftemp = ftemp/deltaP1P0;
    curve_b_hd = ftemp;     //�������Bֵ

    ftemp = pumpHrefSpeedMax - (curve_k_hd*pumpHrefSpeedMaxPwr + curve_b_hd )*pumpHrefSpeedMaxPwr;
    curve_c_hd = ftemp;     //�������Cֵ

#endif


/**********************************************************************************************/

    if(u_enable_exsci==1){
        switch (sysSci_mode.mode)
        {
             case AUTO:
             case AUTOLIMIT:
             case BL_I:
                 h_pumpCal = curve_k * var_QH_cal.Q_pump + curve_b;
                 ftemp = fabs(h_pumpCal - var_QH_cal.H_pump);
                 if(ftemp>4.0){
                     rpmstep = 50;
                 }else if(ftemp>2.0){
                     rpmstep = 25;
                 }else if(ftemp>1.0){
                     rpmstep = 10;
                 }else if(ftemp>0.5){
                     rpmstep = 2;
                 }else{
                     rpmstep = 0;
                 }
                 if(h_pumpCal > var_QH_cal.H_pump){
                     rpm  = rpm + rpmstep;
                 }else if(h_pumpCal < var_QH_cal.H_pump){
                     rpm = rpm - rpmstep;
                 }
                 if(rpm<0){
                     rpm=0;
                 }
                 motor_enableFlg = u_enable_exsci;
             break;

             case HD_I:
                 h_pumpCal = u_speed_exsci;
                 ftemp = fabs(h_pumpCal - var_QH_cal.H_pump);;
                 if(ftemp>4.0){
                     rpmstep = 50;
                 }else if(ftemp>2.0){
                     rpmstep = 25;
                 }else if(ftemp>1.0){
                     rpmstep = 10;
                 }else if(ftemp>0.5){
                     rpmstep = 2;
                 }else{
                     rpmstep = 0;
                 }
                 if(h_pumpCal > var_QH_cal.H_pump){
                     rpm  = rpm + rpmstep;
                 }else if(h_pumpCal < var_QH_cal.H_pump){
                     rpm = rpm - rpmstep;
                 }
                 if(rpm<0){
                     rpm=0;
                 }
                 motor_enableFlg = u_enable_exsci;
             break;
             case HL_I:
                 h_pumpCal = u_speed_exsci;
                 ftemp = fabs(h_pumpCal - var_QH_cal.Q_pump);
                 if(ftemp>50.0){                                 //50l/min
                     rpmstep = 50;
                 }else if(ftemp>25.0){
                     rpmstep = 25;
                 }else if(ftemp>10.0){
                     rpmstep = 10;
                 }else if(ftemp>5){
                     rpmstep = 2;
                 }else{
                     rpmstep = 0;
                 }
                 if(h_pumpCal > var_QH_cal.Q_pump){
                     rpm  = rpm + rpmstep;
                 }else if(h_pumpCal < var_QH_cal.Q_pump){
                     rpm = rpm - rpmstep;
                 }
                 if(rpm<0){
                     rpm=0;
                 }
                 motor_enableFlg = u_enable_exsci;
             break;
             case HS_I:
                 rpm = u_speed_exsci;
                 rpm = rpm*SPEED_MAX;
                 rpm = rpm/1000;        //0.1
                 motor_enableFlg = u_enable_exsci;
             break;
             default:
                 rpm = u_speed_exsci*SPEED_MAX;
                 rpm = rpm/1000;        //0.1
                 motor_enableFlg = u_enable_exsci;
             break;
        }
        //������
        ftemp = sys_param.liquidLimtMax;
        if(sys_param.liquidLimtEn==1){
            if(sys_param.headValid==1){
                liquidLmt.Deta = ftemp * var_QH_cal.Qmax_pump - sys_param.headSensor;
            }else{
                liquidLmt.Deta = ftemp * var_QH_cal.Qmax_pump - var_QH_cal.Q_pump;
            }
            PID((PID_STRUCT *)&liquidLmt);
            rpmPwrLmt = liquidLmt.Out;
            if(rpmPwrLmt < rpm){
                rpm = rpmPwrLmt;
            }else{
                rpm = rpm;
            }
        }

        //�޹���,PI���ڻ�Ӱ���ٶ���Ӧʱ��
        powerLmt.Deta =  MAX_POWER - motorPwr_Lpf;   //���ʷֱ���0.1
        PID((PID_STRUCT *)&powerLmt);
        rpmPwrLmt = powerLmt.Out;
        if (rpmPwrLmt < rpm){
            rpm = rpmPwrLmt;
        }else{
        }

        if(rpm > SPEED_MAX){
            rpm = SPEED_MAX;
        }else if(rpm < SPEED_MIN){
            rpm= SPEED_MIN;
        }
        speed_ramp_cmd = rpm;
        u_motor_ctrl.bit.enable = motor_enableFlg;
    }else{
        motor_enableFlg = 0;
        rpm = 0;
        speed_ramp_cmd = 0;
        u_motor_ctrl.bit.enable = 0;
        liquidLmtInit();
    }

#if 0
//*****************************�»����߳�������****************************************************************/
    switch (sys_param.mode)
    {
        //�޼����������޵�λ
        case AUTO:
        case AUTOLIMIT:
        case BL_I:
            //rpm = sys_param.gear[sys_param.mode].curve_k * QIq + sys_param.gear[sys_param.mode].curve_b;
            rpm = curve_k_hd * QIq + curve_b_hd;
            motor_enableFlg = u_enable_exsci;
        break;
        //�޼���ѹ�����޵�λ
        case HD_I:
            //rpm = (sys_param.gear[sys_param.mode].curve_k * QIq * QIq) + (sys_param.gear[sys_param.mode].curve_b * QIq) + (sys_param.gear[sys_param.mode].curve_c);
            rpm = (curve_k_hd * QIq * QIq) + (curve_b_hd * QIq) + curve_c_hd;
            motor_enableFlg = u_enable_exsci;
        break;
        case HL_I:

        break;
        //�޼����٣��޵�λ
        case HS_I:
            rpm = u_speed_exsci;
            motor_enableFlg = u_enable_exsci;
        break;

        case PWM_GEAR:
            rpm = u_speed_exsci;   //f_speed_pwm;
            motor_enableFlg = u_enable_exsci;
        break;
        case VOL_GEAR:
            rpm = u_speed_exsci;   //f_speed_vi[0];
            motor_enableFlg = u_enable_exsci;
        break;
        case CUR_GEAR:
            rpm = u_speed_exsci;   //f_speed_vi[1];
            motor_enableFlg = u_enable_exsci;
        break;
        case HS_MIN:
            rpm = u_speed_exsci;   //f_speed_min;
            motor_enableFlg = u_enable_exsci;
        break;
        case HS_MAX:
            rpm = u_speed_exsci;   //f_speed_max;
            motor_enableFlg = u_enable_exsci;
        break;
        case MODBUS_GEAR:
            rpm = u_speed_exsci;
            motor_enableFlg = u_enable_exsci;
        break;
        case CAN_GEAR:
            rpm = u_speed_can;
            motor_enableFlg = u_motor_ctrl.bit.enableCAN;
        break;
        case CANFD_GEAR:
            rpm = u_speed_canfd;
            motor_enableFlg = motorVars_M1.cmdCAN.flagCmdRun;
        break;
        case LIN_GEAR:
            rpm = u_speed_lin;
            motor_enableFlg = u_motor_ctrl.bit.enableLIN;
        break;
        default:
            rpm = sys_param.gear[HS_I].max_speed;
            sys_param.mode = HS_I;
            motor_enableFlg = 1;
        break;
    }
    //�ٶ��޷�
    if (rpm < sys_param.gear[sys_param.mode].min_speed){
        rpm = sys_param.gear[sys_param.mode].min_speed;
    }
    else if(rpm > sys_param.gear[sys_param.mode].max_speed){
        rpm = sys_param.gear[sys_param.mode].max_speed;
    }else{
        rpm = rpm;
    }
    //�����޷�
    sPID_pwrLmt.outlimit_upper = sys_param.gear[sys_param.mode].max_speed;
    sPID_pwrLmt.outlimit_lower = sys_param.gear[sys_param.mode].min_speed;
    rpmPwrLmt = pmsm_pi_controller(sys_param.gear[sys_param.mode].limit_power,outpower,&sPID_pwrLmt);
    if (rpmPwrLmt < rpm){
        speed_ramp_cmd = rpmPwrLmt;
    }
    else{
        speed_ramp_cmd = rpm;
    }
    u_motor_ctrl.bit.enable = motor_enableFlg;
/************************************************************************************************************/
#endif
}

float m_Max,m_Min,m_Out,m_OutKp,m_OutKi;
void PID(PID_STRUCT * pid)
{
    //float m_Max,m_Min,m_Out,m_OutKp,m_OutKi;

    m_Max = pid->Max;                       // ���ֵ
    m_Min = pid->Min;                       // ��Сֵ

    m_OutKp = pid->KP * pid->Deta;          // ����
    m_OutKi = pid->KI * pid->Deta;          // ����
    // ��������µ�ȥ���ʹ���
    if((m_OutKp > m_Max) && (pid->Total > 0))
    {
        pid->Total -= (pid->Total * 0.125) + 1;  //��1ȥ���˲�����
        m_OutKi = 0;
    }
    else if((m_OutKp < m_Min) && (pid->Total < 0))
    {
        pid->Total -= (pid->Total * 0.125) - 1;
        m_OutKi = 0;
    }
    pid->Total += m_OutKi;
    pid->Total  = max(pid->Total,m_Min);
    pid->Total  = min(pid->Total,m_Max);
    m_Out       = pid->Total + m_OutKp;
    pid->Out    = max(m_Out,m_Min);
    pid->Out    = min(m_Out,m_Max);

}

#endif


