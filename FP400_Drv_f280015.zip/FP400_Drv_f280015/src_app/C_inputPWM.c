
//����PWM�źŲɼ�

#ifndef SRC_APP_INPUTPWM_C_
#define SRC_APP_INPUTPWM_C_

#include "app_include.h"

volatile struct ECAP_REGS *pECapRegs= &ECap1Regs;;
LINE_STRUCT pulseInLine = LINE_STRTUCT_DEFALUTS;

#pragma CODE_SECTION(INT_myECAP0_ISR, ".TI.ramfunc");

/*************************************************************************************************/
//���������
//������Դ��

//���������pwmDuTy--PWMռ�ձ�
/*************************************************************************************************/


void eCap_Init(void)
{
    pwmDuTy=0;
    pwmDataH = 0;
    period = 0;
    period_old = 0;
    captureTicker = 0;
    pwmInEnable = 0;
    pwmInSpdRef = 0;
}

__interrupt void INT_myECAP0_ISR(void)
{
    captureTicker=0;
    period = pECapRegs->CAP3-pECapRegs->CAP1;
    pwmDataH = pECapRegs->CAP2-pECapRegs->CAP1;
    ECAP_clearInterrupt(myECAP0_BASE,ECAP_ISR_SOURCE_CAPTURE_EVENT_3|ECAP_ISR_SOURCE_CAPTURE_EVENT_2|ECAP_ISR_SOURCE_CAPTURE_EVENT_1|ECAP_ISR_SOURCE_COUNTER_OVERFLOW|0x01);
    ECAP_resetCounters(myECAP0_BASE);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP4);
}

//=====================================================================
//���룺pECapRegs->CAP1��pECapRegs->CAP2��pECapRegs->CAP3��pECapRegs->CAP4
//    pwmInMode,
//�����pwmInEnable��pwmInSpdRef
//=====================================================================
void PulseInCalc(void)
{
    static float pwmDutyOld[5] = {0,0,0,0,0};
    float ftemp;
    static int capzeroClr = 0;

    pwmDutyOld[4] = pwmDutyOld[3];
    pwmDutyOld[3] = pwmDutyOld[2];
    pwmDutyOld[2] = pwmDutyOld[1];
    pwmDutyOld[1] = pwmDutyOld[0];
    captureTicker++;
    if(captureTicker==50){    //���ߡ����͵�ƽ
        ECAP_clearInterrupt(myECAP0_BASE,ECAP_ISR_SOURCE_CAPTURE_EVENT_3|ECAP_ISR_SOURCE_CAPTURE_EVENT_2|ECAP_ISR_SOURCE_CAPTURE_EVENT_1|ECAP_ISR_SOURCE_COUNTER_OVERFLOW|0x01);
        ECAP_resetCounters(myECAP0_BASE);
    }else if(captureTicker>50){
        captureTicker = 51;
        if(GPIO_readPin(myINPUTXBARINPUT2_SOURCE)==0){   //����
            pwmDutyOld[0] = 100;
        }else{
            pwmDutyOld[0] = 0;
        }
    }
    else{
        if(period > PERIOD_MAX){            //Ƶ�ʳ�����
            #if (PWM_PRD_VALID==1)
                pwmDutyOld[0]=100.0;
            #elif (PWM_PRD_VALID==2)
                pwmDutyOld[0]=0.0;
            #endif
        }else if(period < PERIOD_MIN){      //Ƶ�ʳ�����
            #if (PWM_PRD_VALID==1)
                pwmDutyOld[0]=100.0;
            #elif (PWM_PRD_VALID==2)
                pwmDutyOld[0]=0.0;
            #endif
        }else if(period < 0){               //����ֵ�쳣
        }else if(pwmDataH < 0){             //���ź�ʱ��ֵ�쳣
        }else if(period < pwmDataH){        //����ֵ�������ź�ʱ��ֵ
        }else{
            pwmDutyOld[0] = 100.0*pwmDataH/period;
            pwmDutyOld[0] = 100 - pwmDutyOld[0];
        }
    }

    ftemp = fabs(pwmDutyOld[4] - pwmDutyOld[0]);
    if(ftemp < 0.1){
        pwmDuTy = pwmDutyOld[0];
    }

    if(pwmInMode==PWMIN_A){
        pulseInLine.mode = 0;
        pulseInLine.x1 = 10.0;
        pulseInLine.y1 = SPD_MAX_PWMIN;
        pulseInLine.x2 = 84.0;
        pulseInLine.y2 = SPD_MIN;
        pulseInLine.x = pwmDuTy;
        if(pwmDuTy > 95.0){
            pwmInEnable = 0;
        }else if(pwmDuTy < 91.0){
            pwmInEnable = 1;
        }
    }else if(pwmInMode==PWMIN_B){
        pulseInLine.mode = 0;
        pulseInLine.x1 = 10.0;
        pulseInLine.y1 = SPD_MAX_PWMIN;
        pulseInLine.x2 = 95.0;
        pulseInLine.y2 = SPD_MIN_PWMIN;
        pulseInLine.x = pwmDuTy;
        pwmInEnable = 1;
    }else if(pwmInMode==PWMIN_C){
        pulseInLine.mode = 0;
        pulseInLine.x1 = 15.0;
        pulseInLine.y1 = SPD_MIN_PWMIN;
        pulseInLine.x2 = 90.0;
        pulseInLine.y2 = SPD_MAX_PWMIN;
        pulseInLine.x = pwmDuTy;
        if(pwmDuTy > 95.0){
            pwmInEnable = 0;
        }else if(pwmDuTy < 91.0){
            pwmInEnable = 1;
        }
    }else if(pwmInMode==PWMIN_D){
        pulseInLine.mode = 0;
        pulseInLine.x1 = 5.00;
        pulseInLine.y1 = SPD_MIN_PWMIN;
        pulseInLine.x2 = 100.0;
        pulseInLine.y2 = SPD_MAX_PWMIN;
        pulseInLine.x = pwmDuTy;
        pwmInEnable = 1;
    }else if(pwmInMode==PWMIN_E){
        pulseInLine.mode = 0;
        pulseInLine.x1 = 55.0;
        pulseInLine.y1 = SPD_MIN_PWMIN;
        pulseInLine.x2 = 90.0;
        pulseInLine.y2 = SPD_MAX_PWMIN;
        pulseInLine.x = pwmDuTy;
        if(pwmDuTy < 10.0){
            pwmInEnable = 0;
        }else{
            pwmInEnable = 1;
        }
    }else{
        pulseInLine.mode = 0;
        pulseInLine.x1 = 5.00;
        pulseInLine.y1 = SPD_MIN_PWMIN;
        pulseInLine.x2 = 100.0;
        pulseInLine.y2 = SPD_MAX_PWMIN;
        pulseInLine.x = pwmDuTy;
        pwmInEnable = 1;
    }
    pulseInLine.calc(&pulseInLine);
    pwmInSpdRef = (Uint16)pulseInLine.y;
}



#endif /* SRC_APP_INPUTPWM_C_ */
