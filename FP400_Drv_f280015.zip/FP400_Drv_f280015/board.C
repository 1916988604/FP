/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"
#include "App_CanDebug.h"

#define     ADC_VOL_REF 0   //0:�ⲿ��׼��   1:�ڲ���׼

//*****************************************************************************
//
// Board Configurations
// Initializes the rest of the modules. 
// Call this function in your application if you wish to do all module 
// initialization.
// If you wish to not use some of the initializations, instead of the 
// Board_init use the individual Module_inits
//
//*****************************************************************************
void Board_init()
{
	EALLOW;

	PinMux_init();
	SYSCTL_init();
	INPUTXBAR_init();
	SYNC_init();
	ASYSCTL_init();
	ADC_init();
	CAN_init();
	CMPSS_init();
	CMPSSLITE_init();
	CPUTIMER_init();
	ECAP_init();
    GPIO_init();
	EPWM_init();
	EPWMXBAR_init();
	//GPIO_init();
	SCI_init();
	INTERRUPT_init();

	EDIS;
}

//*****************************************************************************
//
// PINMUX Configurations
//
//*****************************************************************************
void PinMux_init()
{
	//
	// PinMux for modules assigned to CPU1
	//
	
	//
	// ANALOG -> MOTOR_FEEDBACK Pinmux
	//
	// Analog PinMux for A0/C15/CMP1_DACL
	GPIO_setPinConfig(GPIO_231_GPIO231);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(231, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A11/C0
	GPIO_setPinConfig(GPIO_237_GPIO237);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(237, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A12/C1
	GPIO_setPinConfig(GPIO_238_GPIO238);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(238, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A2/C9, GPIO224
	GPIO_setPinConfig(GPIO_224_GPIO224);
	// AGPIO -> Analog mode selected
	GPIO_setAnalogMode(224, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A3/C5, GPIO242
	GPIO_setPinConfig(GPIO_242_GPIO242);
	// AGPIO -> Analog mode selected
	GPIO_setAnalogMode(242, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A5/C2
	GPIO_setPinConfig(GPIO_244_GPIO244);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(244, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A7/C3
	GPIO_setPinConfig(GPIO_245_GPIO245);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(245, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A8/C11
	GPIO_setPinConfig(GPIO_241_GPIO241);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(241, GPIO_ANALOG_ENABLED);
	// Analog PinMux for A15/C7, C4/A14
	GPIO_setPinConfig(GPIO_233_GPIO233);
	// AIO -> Analog mode selected
	GPIO_setAnalogMode(233, GPIO_ANALOG_ENABLED);
	//
	// CANA -> myCAN0 Pinmux
	//
	GPIO_setPinConfig(myCAN0_CANRX_PIN_CONFIG);
	// AGPIO -> GPIO mode selected
	GPIO_setAnalogMode(12, GPIO_ANALOG_DISABLED);
	GPIO_setPadConfig(myCAN0_CANRX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
	GPIO_setQualificationMode(myCAN0_CANRX_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(myCAN0_CANTX_PIN_CONFIG);
	// AGPIO -> GPIO mode selected
	GPIO_setAnalogMode(13, GPIO_ANALOG_DISABLED);
	GPIO_setPadConfig(myCAN0_CANTX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
	GPIO_setQualificationMode(myCAN0_CANTX_GPIO, GPIO_QUAL_ASYNC);

	//
	// EPWM1 -> MTR1_PWM_U Pinmux
	//
	GPIO_setPinConfig(MTR1_PWM_U_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(MTR1_PWM_U_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(MTR1_PWM_U_EPWMA_GPIO, GPIO_QUAL_SYNC);

	GPIO_setPinConfig(MTR1_PWM_U_EPWMB_PIN_CONFIG);
	GPIO_setPadConfig(MTR1_PWM_U_EPWMB_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(MTR1_PWM_U_EPWMB_GPIO, GPIO_QUAL_SYNC);

	//
	// EPWM2 -> MTR1_PWM_V Pinmux
	//
	GPIO_setPinConfig(MTR1_PWM_V_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(MTR1_PWM_V_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(MTR1_PWM_V_EPWMA_GPIO, GPIO_QUAL_SYNC);

	GPIO_setPinConfig(MTR1_PWM_V_EPWMB_PIN_CONFIG);
	GPIO_setPadConfig(MTR1_PWM_V_EPWMB_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(MTR1_PWM_V_EPWMB_GPIO, GPIO_QUAL_SYNC);

	//
	// EPWM3 -> MTR1_PWM_W Pinmux
	//
	GPIO_setPinConfig(MTR1_PWM_W_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(MTR1_PWM_W_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(MTR1_PWM_W_EPWMA_GPIO, GPIO_QUAL_SYNC);

	GPIO_setPinConfig(MTR1_PWM_W_EPWMB_PIN_CONFIG);
	GPIO_setPadConfig(MTR1_PWM_W_EPWMB_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(MTR1_PWM_W_EPWMB_GPIO, GPIO_QUAL_SYNC);

	//
	// EPWM6 -> myEPWM0 Pinmux
	//
	GPIO_setPinConfig(myEPWM0_EPWMA_PIN_CONFIG);
	// AGPIO -> GPIO mode selected
	GPIO_setAnalogMode(226, GPIO_ANALOG_DISABLED);
	GPIO_setPadConfig(myEPWM0_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(myEPWM0_EPWMA_GPIO, GPIO_QUAL_SYNC);

	// GPIO227 -> Relay1_IO Pinmux
	GPIO_setPinConfig(GPIO_227_GPIO227);
	// AGPIO -> GPIO mode selected
	GPIO_setAnalogMode(227, GPIO_ANALOG_DISABLED);
	// GPIO24 -> GPIO_SYS_DIS_FET_SUPPLY Pinmux
	GPIO_setPinConfig(GPIO_24_GPIO24);
	// GPIO32 -> LED2_GPIO Pinmux
	GPIO_setPinConfig(GPIO_32_GPIO32);
	// GPIO230 -> PFC_Ctrl_IO Pinmux
	GPIO_setPinConfig(GPIO_230_GPIO230);
	// AGPIO -> GPIO mode selected
	GPIO_setAnalogMode(230, GPIO_ANALOG_DISABLED);
	// GPIO20 -> myGPIO20 Pinmux
	GPIO_setPinConfig(GPIO_20_GPIO20);
	// AGPIO -> GPIO mode selected
	GPIO_setAnalogMode(20, GPIO_ANALOG_DISABLED);
	// GPIO33 -> myGPIO33 Pinmux
	GPIO_setPinConfig(GPIO_33_GPIO33);
	//
	// SCIA -> SCIA_IO Pinmux
	//
	GPIO_setPinConfig(SCIA_IO_SCIRX_PIN_CONFIG);
	// AGPIO -> GPIO mode selected
	GPIO_setAnalogMode(28, GPIO_ANALOG_DISABLED);
	GPIO_setPadConfig(SCIA_IO_SCIRX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
	GPIO_setQualificationMode(SCIA_IO_SCIRX_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SCIA_IO_SCITX_PIN_CONFIG);
	GPIO_setPadConfig(SCIA_IO_SCITX_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
	GPIO_setQualificationMode(SCIA_IO_SCITX_GPIO, GPIO_QUAL_ASYNC);


}

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
void ADC_init(){
	MTR1_ADCA_init();
	MTR1_ADCC_init();
}

void MTR1_ADCA_init(){
	//
	// ADC Initialization: Write ADC configurations and power up the ADC
	//
	// Configures the ADC module's offset trim
	//
#if ADC_VOL_REF==0
	ADC_setOffsetTrimAll(ADC_REFERENCE_EXTERNAL,ADC_REFERENCE_3_3V);
#else
    ADC_setOffsetTrimAll(ADC_REFERENCE_INTERNAL,ADC_REFERENCE_3_3V);
#endif
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(MTR1_ADCA_BASE, ADC_CLK_DIV_2_0);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(MTR1_ADCA_BASE, ADC_PULSE_END_OF_ACQ_WIN);
	//
	// Sets the timing of early interrupt generation.
	//
	ADC_setInterruptCycleOffset(MTR1_ADCA_BASE, 0U);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(MTR1_ADCA_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(5000);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(MTR1_ADCA_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(MTR1_ADCA_BASE, ADC_PRI_THRU_SOC1_HIPRI);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN11
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCA_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN11, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCA_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCA_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN5, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCA_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCA_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN3, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCA_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 3 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN12
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCA_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN12, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCA_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 4 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 4
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN0
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCA_BASE, ADC_SOC_NUMBER4, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN0, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCA_BASE, ADC_SOC_NUMBER4, ADC_INT_SOC_TRIGGER_NONE);
	//
	// ADC Interrupt 1 Configuration
	// 		Source	: ADC_SOC_NUMBER4
	// 		Interrupt Source: enabled
	// 		Continuous Mode	: disabled
	//
	//
	ADC_setInterruptSource(MTR1_ADCA_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER4);
	ADC_clearInterruptStatus(MTR1_ADCA_BASE, ADC_INT_NUMBER1);
	ADC_disableContinuousMode(MTR1_ADCA_BASE, ADC_INT_NUMBER1);
	ADC_enableInterrupt(MTR1_ADCA_BASE, ADC_INT_NUMBER1);
			
	//
	// PPB Configuration: Configure high and low limits detection for ADCPPB
	//
	// Post Processing Block 1 Configuration
	// 		Configures a post-processing block (PPB) in the ADC.
	// 		PPB Number				: 1
	// 		SOC/EOC number			: 0
	// 		Calibration Offset		: 0
	// 		Reference Offset		: 0
	// 		Two's Complement		: Disabled
	// 		Trip High Limit			: 0
	// 		Trip Low Limit			: 0
	// 		Clear PPB Event Flags	: Disabled
	//
	ADC_setupPPB(MTR1_ADCA_BASE, ADC_PPB_NUMBER1, ADC_SOC_NUMBER0);
	ADC_disablePPBEvent(MTR1_ADCA_BASE, ADC_PPB_NUMBER1, (ADC_EVT_TRIPHI | ADC_EVT_TRIPLO | ADC_EVT_ZERO));
	ADC_disablePPBEventInterrupt(MTR1_ADCA_BASE, ADC_PPB_NUMBER1, (ADC_EVT_TRIPHI | ADC_EVT_TRIPLO | ADC_EVT_ZERO));
	ADC_setPPBCalibrationOffset(MTR1_ADCA_BASE, ADC_PPB_NUMBER1, 0);
	ADC_setPPBReferenceOffset(MTR1_ADCA_BASE, ADC_PPB_NUMBER1, 0);
	ADC_disablePPBTwosComplement(MTR1_ADCA_BASE, ADC_PPB_NUMBER1);
	ADC_setPPBTripLimits(MTR1_ADCA_BASE, ADC_PPB_NUMBER1, 0, 0);
	ADC_disablePPBEventCBCClear(MTR1_ADCA_BASE, ADC_PPB_NUMBER1);
	//
	// Post Processing Block 2 Configuration
	// 		Configures a post-processing block (PPB) in the ADC.
	// 		PPB Number				: 2
	// 		SOC/EOC number			: 1
	// 		Calibration Offset		: 0
	// 		Reference Offset		: 0
	// 		Two's Complement		: Disabled
	// 		Trip High Limit			: 0
	// 		Trip Low Limit			: 0
	// 		Clear PPB Event Flags	: Disabled
	//
	ADC_setupPPB(MTR1_ADCA_BASE, ADC_PPB_NUMBER2, ADC_SOC_NUMBER1);
	ADC_disablePPBEvent(MTR1_ADCA_BASE, ADC_PPB_NUMBER2, (ADC_EVT_TRIPHI | ADC_EVT_TRIPLO | ADC_EVT_ZERO));
	ADC_disablePPBEventInterrupt(MTR1_ADCA_BASE, ADC_PPB_NUMBER2, (ADC_EVT_TRIPHI | ADC_EVT_TRIPLO | ADC_EVT_ZERO));
	ADC_setPPBCalibrationOffset(MTR1_ADCA_BASE, ADC_PPB_NUMBER2, 0);
	ADC_setPPBReferenceOffset(MTR1_ADCA_BASE, ADC_PPB_NUMBER2, 0);
	ADC_disablePPBTwosComplement(MTR1_ADCA_BASE, ADC_PPB_NUMBER2);
	ADC_setPPBTripLimits(MTR1_ADCA_BASE, ADC_PPB_NUMBER2, 0, 0);
	ADC_disablePPBEventCBCClear(MTR1_ADCA_BASE, ADC_PPB_NUMBER2);
}
void MTR1_ADCC_init(){
	//
	// ADC Initialization: Write ADC configurations and power up the ADC
	//
	// Configures the ADC module's offset trim
	//
#if ADC_VOL_REF==0
    ADC_setOffsetTrimAll(ADC_REFERENCE_EXTERNAL,ADC_REFERENCE_3_3V);
#else
    ADC_setOffsetTrimAll(ADC_REFERENCE_INTERNAL,ADC_REFERENCE_3_3V);
#endif
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(MTR1_ADCC_BASE, ADC_CLK_DIV_2_0);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(MTR1_ADCC_BASE, ADC_PULSE_END_OF_ACQ_WIN);
	//
	// Sets the timing of early interrupt generation.
	//
	ADC_setInterruptCycleOffset(MTR1_ADCC_BASE, 0U);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(MTR1_ADCC_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(5000);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(MTR1_ADCC_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(MTR1_ADCC_BASE, ADC_PRI_THRU_SOC1_HIPRI);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCC_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN3, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCC_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN9
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCC_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN9, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCC_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN7
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCC_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN7, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCC_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 3 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN11
	//	 	Sample Window	: 15 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(MTR1_ADCC_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN11, 15U);
	ADC_setInterruptSOCTrigger(MTR1_ADCC_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
			
	//
	// PPB Configuration: Configure high and low limits detection for ADCPPB
	//
	// Post Processing Block 1 Configuration
	// 		Configures a post-processing block (PPB) in the ADC.
	// 		PPB Number				: 1
	// 		SOC/EOC number			: 0
	// 		Calibration Offset		: 0
	// 		Reference Offset		: 0
	// 		Two's Complement		: Disabled
	// 		Trip High Limit			: 0
	// 		Trip Low Limit			: 0
	// 		Clear PPB Event Flags	: Disabled
	//
	ADC_setupPPB(MTR1_ADCC_BASE, ADC_PPB_NUMBER1, ADC_SOC_NUMBER0);
	ADC_disablePPBEvent(MTR1_ADCC_BASE, ADC_PPB_NUMBER1, (ADC_EVT_TRIPHI | ADC_EVT_TRIPLO | ADC_EVT_ZERO));
	ADC_disablePPBEventInterrupt(MTR1_ADCC_BASE, ADC_PPB_NUMBER1, (ADC_EVT_TRIPHI | ADC_EVT_TRIPLO | ADC_EVT_ZERO));
	ADC_setPPBCalibrationOffset(MTR1_ADCC_BASE, ADC_PPB_NUMBER1, 0);
	ADC_setPPBReferenceOffset(MTR1_ADCC_BASE, ADC_PPB_NUMBER1, 0);
	ADC_disablePPBTwosComplement(MTR1_ADCC_BASE, ADC_PPB_NUMBER1);
	ADC_setPPBTripLimits(MTR1_ADCC_BASE, ADC_PPB_NUMBER1, 0, 0);
	ADC_disablePPBEventCBCClear(MTR1_ADCC_BASE, ADC_PPB_NUMBER1);
}

//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************
void ASYSCTL_init(){
	//
	// asysctl initialization
	//
	// Enables the temperature sensor output to the ADC.
	//
	ASysCtl_enableTemperatureSensor();
	DEVICE_DELAY_US(500);
	//
	// Set the analog voltage reference selection to external.
	//
#if ADC_VOL_REF==0
	ASysCtl_setAnalogReferenceExternal( ASYSCTL_VREFHI );
#else
    ASysCtl_setAnalogReferenceInternal( ASYSCTL_VREFHI );
    ASysCtl_setAnalogReference1P65( ASYSCTL_VREFHI );
#endif
}

//*****************************************************************************
//
// CAN Configurations
//
//*****************************************************************************
void CAN_init(){
	myCAN0_init();
}

void myCAN0_init(){
	CAN_initModule(myCAN0_BASE);
	//
	// Refer to the Driver Library User Guide for information on how to set
	// tighter timing control. Additionally, consult the device data sheet
	// for more information about the CAN module clocking.
#if XTAL_PLL_FREQ==0  || XTAL_PLL_FREQ==2
    #if BAUDRATE_SEL==0
        CAN_setBitTiming(myCAN0_BASE, 9, 0, 14, 7, 3); //500k,������79.1%
    #else
        CAN_setBitTiming(myCAN0_BASE, 19, 0, 14, 7, 3); //250k,������79.1%
    #endif
#else
    #if BAUDRATE_SEL==0
        CAN_setBitTiming(myCAN0_BASE, 7, 0, 15, 7, 3); //500k,������79.1%
    #else
        CAN_setBitTiming(myCAN0_BASE, 15, 0, 15, 7, 3); //250k,������79.1%
    #endif
#endif
	//
	// Initialize the transmit message object used for sending CAN messages.
	// Message Object Parameters:
	//      Message Object ID Number: 30
	//      Message Identifier: 2024
	//      Message Frame: CAN_MSG_FRAME_EXT
	//      Message Type: CAN_MSG_OBJ_TYPE_RX
	//      Message ID Mask: 0
	//      Message Object Flags: 
	//      Message Data Length: 0 Bytes
	//
	CAN_setupMessageObject(myCAN0_BASE, 30, myCAN0_MessageObj30_ID, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_RX, 0, 0,0);
	//
	// Initialize the transmit message object used for sending CAN messages.
	// Message Object Parameters:
	//      Message Object ID Number: 31
	//      Message Identifier: 2016
	//      Message Frame: CAN_MSG_FRAME_EXT
	//      Message Type: CAN_MSG_OBJ_TYPE_TX
	//      Message ID Mask: 0
	//      Message Object Flags: 
	//      Message Data Length: 8 Bytes
	//
	CAN_setupMessageObject(myCAN0_BASE, 31, myCAN0_MessageObj31_ID, CAN_MSG_FRAME_EXT,CAN_MSG_OBJ_TYPE_TX, 0, 0,8);
	J1939_Module_Mailbox_Config();
	//
	// Start CAN module operations
	//
	CAN_startModule(myCAN0_BASE);
}

//*****************************************************************************
//
// CMPSS Configurations
//
//*****************************************************************************
void CMPSS_init(){
	MTR1_CMPSS_IU_IV_init();
}

void MTR1_CMPSS_IU_IV_init(){
    //
    // Select the value for CMP1HPMXSEL.
    //
    ASysCtl_selectCMPHPMux(ASYSCTL_CMPHPMUX_SELECT_1,1U);
    //
    // Select the value for CMP1LPMXSEL.
    //
    ASysCtl_selectCMPLPMux(ASYSCTL_CMPLPMUX_SELECT_1,1U);
    //
    // Sets the configuration for the high comparator.
    //
    CMPSS_configHighComparator(MTR1_CMPSS_IU_IV_BASE,(CMPSS_INSRC_DAC));
    //
    // Sets the configuration for the low comparator.
    //
    CMPSS_configLowComparator(MTR1_CMPSS_IU_IV_BASE,(CMPSS_INSRC_DAC | CMPSS_INV_INVERTED));
    //
    // Sets the configuration for the internal comparator DACs.
    //
    CMPSS_configDACHigh(MTR1_CMPSS_IU_IV_BASE,(CMPSS_DACVAL_SYSCLK | CMPSS_DACSRC_SHDW));
    CMPSS_configDACLow(MTR1_CMPSS_IU_IV_BASE, CMPSS_DACSRC_SHDW);
    //
    // Sets the value of the internal DAC of the high comparator.
    //
    CMPSS_setDACValueHigh(MTR1_CMPSS_IU_IV_BASE,3990U);
    //
    // Sets the value of the internal DAC of the low comparator.
    //
    CMPSS_setDACValueLow(MTR1_CMPSS_IU_IV_BASE,512U);
    //
    //  Configures the digital filter of the high comparator.
    //
    CMPSS_configFilterHigh(MTR1_CMPSS_IU_IV_BASE, 32U, 32U, 30U);
    //
    // Configures the digital filter of the low comparator.
    //
    CMPSS_configFilterLow(MTR1_CMPSS_IU_IV_BASE, 32U, 32U, 30U);
    //
    // Initializes the digital filter of the high comparator.
    //
    CMPSS_initFilterHigh(MTR1_CMPSS_IU_IV_BASE);
    //
    // Initializes the digital filter of the low comparator.
    //
    CMPSS_initFilterLow(MTR1_CMPSS_IU_IV_BASE);
    //
    // Sets the output signal configuration for the high comparator.
    //
    CMPSS_configOutputsHigh(MTR1_CMPSS_IU_IV_BASE,(CMPSS_TRIPOUT_FILTER | CMPSS_TRIP_FILTER));
    //
    // Sets the output signal configuration for the low comparator.
    //
    CMPSS_configOutputsLow(MTR1_CMPSS_IU_IV_BASE,(CMPSS_TRIPOUT_FILTER | CMPSS_TRIP_FILTER));
    //
    // Sets the comparator hysteresis settings.
    //
    CMPSS_setHysteresis(MTR1_CMPSS_IU_IV_BASE,1U);
    //
    // Configures the comparator subsystem's high ramp generator.
    //
    CMPSS_configRampHigh(MTR1_CMPSS_IU_IV_BASE, CMPSS_RAMP_DIR_DOWN, 0U,0U,0U,1U,true);
    //
    // Configures the comparator subsystem's low ramp generator.
    //
    CMPSS_configRampLow(MTR1_CMPSS_IU_IV_BASE, CMPSS_RAMP_DIR_DOWN, 0U,0U,0U,1U,true);
    //
    // Disables reset of HIGH comparator digital filter output latch on PWMSYNC
    //
    CMPSS_disableLatchResetOnPWMSYNCHigh(MTR1_CMPSS_IU_IV_BASE);
    //
    // Disables reset of LOW comparator digital filter output latch on PWMSYNC
    //
    CMPSS_disableLatchResetOnPWMSYNCLow(MTR1_CMPSS_IU_IV_BASE);
    //
    // Sets the ePWM module blanking signal that holds trip in reset.
    //
    CMPSS_configBlanking(MTR1_CMPSS_IU_IV_BASE,1U);
    //
    // Disables an ePWM blanking signal from holding trip in reset.
    //
    CMPSS_disableBlanking(MTR1_CMPSS_IU_IV_BASE);
    //
    // Configures whether or not the digital filter latches are reset by PWMSYNC
    //
    CMPSS_configLatchOnPWMSYNC(MTR1_CMPSS_IU_IV_BASE,false,false);
    //
    // Enables the CMPSS module.
    //
    CMPSS_enableModule(MTR1_CMPSS_IU_IV_BASE);
    //
    // Delay for CMPSS DAC to power up.
    //
    DEVICE_DELAY_US(500);
    //
    // Causes a software reset of the high comparator digital filter output latch.
    //
    CMPSS_clearFilterLatchHigh(MTR1_CMPSS_IU_IV_BASE);
    //
    // Causes a software reset of the low comparator digital filter output latch.
    //
    CMPSS_clearFilterLatchLow(MTR1_CMPSS_IU_IV_BASE);
}

//*****************************************************************************
//
// CMPSS-LITE Configurations
//
//*****************************************************************************
void CMPSSLITE_init(){
	MTR1_CMPSS_IW_init();
	MTR1_CMPSS_IV_init();
	MTR1_CMPSS_UDC_ULN_init();
}

void MTR1_CMPSS_IW_init(){
    //
    // Select the value for CMP4HPMXSEL.
    //
    ASysCtl_selectCMPHPMux(ASYSCTL_CMPHPMUX_SELECT_4,1U);
    //
    // Select the value for CMP4LPMXSEL.
    //
    ASysCtl_selectCMPLPMux(ASYSCTL_CMPLPMUX_SELECT_4,1U);
    //
    // Sets the configuration for the high comparator.
    //
    CMPSSLITE_configHighComparator(MTR1_CMPSS_IW_BASE,(CMPSS_INSRC_DAC));
    //
    // Sets the configuration for the low comparator.
    //
    CMPSSLITE_configLowComparator(MTR1_CMPSS_IW_BASE,(CMPSS_INSRC_DAC | CMPSS_INV_INVERTED));
    //
    // Sets the configuration for the internal comparator DACs.
    //
    CMPSSLITE_configDAC(MTR1_CMPSS_IW_BASE, CMPSS_DACVAL_SYSCLK);
    //
    // Sets the value of the internal DAC of the high comparator.
    //
    CMPSSLITE_setDACValueHigh(MTR1_CMPSS_IW_BASE,3990U);
    //
    // Sets the value of the internal DAC of the low comparator.
    //
    CMPSSLITE_setDACValueLow(MTR1_CMPSS_IW_BASE,512U);
    //
    //  Configures the digital filter of the high comparator.
    //
    CMPSSLITE_configFilterHigh(MTR1_CMPSS_IW_BASE, 32U, 32U, 30U);
    //
    // Configures the digital filter of the low comparator.
    //
    CMPSSLITE_configFilterLow(MTR1_CMPSS_IW_BASE, 32U, 32U, 30U);
    //
    // Initializes the digital filter of the high comparator.
    //
    CMPSSLITE_initFilterHigh(MTR1_CMPSS_IW_BASE);
    //
    // Initializes the digital filter of the low comparator.
    //
    CMPSSLITE_initFilterLow(MTR1_CMPSS_IW_BASE);
    //
    // Sets the output signal configuration for the high comparator.
    //
    CMPSSLITE_configOutputsHigh(MTR1_CMPSS_IW_BASE,(CMPSS_TRIPOUT_FILTER | CMPSS_TRIP_FILTER));
    //
    // Sets the comparator hysteresis settings.
    //
    CMPSSLITE_setHysteresis(MTR1_CMPSS_IW_BASE,0U);
    //
    // Disables reset of HIGH comparator digital filter output latch on PWMSYNC
    //
    CMPSSLITE_disableLatchResetOnPWMSYNCHigh(MTR1_CMPSS_IW_BASE);
    //
    // Disables reset of LOW comparator digital filter output latch on PWMSYNC
    //
    CMPSSLITE_disableLatchResetOnPWMSYNCLow(MTR1_CMPSS_IW_BASE);
    //
    // Sets the ePWM module blanking signal that holds trip in reset.
    //
    CMPSSLITE_configBlanking(MTR1_CMPSS_IW_BASE,1U);
    //
    // Disables an ePWM blanking signal from holding trip in reset.
    //
    CMPSSLITE_disableBlanking(MTR1_CMPSS_IW_BASE);
    //
    // Configures whether or not the digital filter latches are reset by PWMSYNC
    //
    CMPSSLITE_configLatchOnPWMSYNC(MTR1_CMPSS_IW_BASE,false,false);
    //
    // Enables the CMPSSLITE module.
    //
    CMPSSLITE_enableModule(MTR1_CMPSS_IW_BASE);
    //
    // Delay for CMPSSLITE DAC to power up.
    //
    DEVICE_DELAY_US(500);
    //
    // Causes a software reset of the high comparator digital filter output latch.
    //
    CMPSSLITE_clearFilterLatchHigh(MTR1_CMPSS_IW_BASE);
    //
    // Causes a software reset of the low comparator digital filter output latch.
    //
    CMPSSLITE_clearFilterLatchLow(MTR1_CMPSS_IW_BASE);
}
void MTR1_CMPSS_IV_init(){
    //
    // Select the value for CMP3HPMXSEL.
    //
    ASysCtl_selectCMPHPMux(ASYSCTL_CMPHPMUX_SELECT_3,1U);
    //
    // Select the value for CMP3LPMXSEL.
    //
    ASysCtl_selectCMPLPMux(ASYSCTL_CMPLPMUX_SELECT_3,1U);
    //
    // Sets the configuration for the high comparator.
    //
    CMPSSLITE_configHighComparator(MTR1_CMPSS_IV_BASE,(CMPSS_INSRC_DAC));
    //
    // Sets the configuration for the low comparator.
    //
    CMPSSLITE_configLowComparator(MTR1_CMPSS_IV_BASE,(CMPSS_INSRC_DAC | CMPSS_INV_INVERTED));
    //
    // Sets the configuration for the internal comparator DACs.
    //
    CMPSSLITE_configDAC(MTR1_CMPSS_IV_BASE, CMPSS_DACVAL_SYSCLK);
    //
    // Sets the value of the internal DAC of the high comparator.
    //
    CMPSSLITE_setDACValueHigh(MTR1_CMPSS_IV_BASE,3990U);
    //
    // Sets the value of the internal DAC of the low comparator.
    //
    CMPSSLITE_setDACValueLow(MTR1_CMPSS_IV_BASE,512U);
    //
    //  Configures the digital filter of the high comparator.
    //
    CMPSSLITE_configFilterHigh(MTR1_CMPSS_IV_BASE, 32U, 32U, 30U);
    //
    // Configures the digital filter of the low comparator.
    //
    CMPSSLITE_configFilterLow(MTR1_CMPSS_IV_BASE, 32U, 32U, 30U);
    //
    // Initializes the digital filter of the high comparator.
    //
    CMPSSLITE_initFilterHigh(MTR1_CMPSS_IV_BASE);
    //
    // Initializes the digital filter of the low comparator.
    //
    CMPSSLITE_initFilterLow(MTR1_CMPSS_IV_BASE);
    //
    // Sets the output signal configuration for the high comparator.
    //
    CMPSSLITE_configOutputsHigh(MTR1_CMPSS_IV_BASE,(CMPSS_TRIPOUT_FILTER | CMPSS_TRIP_FILTER));
    //
    // Sets the comparator hysteresis settings.
    //
    CMPSSLITE_setHysteresis(MTR1_CMPSS_IV_BASE,0U);
    //
    // Disables reset of HIGH comparator digital filter output latch on PWMSYNC
    //
    CMPSSLITE_disableLatchResetOnPWMSYNCHigh(MTR1_CMPSS_IV_BASE);
    //
    // Disables reset of LOW comparator digital filter output latch on PWMSYNC
    //
    CMPSSLITE_disableLatchResetOnPWMSYNCLow(MTR1_CMPSS_IV_BASE);
    //
    // Sets the ePWM module blanking signal that holds trip in reset.
    //
    CMPSSLITE_configBlanking(MTR1_CMPSS_IV_BASE,1U);
    //
    // Disables an ePWM blanking signal from holding trip in reset.
    //
    CMPSSLITE_disableBlanking(MTR1_CMPSS_IV_BASE);
    //
    // Configures whether or not the digital filter latches are reset by PWMSYNC
    //
    CMPSSLITE_configLatchOnPWMSYNC(MTR1_CMPSS_IV_BASE,false,false);
    //
    // Enables the CMPSSLITE module.
    //
    CMPSSLITE_enableModule(MTR1_CMPSS_IV_BASE);
    //
    // Delay for CMPSSLITE DAC to power up.
    //
    DEVICE_DELAY_US(500);
    //
    // Causes a software reset of the high comparator digital filter output latch.
    //
    CMPSSLITE_clearFilterLatchHigh(MTR1_CMPSS_IV_BASE);
    //
    // Causes a software reset of the low comparator digital filter output latch.
    //
    CMPSSLITE_clearFilterLatchLow(MTR1_CMPSS_IV_BASE);
}
void MTR1_CMPSS_UDC_ULN_init(){
    //
    // Select the value for CMP2HPMXSEL.
    //
    ASysCtl_selectCMPHPMux(ASYSCTL_CMPHPMUX_SELECT_2,1U);
    //
    // Select the value for CMP2LPMXSEL.
    //
    ASysCtl_selectCMPLPMux(ASYSCTL_CMPLPMUX_SELECT_2,4U);
    //
    // Sets the configuration for the high comparator.
    //
    CMPSSLITE_configHighComparator(MTR1_CMPSS_UDC_ULN_BASE,(CMPSS_INSRC_DAC));
    //
    // Sets the configuration for the low comparator.
    //
    CMPSSLITE_configLowComparator(MTR1_CMPSS_UDC_ULN_BASE,(CMPSS_INSRC_DAC));
    //
    // Sets the configuration for the internal comparator DACs.
    //
    CMPSSLITE_configDAC(MTR1_CMPSS_UDC_ULN_BASE, CMPSS_DACVAL_SYSCLK);
    //
    // Sets the value of the internal DAC of the high comparator.
    //
    CMPSSLITE_setDACValueHigh(MTR1_CMPSS_UDC_ULN_BASE,4070U);
    //
    // Sets the value of the internal DAC of the low comparator.
    //
    CMPSSLITE_setDACValueLow(MTR1_CMPSS_UDC_ULN_BASE,3600U);
    //
    //  Configures the digital filter of the high comparator.
    //
    CMPSSLITE_configFilterHigh(MTR1_CMPSS_UDC_ULN_BASE, 32U, 32U, 30U);
    //
    // Configures the digital filter of the low comparator.
    //
    CMPSSLITE_configFilterLow(MTR1_CMPSS_UDC_ULN_BASE, 32U, 32U, 30U);
    //
    // Initializes the digital filter of the high comparator.
    //
    CMPSSLITE_initFilterHigh(MTR1_CMPSS_UDC_ULN_BASE);
    //
    // Initializes the digital filter of the low comparator.
    //
    CMPSSLITE_initFilterLow(MTR1_CMPSS_UDC_ULN_BASE);
    //
    // Sets the output signal configuration for the high comparator.
    //
    CMPSSLITE_configOutputsHigh(MTR1_CMPSS_UDC_ULN_BASE,(CMPSS_TRIPOUT_FILTER | CMPSS_TRIP_FILTER));
    //
    // Sets the comparator hysteresis settings.
    //
    CMPSSLITE_setHysteresis(MTR1_CMPSS_UDC_ULN_BASE,0U);
    //
    // Disables reset of HIGH comparator digital filter output latch on PWMSYNC
    //
    CMPSSLITE_disableLatchResetOnPWMSYNCHigh(MTR1_CMPSS_UDC_ULN_BASE);
    //
    // Disables reset of LOW comparator digital filter output latch on PWMSYNC
    //
    CMPSSLITE_disableLatchResetOnPWMSYNCLow(MTR1_CMPSS_UDC_ULN_BASE);
    //
    // Sets the ePWM module blanking signal that holds trip in reset.
    //
    CMPSSLITE_configBlanking(MTR1_CMPSS_UDC_ULN_BASE,1U);
    //
    // Disables an ePWM blanking signal from holding trip in reset.
    //
    CMPSSLITE_disableBlanking(MTR1_CMPSS_UDC_ULN_BASE);
    //
    // Configures whether or not the digital filter latches are reset by PWMSYNC
    //
    CMPSSLITE_configLatchOnPWMSYNC(MTR1_CMPSS_UDC_ULN_BASE,false,false);
    //
    // Enables the CMPSSLITE module.
    //
    CMPSSLITE_enableModule(MTR1_CMPSS_UDC_ULN_BASE);
    //
    // Delay for CMPSSLITE DAC to power up.
    //
    DEVICE_DELAY_US(500);
    //
    // Causes a software reset of the high comparator digital filter output latch.
    //
    CMPSSLITE_clearFilterLatchHigh(MTR1_CMPSS_UDC_ULN_BASE);
    //
    // Causes a software reset of the low comparator digital filter output latch.
    //
    CMPSSLITE_clearFilterLatchLow(MTR1_CMPSS_UDC_ULN_BASE);
}

//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
void CPUTIMER_init(){
	TIMEBASE_TIMER_init();
}

void TIMEBASE_TIMER_init(){
	CPUTimer_setEmulationMode(TIMEBASE_TIMER_BASE, CPUTIMER_EMULATIONMODE_RUNFREE);
	CPUTimer_setPreScaler(TIMEBASE_TIMER_BASE, 0U);
#if XTAL_PLL_FREQ==0  || XTAL_PLL_FREQ==2
	CPUTimer_setPeriod(TIMEBASE_TIMER_BASE, 120000U);
#else
    CPUTimer_setPeriod(TIMEBASE_TIMER_BASE, 100000U);
#endif
	CPUTimer_disableInterrupt(TIMEBASE_TIMER_BASE);
	CPUTimer_stopTimer(TIMEBASE_TIMER_BASE);

	CPUTimer_reloadTimerCounter(TIMEBASE_TIMER_BASE);
	CPUTimer_startTimer(TIMEBASE_TIMER_BASE);
}

//*****************************************************************************
//
// ECAP Configurations
//
//*****************************************************************************
void ECAP_init(){
	myECAP0_init();
}

void myECAP0_init(){
	//
	// Disable ,clear all capture flags and interrupts
	//
	ECAP_disableInterrupt(myECAP0_BASE,
		(ECAP_ISR_SOURCE_CAPTURE_EVENT_1  |
		ECAP_ISR_SOURCE_CAPTURE_EVENT_2  |
		ECAP_ISR_SOURCE_CAPTURE_EVENT_3  |
		ECAP_ISR_SOURCE_CAPTURE_EVENT_4  |
		ECAP_ISR_SOURCE_COUNTER_OVERFLOW |
		ECAP_ISR_SOURCE_COUNTER_PERIOD   |
		ECAP_ISR_SOURCE_COUNTER_COMPARE));
	ECAP_clearInterrupt(myECAP0_BASE,
		(ECAP_ISR_SOURCE_CAPTURE_EVENT_1  |
		ECAP_ISR_SOURCE_CAPTURE_EVENT_2  |
		ECAP_ISR_SOURCE_CAPTURE_EVENT_3  |
		ECAP_ISR_SOURCE_CAPTURE_EVENT_4  |
		ECAP_ISR_SOURCE_COUNTER_OVERFLOW |
		ECAP_ISR_SOURCE_COUNTER_PERIOD   |
		ECAP_ISR_SOURCE_COUNTER_COMPARE));
	//
	// Disables time stamp capture.
	//
	ECAP_disableTimeStampCapture(myECAP0_BASE);
	//
	// Stops Time stamp counter.
	//
	ECAP_stopCounter(myECAP0_BASE);
	//
	// Sets eCAP in Capture mode.
	//
	ECAP_enableCaptureMode(myECAP0_BASE);
	//
	// Sets the capture mode.
	//
	ECAP_setCaptureMode(myECAP0_BASE,ECAP_CONTINUOUS_CAPTURE_MODE,ECAP_EVENT_3);
	//
	// Sets the Capture event prescaler.
	//
	ECAP_setEventPrescaler(myECAP0_BASE, 0U);
	//
	// Sets the Capture event polarity.
	//
	ECAP_setEventPolarity(myECAP0_BASE,ECAP_EVENT_1,ECAP_EVNT_RISING_EDGE);
	ECAP_setEventPolarity(myECAP0_BASE,ECAP_EVENT_2,ECAP_EVNT_FALLING_EDGE);
	ECAP_setEventPolarity(myECAP0_BASE,ECAP_EVENT_3,ECAP_EVNT_RISING_EDGE);
	ECAP_setEventPolarity(myECAP0_BASE,ECAP_EVENT_4,ECAP_EVNT_FALLING_EDGE);
	//
	// Configure counter reset on events
	//
	ECAP_disableCounterResetOnEvent(myECAP0_BASE,ECAP_EVENT_1);
	ECAP_disableCounterResetOnEvent(myECAP0_BASE,ECAP_EVENT_2);
	ECAP_enableCounterResetOnEvent(myECAP0_BASE,ECAP_EVENT_3);	
	ECAP_disableCounterResetOnEvent(myECAP0_BASE,ECAP_EVENT_4);
	//
	// Select eCAP input.
	//
	ECAP_selectECAPInput(myECAP0_BASE,ECAP_INPUT_INPUTXBAR3);
	//
	// Sets a phase shift value count.
	//
	ECAP_setPhaseShiftCount(myECAP0_BASE,0U);
	//
	// Enable counter loading with phase shift value.
	//
	ECAP_enableLoadCounter(myECAP0_BASE);
	//
	// Load time stamp counter.
	//
	ECAP_loadCounter(myECAP0_BASE);
	//
	// Configures Sync out signal mode.
	//
	ECAP_setSyncOutMode(myECAP0_BASE,ECAP_SYNC_OUT_SYNCI);
	//
	// Resets eCAP counters and flags.
	//
	ECAP_resetCounters(myECAP0_BASE);
	//
	// Configures emulation mode.
	//
	ECAP_setEmulationMode(myECAP0_BASE,ECAP_EMULATION_FREE_RUN);
	//
	// Set up the source for sync-in pulse..
	//
	ECAP_setSyncInPulseSource(myECAP0_BASE,ECAP_SYNC_IN_PULSE_SRC_DISABLE);
	//
	// Starts Time stamp counter for myECAP0.
	//
	ECAP_startCounter(myECAP0_BASE);
	//
	// Enables time stamp capture for myECAP0.
	//
	ECAP_enableTimeStampCapture(myECAP0_BASE);
	//
	// Re-arms the eCAP module for myECAP0.
	//
	ECAP_reArm(myECAP0_BASE);
	//
	// Enables interrupt source for myECAP0.
	//
	ECAP_enableInterrupt(myECAP0_BASE,(ECAP_ISR_SOURCE_CAPTURE_EVENT_3));

    //-----------------Signal Monitoring--------------------//
}

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
void EPWM_init(){
    EPWM_setEmulationMode(MTR1_PWM_U_BASE, EPWM_EMULATION_FREE_RUN);	
    EPWM_setClockPrescaler(MTR1_PWM_U_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);	
    EPWM_setTimeBasePeriod(MTR1_PWM_U_BASE, 0);	
    EPWM_setTimeBaseCounter(MTR1_PWM_U_BASE, 0);	
    EPWM_setTimeBaseCounterMode(MTR1_PWM_U_BASE, EPWM_COUNTER_MODE_UP_DOWN);	
    EPWM_setCountModeAfterSync(MTR1_PWM_U_BASE, EPWM_COUNT_MODE_UP_AFTER_SYNC);	
    EPWM_disablePhaseShiftLoad(MTR1_PWM_U_BASE);	
    EPWM_setPhaseShift(MTR1_PWM_U_BASE, 0);	
    EPWM_setSyncPulseSource(MTR1_PWM_U_BASE, HRPWM_PWMSYNC_SOURCE_ZERO);	
    EPWM_setCounterCompareValue(MTR1_PWM_U_BASE, EPWM_COUNTER_COMPARE_A, 0);	
    EPWM_setCounterCompareShadowLoadMode(MTR1_PWM_U_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(MTR1_PWM_U_BASE, EPWM_COUNTER_COMPARE_B, 0);	
    EPWM_setCounterCompareShadowLoadMode(MTR1_PWM_U_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_U_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setDeadBandDelayPolarity(MTR1_PWM_U_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);	
    EPWM_setDeadBandDelayMode(MTR1_PWM_U_BASE, EPWM_DB_RED, true);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(MTR1_PWM_U_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(MTR1_PWM_U_BASE);	
    EPWM_setRisingEdgeDelayCount(MTR1_PWM_U_BASE, 10);	
    EPWM_setDeadBandDelayMode(MTR1_PWM_U_BASE, EPWM_DB_FED, true);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(MTR1_PWM_U_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(MTR1_PWM_U_BASE);	
    EPWM_setFallingEdgeDelayCount(MTR1_PWM_U_BASE, 10);	
    EPWM_setTripZoneAction(MTR1_PWM_U_BASE, EPWM_TZ_ACTION_EVENT_TZA, EPWM_TZ_ACTION_LOW);	
    EPWM_setTripZoneAction(MTR1_PWM_U_BASE, EPWM_TZ_ACTION_EVENT_TZB, EPWM_TZ_ACTION_LOW);	
    EPWM_enableTripZoneSignals(MTR1_PWM_U_BASE, EPWM_TZ_SIGNAL_DCAEVT1 | EPWM_TZ_SIGNAL_DCBEVT1);	
    EPWM_enableTripZoneSignals(MTR1_PWM_U_BASE, EPWM_TZ_SIGNAL_CBC6);	
    EPWM_selectDigitalCompareTripInput(MTR1_PWM_U_BASE, EPWM_DC_TRIP_COMBINATION, EPWM_DC_TYPE_DCAH);	
    EPWM_enableDigitalCompareTripCombinationInput(MTR1_PWM_U_BASE, EPWM_DC_COMBINATIONAL_TRIPIN7, EPWM_DC_TYPE_DCAH);	
    EPWM_setTripZoneDigitalCompareEventCondition(MTR1_PWM_U_BASE, EPWM_TZ_DC_OUTPUT_A1, EPWM_TZ_EVENT_DCXH_HIGH);	
    EPWM_setDigitalCompareEventSyncMode(MTR1_PWM_U_BASE, EPWM_DC_MODULE_A, EPWM_DC_EVENT_1, EPWM_DC_EVENT_INPUT_NOT_SYNCED);	
    EPWM_setDigitalCompareEventSource(MTR1_PWM_U_BASE, EPWM_DC_MODULE_A, EPWM_DC_EVENT_1, EPWM_DC_EVENT_SOURCE_FILT_SIGNAL);	
    EPWM_selectDigitalCompareTripInput(MTR1_PWM_U_BASE, EPWM_DC_TRIP_COMBINATION, EPWM_DC_TYPE_DCBH);	
    EPWM_enableDigitalCompareTripCombinationInput(MTR1_PWM_U_BASE, EPWM_DC_COMBINATIONAL_TRIPIN7, EPWM_DC_TYPE_DCBH);	
    EPWM_setTripZoneDigitalCompareEventCondition(MTR1_PWM_U_BASE, EPWM_TZ_DC_OUTPUT_B1, EPWM_TZ_EVENT_DCXL_HIGH);	
    EPWM_setDigitalCompareEventSyncMode(MTR1_PWM_U_BASE, EPWM_DC_MODULE_B, EPWM_DC_EVENT_1, EPWM_DC_EVENT_INPUT_NOT_SYNCED);	
    EPWM_setDigitalCompareEventSource(MTR1_PWM_U_BASE, EPWM_DC_MODULE_B, EPWM_DC_EVENT_1, EPWM_DC_EVENT_SOURCE_FILT_SIGNAL);	
    EPWM_enableInterrupt(MTR1_PWM_U_BASE);	
    EPWM_setInterruptSource(MTR1_PWM_U_BASE, EPWM_INT_TBCTR_ZERO);	
    EPWM_setInterruptEventCount(MTR1_PWM_U_BASE, 1);	
    EPWM_enableADCTrigger(MTR1_PWM_U_BASE, EPWM_SOC_A);	
    EPWM_setADCTriggerSource(MTR1_PWM_U_BASE, EPWM_SOC_A, EPWM_SOC_TBCTR_D_CMPC);	
    EPWM_setADCTriggerEventPrescale(MTR1_PWM_U_BASE, EPWM_SOC_A, 1);	
    EPWM_setEmulationMode(MTR1_PWM_V_BASE, EPWM_EMULATION_FREE_RUN);	
    EPWM_setClockPrescaler(MTR1_PWM_V_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);	
    EPWM_setTimeBasePeriod(MTR1_PWM_V_BASE, 0);	
    EPWM_setTimeBaseCounter(MTR1_PWM_V_BASE, 0);	
    EPWM_setTimeBaseCounterMode(MTR1_PWM_V_BASE, EPWM_COUNTER_MODE_UP_DOWN);	
    EPWM_setCountModeAfterSync(MTR1_PWM_V_BASE, EPWM_COUNT_MODE_UP_AFTER_SYNC);	
    EPWM_disablePhaseShiftLoad(MTR1_PWM_V_BASE);	
    EPWM_setPhaseShift(MTR1_PWM_V_BASE, 0);	
    EPWM_setSyncPulseSource(MTR1_PWM_V_BASE, HRPWM_PWMSYNC_SOURCE_ZERO);	
    EPWM_setCounterCompareValue(MTR1_PWM_V_BASE, EPWM_COUNTER_COMPARE_A, 0);	
    EPWM_setCounterCompareShadowLoadMode(MTR1_PWM_V_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(MTR1_PWM_V_BASE, EPWM_COUNTER_COMPARE_B, 0);	
    EPWM_setCounterCompareShadowLoadMode(MTR1_PWM_V_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_V_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setDeadBandDelayPolarity(MTR1_PWM_V_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);	
    EPWM_setDeadBandDelayMode(MTR1_PWM_V_BASE, EPWM_DB_RED, true);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(MTR1_PWM_V_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(MTR1_PWM_V_BASE);	
    EPWM_setRisingEdgeDelayCount(MTR1_PWM_V_BASE, 10);	
    EPWM_setDeadBandDelayMode(MTR1_PWM_V_BASE, EPWM_DB_FED, true);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(MTR1_PWM_V_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(MTR1_PWM_V_BASE);	
    EPWM_setFallingEdgeDelayCount(MTR1_PWM_V_BASE, 10);	
    EPWM_setTripZoneAction(MTR1_PWM_V_BASE, EPWM_TZ_ACTION_EVENT_TZA, EPWM_TZ_ACTION_LOW);	
    EPWM_setTripZoneAction(MTR1_PWM_V_BASE, EPWM_TZ_ACTION_EVENT_TZB, EPWM_TZ_ACTION_LOW);	
    EPWM_enableTripZoneSignals(MTR1_PWM_V_BASE, EPWM_TZ_SIGNAL_DCAEVT1 | EPWM_TZ_SIGNAL_DCBEVT1);	
    EPWM_enableTripZoneSignals(MTR1_PWM_V_BASE, EPWM_TZ_SIGNAL_CBC6);	
    EPWM_selectDigitalCompareTripInput(MTR1_PWM_V_BASE, EPWM_DC_TRIP_COMBINATION, EPWM_DC_TYPE_DCAH);	
    EPWM_enableDigitalCompareTripCombinationInput(MTR1_PWM_V_BASE, EPWM_DC_COMBINATIONAL_TRIPIN7, EPWM_DC_TYPE_DCAH);	
    EPWM_setTripZoneDigitalCompareEventCondition(MTR1_PWM_V_BASE, EPWM_TZ_DC_OUTPUT_A1, EPWM_TZ_EVENT_DCXH_HIGH);	
    EPWM_setDigitalCompareEventSyncMode(MTR1_PWM_V_BASE, EPWM_DC_MODULE_A, EPWM_DC_EVENT_1, EPWM_DC_EVENT_INPUT_NOT_SYNCED);	
    EPWM_setDigitalCompareEventSource(MTR1_PWM_V_BASE, EPWM_DC_MODULE_A, EPWM_DC_EVENT_1, EPWM_DC_EVENT_SOURCE_FILT_SIGNAL);	
    EPWM_selectDigitalCompareTripInput(MTR1_PWM_V_BASE, EPWM_DC_TRIP_COMBINATION, EPWM_DC_TYPE_DCBH);	
    EPWM_enableDigitalCompareTripCombinationInput(MTR1_PWM_V_BASE, EPWM_DC_COMBINATIONAL_TRIPIN7, EPWM_DC_TYPE_DCBH);	
    EPWM_setTripZoneDigitalCompareEventCondition(MTR1_PWM_V_BASE, EPWM_TZ_DC_OUTPUT_B1, EPWM_TZ_EVENT_DCXL_HIGH);	
    EPWM_setDigitalCompareEventSyncMode(MTR1_PWM_V_BASE, EPWM_DC_MODULE_B, EPWM_DC_EVENT_1, EPWM_DC_EVENT_INPUT_NOT_SYNCED);	
    EPWM_setDigitalCompareEventSource(MTR1_PWM_V_BASE, EPWM_DC_MODULE_B, EPWM_DC_EVENT_1, EPWM_DC_EVENT_SOURCE_FILT_SIGNAL);	
    EPWM_setEmulationMode(MTR1_PWM_W_BASE, EPWM_EMULATION_FREE_RUN);	
    EPWM_setClockPrescaler(MTR1_PWM_W_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);	
    EPWM_setTimeBasePeriod(MTR1_PWM_W_BASE, 0);	
    EPWM_setTimeBaseCounter(MTR1_PWM_W_BASE, 0);	
    EPWM_setTimeBaseCounterMode(MTR1_PWM_W_BASE, EPWM_COUNTER_MODE_UP_DOWN);	
    EPWM_setCountModeAfterSync(MTR1_PWM_W_BASE, EPWM_COUNT_MODE_UP_AFTER_SYNC);	
    EPWM_disablePhaseShiftLoad(MTR1_PWM_W_BASE);	
    EPWM_setPhaseShift(MTR1_PWM_W_BASE, 0);	
    EPWM_setSyncPulseSource(MTR1_PWM_W_BASE, HRPWM_PWMSYNC_SOURCE_ZERO);	
    EPWM_setCounterCompareValue(MTR1_PWM_W_BASE, EPWM_COUNTER_COMPARE_A, 0);	
    EPWM_setCounterCompareShadowLoadMode(MTR1_PWM_W_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(MTR1_PWM_W_BASE, EPWM_COUNTER_COMPARE_B, 0);	
    EPWM_setCounterCompareShadowLoadMode(MTR1_PWM_W_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(MTR1_PWM_W_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setDeadBandDelayPolarity(MTR1_PWM_W_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);	
    EPWM_setDeadBandDelayMode(MTR1_PWM_W_BASE, EPWM_DB_RED, true);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(MTR1_PWM_W_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(MTR1_PWM_W_BASE);	
    EPWM_setRisingEdgeDelayCount(MTR1_PWM_W_BASE, 10);	
    EPWM_setDeadBandDelayMode(MTR1_PWM_W_BASE, EPWM_DB_FED, true);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(MTR1_PWM_W_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(MTR1_PWM_W_BASE);	
    EPWM_setFallingEdgeDelayCount(MTR1_PWM_W_BASE, 10);	
    EPWM_setTripZoneAction(MTR1_PWM_W_BASE, EPWM_TZ_ACTION_EVENT_TZA, EPWM_TZ_ACTION_LOW);	
    EPWM_setTripZoneAction(MTR1_PWM_W_BASE, EPWM_TZ_ACTION_EVENT_TZB, EPWM_TZ_ACTION_LOW);	
    EPWM_enableTripZoneSignals(MTR1_PWM_W_BASE, EPWM_TZ_SIGNAL_DCAEVT1 | EPWM_TZ_SIGNAL_DCBEVT1);	
    EPWM_enableTripZoneSignals(MTR1_PWM_W_BASE, EPWM_TZ_SIGNAL_CBC6);	
    EPWM_selectDigitalCompareTripInput(MTR1_PWM_W_BASE, EPWM_DC_TRIP_COMBINATION, EPWM_DC_TYPE_DCAH);	
    EPWM_enableDigitalCompareTripCombinationInput(MTR1_PWM_W_BASE, EPWM_DC_COMBINATIONAL_TRIPIN7, EPWM_DC_TYPE_DCAH);	
    EPWM_setTripZoneDigitalCompareEventCondition(MTR1_PWM_W_BASE, EPWM_TZ_DC_OUTPUT_A1, EPWM_TZ_EVENT_DCXH_HIGH);	
    EPWM_setDigitalCompareEventSyncMode(MTR1_PWM_W_BASE, EPWM_DC_MODULE_A, EPWM_DC_EVENT_1, EPWM_DC_EVENT_INPUT_NOT_SYNCED);	
    EPWM_setDigitalCompareEventSource(MTR1_PWM_W_BASE, EPWM_DC_MODULE_A, EPWM_DC_EVENT_1, EPWM_DC_EVENT_SOURCE_FILT_SIGNAL);	
    EPWM_selectDigitalCompareTripInput(MTR1_PWM_W_BASE, EPWM_DC_TRIP_COMBINATION, EPWM_DC_TYPE_DCBH);	
    EPWM_enableDigitalCompareTripCombinationInput(MTR1_PWM_W_BASE, EPWM_DC_COMBINATIONAL_TRIPIN7, EPWM_DC_TYPE_DCBH);	
    EPWM_setTripZoneDigitalCompareEventCondition(MTR1_PWM_W_BASE, EPWM_TZ_DC_OUTPUT_B1, EPWM_TZ_EVENT_DCXL_HIGH);	
    EPWM_setDigitalCompareEventSyncMode(MTR1_PWM_W_BASE, EPWM_DC_MODULE_B, EPWM_DC_EVENT_1, EPWM_DC_EVENT_INPUT_NOT_SYNCED);	
    EPWM_setDigitalCompareEventSource(MTR1_PWM_W_BASE, EPWM_DC_MODULE_B, EPWM_DC_EVENT_1, EPWM_DC_EVENT_SOURCE_FILT_SIGNAL);	
    EPWM_setClockPrescaler(myEPWM0_BASE, EPWM_CLOCK_DIVIDER_8, EPWM_HSCLOCK_DIVIDER_4);	
    EPWM_setTimeBasePeriod(myEPWM0_BASE, 41666);	
    EPWM_setTimeBaseCounter(myEPWM0_BASE, 0);	
    EPWM_setTimeBaseCounterMode(myEPWM0_BASE, EPWM_COUNTER_MODE_UP);	
    EPWM_disablePhaseShiftLoad(myEPWM0_BASE);	
    EPWM_setPhaseShift(myEPWM0_BASE, 0);	
    EPWM_setSyncInPulseSource(myEPWM0_BASE, EPWM_SYNC_IN_PULSE_SRC_DISABLE);	
    EPWM_setCounterCompareValue(myEPWM0_BASE, EPWM_COUNTER_COMPARE_A, 3000);	
    EPWM_setCounterCompareShadowLoadMode(myEPWM0_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(myEPWM0_BASE, EPWM_COUNTER_COMPARE_B, 0);	
    EPWM_setCounterCompareShadowLoadMode(myEPWM0_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(myEPWM0_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(myEPWM0_BASE);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(myEPWM0_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(myEPWM0_BASE);	
}

//*****************************************************************************
//
// EPWMXBAR Configurations
//
//*****************************************************************************
void EPWMXBAR_init(){
	MTR1_IS_XBAR_EPWM_MUX_init();
}

void MTR1_IS_XBAR_EPWM_MUX_init(){
		
	XBAR_setEPWMMuxConfig(MTR1_IS_XBAR_EPWM_MUX, XBAR_EPWM_MUX00_CMPSS1_CTRIPH_OR_L);
	XBAR_setEPWMMuxConfig(MTR1_IS_XBAR_EPWM_MUX, XBAR_EPWM_MUX02_CMPSS2_CTRIPH_OR_L);
	XBAR_setEPWMMuxConfig(MTR1_IS_XBAR_EPWM_MUX, XBAR_EPWM_MUX04_CMPSS3_CTRIPH_OR_L);
	XBAR_setEPWMMuxConfig(MTR1_IS_XBAR_EPWM_MUX, XBAR_EPWM_MUX06_CMPSS4_CTRIPH);
	XBAR_setEPWMMuxConfig(MTR1_IS_XBAR_EPWM_MUX, XBAR_EPWM_MUX07_INPUTXBAR4);
	XBAR_setEPWMMuxConfig(MTR1_IS_XBAR_EPWM_MUX, XBAR_EPWM_MUX09_INPUTXBAR5);

	//��ʼ�����ã��ػ�����OST������
    /*HWREG(XBAR_BASE + XBAR_O_CLR1) = 0xFFFFFFFF;
    HWREG(XBAR_BASE + XBAR_O_CLR2) = 0xFFFFFFFF;
    CMPSS_clearFilterLatchHigh(CMPSS1_BASE);
    CMPSS_clearFilterLatchLow(CMPSS1_BASE);

    CMPSS_clearFilterLatchHigh(CMPSSLITE3_BASE);
    CMPSS_clearFilterLatchLow(CMPSSLITE3_BASE);

    CMPSS_clearFilterLatchHigh(CMPSSLITE4_BASE);
    CMPSS_clearFilterLatchLow(CMPSSLITE4_BASE);

    CMPSS_clearFilterLatchHigh(CMPSSLITE2_BASE);
    CMPSS_clearFilterLatchLow(CMPSSLITE2_BASE);

    EPWM_clearTripZoneFlag(EPWM1_BASE, EPWM_TZ_FLAG_OST | EPWM_TZ_FLAG_DCAEVT1 | EPWM_TZ_FLAG_DCBEVT1);
    EPWM_clearTripZoneFlag(EPWM2_BASE, EPWM_TZ_FLAG_OST | EPWM_TZ_FLAG_DCAEVT1 | EPWM_TZ_FLAG_DCBEVT1);
    EPWM_clearTripZoneFlag(EPWM3_BASE, EPWM_TZ_FLAG_OST | EPWM_TZ_FLAG_DCAEVT1 | EPWM_TZ_FLAG_DCBEVT1);*/
	XBAR_enableEPWMMux(MTR1_IS_XBAR_EPWM_MUX, XBAR_MUX00 | XBAR_MUX02 | XBAR_MUX04 | XBAR_MUX06 | XBAR_MUX07 | XBAR_MUX09);
}

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
void GPIO_init(){
	Relay3_IO_init();
	GPIO_SYS_DIS_FET_SUPPLY_init();
	LED2_GPIO_init();
	PFC_Ctrl_IO_init();
	myGPIO20_init();
	myGPIO33_init();
}

void Relay3_IO_init(){
	GPIO_writePin(Relay3_IO, 0);
	GPIO_setPadConfig(Relay3_IO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(Relay3_IO, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(Relay3_IO, GPIO_DIR_MODE_OUT);
}
void GPIO_SYS_DIS_FET_SUPPLY_init(){
	GPIO_writePin(GPIO_SYS_DIS_FET_SUPPLY, 1);
	GPIO_setPadConfig(GPIO_SYS_DIS_FET_SUPPLY, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(GPIO_SYS_DIS_FET_SUPPLY, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(GPIO_SYS_DIS_FET_SUPPLY, GPIO_DIR_MODE_OUT);
}
void LED2_GPIO_init(){
	GPIO_writePin(LED2_GPIO, 1);
	GPIO_setPadConfig(LED2_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(LED2_GPIO, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(LED2_GPIO, GPIO_DIR_MODE_OUT);
}
void PFC_Ctrl_IO_init(){
	GPIO_writePin(PFC_Ctrl_IO, 1);
	GPIO_setPadConfig(PFC_Ctrl_IO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PFC_Ctrl_IO, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(PFC_Ctrl_IO, GPIO_DIR_MODE_OUT);
}
void myGPIO20_init(){
	GPIO_setPadConfig(myGPIO20, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(myGPIO20, GPIO_QUAL_SYNC);
    GPIO_setPadConfig(myGPIO20, GPIO_PIN_TYPE_INVERT);
	GPIO_setDirectionMode(myGPIO20, GPIO_DIR_MODE_IN);
}
void myGPIO33_init(){
	GPIO_setPadConfig(myGPIO33, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(myGPIO33, GPIO_QUAL_SYNC);
    GPIO_setPadConfig(myGPIO33, GPIO_PIN_TYPE_INVERT);
	GPIO_setDirectionMode(myGPIO33, GPIO_DIR_MODE_IN);
}

//*****************************************************************************
//
// INPUTXBAR Configurations
//
//*****************************************************************************
void INPUTXBAR_init(){
	myINPUTXBARINPUT0_init();
	myINPUTXBARINPUT1_init();
	myINPUTXBARINPUT2_init();
}

void myINPUTXBARINPUT0_init(){
	XBAR_setInputPin(INPUTXBAR_BASE, myINPUTXBARINPUT0_INPUT, myINPUTXBARINPUT0_SOURCE);
	XBAR_lockInput(INPUTXBAR_BASE, myINPUTXBARINPUT0_INPUT);
}
void myINPUTXBARINPUT1_init(){
	XBAR_setInputPin(INPUTXBAR_BASE, myINPUTXBARINPUT1_INPUT, myINPUTXBARINPUT1_SOURCE);
	XBAR_lockInput(INPUTXBAR_BASE, myINPUTXBARINPUT1_INPUT);
}
void myINPUTXBARINPUT2_init(){
	XBAR_setInputPin(INPUTXBAR_BASE, myINPUTXBARINPUT2_INPUT, myINPUTXBARINPUT2_SOURCE);
	XBAR_lockInput(INPUTXBAR_BASE, myINPUTXBARINPUT2_INPUT);
}

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************
void INTERRUPT_init(){
	
	// Interrupt Setings for INT_MTR1_ADCA_1
	Interrupt_register(INT_MTR1_ADCA_1, &motor1CtrlISR);
	Interrupt_enable(INT_MTR1_ADCA_1);
	
	// Interrupt Setings for INT_myECAP0
	Interrupt_register(INT_myECAP0, &INT_myECAP0_ISR);
	Interrupt_enable(INT_myECAP0);
}
//*****************************************************************************
//
// SCI Configurations
//
//*****************************************************************************
void SCI_init(){
	SCIA_IO_init();
}

void SCIA_IO_init(){
	SCI_clearInterruptStatus(SCIA_IO_BASE, SCI_INT_RXFF | SCI_INT_TXFF | SCI_INT_FE | SCI_INT_OE | SCI_INT_PE | SCI_INT_RXERR | SCI_INT_RXRDY_BRKDT | SCI_INT_TXRDY);
	SCI_clearOverflowStatus(SCIA_IO_BASE);
	SCI_disableFIFO(SCIA_IO_BASE);
	SCI_resetChannels(SCIA_IO_BASE);
	SCI_setConfig(SCIA_IO_BASE, DEVICE_LSPCLK_FREQ, SCIA_IO_BAUDRATE, (SCI_CONFIG_WLEN_8|SCI_CONFIG_STOP_ONE|SCI_CONFIG_PAR_NONE));
	SCI_disableLoopback(SCIA_IO_BASE);
	SCI_performSoftwareReset(SCIA_IO_BASE);
	SCI_enableModule(SCIA_IO_BASE);
}

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************
void SYNC_init(){
	SysCtl_setSyncOutputConfig(SYSCTL_SYNC_OUT_SRC_EPWM1SYNCOUT);
	//
	// SOCA
	//
	SysCtl_enableExtADCSOCSource(0);
	//
	// SOCB
	//
	SysCtl_enableExtADCSOCSource(0);
}
//*****************************************************************************
//
// SYSCTL Configurations
//
//*****************************************************************************
void SYSCTL_init(){
	//
    // sysctl initialization
	//
    SysCtl_setStandbyQualificationPeriod(2);
    SysCtl_configureType(SYSCTL_ECAPTYPE, 0, 0);
    SysCtl_selectErrPinPolarity(0);

    SysCtl_enableMCD();


    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TIMER0);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TIMER1);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TIMER2);
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_HRCAL);
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM1);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM2);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM3);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM4);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM5);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM6);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_EPWM7);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ECAP1);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ECAP2);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ECAP3);
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_EQEP1);
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_EQEP2);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_SCIA);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_SCIB);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_SCIC);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_SPIA);
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_I2CA);
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_I2CB);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_CANA);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_MCANA);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ADCA);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_ADCC);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_CMPSS1);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_CMPSS2);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_CMPSS3);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_CMPSS4);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_LINA);
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_PMBUSA);
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_DCC0);
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_EPG1);



}

